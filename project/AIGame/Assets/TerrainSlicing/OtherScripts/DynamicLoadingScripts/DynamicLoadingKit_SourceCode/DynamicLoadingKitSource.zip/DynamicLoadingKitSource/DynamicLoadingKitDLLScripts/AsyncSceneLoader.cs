﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System.Collections;
    using System.Collections.Generic;
#if !UNITY_4
    using UnityEngine.SceneManagement;
#endif
    /// <summary>
    /// A Cell Object Loader component which loads objects via scenes. This is similar to the 
    /// <see cred = "SceneLoader" href="SceneLoader.html">SceneLoader</see> component, except this version uses 
    /// <see href="http://docs.unity3d.com/ScriptReference/Application.LoadLevelAdditiveAsync.html">Application.LoadLevelAdditiveAsync</see>.
    /// <para>You should never have to interact directly with this component, as the methods/properties are called/used
    /// as needed by the Dynamic Loading Kit.</para>
    /// <para>
    /// This method is available to all Unity 5 users and Unity 4 Pro users.
    /// </para>
    /// </summary>
    /// <title>AsyncSceneLoader Class</title>
    /// <category>Cell Object Loaders</category>
    /// <navigationName>AsyncSceneLoader</navigationName>
    /// <fileName>AsyncSceneLoader.html</fileName>
    /// <syntax>public sealed class AsyncSceneLoader : <see cref = "BaseSceneLoader" href = "BaseSceneLoader.html">BaseSceneLoader</see></syntax>
    /// <inspector name = "Load Priority" type = "ThreadPriority" link = "http://docs.unity3d.com/ScriptReference/ThreadPriority.html">The priority of the thread used to load the scenes. 
    /// A lower priority means the background operation run less often and will take up less time, but will progress more slowly.</inspector>
    [AddComponentMenu("Dynamic Loading Kit/Cell Object Loaders/Async Scene Loader (4 Pro/5 Personal)")]
    public sealed class AsyncSceneLoader : BaseSceneLoader
    {
        [SerializeField]
        internal ThreadPriority loadPriority = ThreadPriority.Normal;

        void Awake()
        {
            Application.backgroundLoadingPriority = loadPriority;
        }

        /// <summary>
        /// Loads the scene/objects with the name objectName into the current scene via <see href="http://docs.unity3d.com/ScriptReference/Application.LoadLevelAdditiveAsync.html">Application.LoadLevelAdditiveAsync</see>.
        /// </summary>
        /// <param name="objectName" type = "string">The name of the object/scene to load.</param>
        /// <displayName id = "LoadCellObjectIntoLevel">LoadCellObjectIntoLevel(string)</displayName>
        /// <syntax>protected sealed override YieldInstruction LoadCellObjectIntoLevel(string objectName)</syntax>
        /// <returns type = "YieldInstruction" link = "http://docs.unity3d.com/ScriptReference/YieldInstruction.html">Returns the 
        /// <see href="http://docs.unity3d.com/ScriptReference/AsyncOperation.html">AsyncOperation</see> object returned by
        /// Application.LoadLevelAddtiveAsync.</returns>
        protected sealed override YieldInstruction LoadCellObjectIntoLevel(string objectName)
        {
#if UNITY_4
            return Application.LoadLevelAdditiveAsync(objectName);
#else
            return SceneManager.LoadSceneAsync(objectName, LoadSceneMode.Additive);
#endif
        }
    }
}