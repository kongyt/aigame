//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;

    /// <summary>
    /// Provides an implementation for a Persistent Data Controller that uses Unity's built in <see href="http://docs.unity3d.com/ScriptReference/PlayerPrefs.html">Player Prefs</see> to save and load
    /// persistent data between game sessions.
    /// </summary>
    /// <title>PlayerPrefsPersistentDataController Class</title>
    /// <category>Primary Components</category>
    /// <navigationName>PlayerPrefsPersistentDataController</navigationName>
    /// <fileName>PlayerPrefsPersistentDataController.html</fileName>
    /// <syntax>public class PlayerPrefsPersistentDataController : <see href = "PersistentDataController.html">PersistentDataController</see></syntax>
    [AddComponentMenu("Dynamic Loading Kit/Main Components/Player Prefs Persistent Data Controller")]
    public sealed class PlayerPrefsPersistentDataController : PersistentDataController
    {
        bool DoesDataExist(string key)
        {
            return PlayerPrefs.HasKey(key);
        }

        /// <summary>
        /// Saves the specified data using the specified key in Player Prefs.
        /// </summary>
        /// <param name="key" type="string">The key used to save the persistent data.</param>
        /// <param name="data" type="string">The persistent data that will be saved.</param>
        /// <displayName id="SaveData">SaveData(string, string)</displayName>
        /// <syntax>public sealed override void SaveData(string key, string data)</syntax>
        public sealed override void SaveData(string key, string data)
        {
            PlayerPrefs.SetString(key, data);
            PlayerPrefs.Save();
        }


        /// <summary>
        /// Attempts to get the persistent data associated with the specified key from Player Prefs.
        /// </summary>
        /// <param name="key" type="string">The key used to try and retrieve the persistent data.</param>
        /// <param name="data" type="out string">A string which will contain the data if successfully retrieved.</param>
        /// <returns type="bool">A value indicating whether the data was successfully retrieved. If false, "data" will be null.</returns>
        /// <displayName id="TryGetData">TryGetData(string, out string)</displayName>
        /// <syntax>public sealed override bool TryGetData(string key, out string data)</syntax>
        public sealed override bool TryGetData(string key, out string data)
        {
            if (DoesDataExist(key))
            {
                data = PlayerPrefs.GetString(key);
                return true;
            }
            else
            {
                data = null;
                return false;
            }
        }

        /// <summary>
        /// Attempts to to delete the persistent data associated with the specified key from Player Prefs.
        /// </summary>
        /// <param name="key" type="string">The key used to identify the persistent data that should be deleted.</param>
        /// <returns type ="bool">A value indicating whether the persistent data was successfully deleted.</returns>
        /// <displayName id="TryDeleteData">TryDeleteData(string)</displayName>
        /// <syntax>public sealed override bool TryDeleteData(string key)</syntax>
        public sealed override bool TryDeleteData(string key)
        {
            if (DoesDataExist(key))
            {
                PlayerPrefs.DeleteKey(key);
                PlayerPrefs.Save();
                return true;
            }
            else
                return false;
        }
    }
}