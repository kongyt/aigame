﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using System;
    using UnityEditor;
    using UnityEngine;

    internal class RangeSettingsGUIDrawer
    {
        SerializedObjectHelper worldSerializedObjectHelper, worldGridSerializedObjectHelper;
        WorldGridBase worldGrid;

        GUILayoutOption labelWidth, fieldWidth, templatePopupWidth, wideLabel;
        string[] templateNames;
        //Reading data straight from the World Grid is safe, as long as it's data that cannot be 
        //changed while inspecting the World component




        internal RangeSettingsGUIDrawer(SerializedObjectHelper worldSerializedObjectHelper, GUILayoutOption wideLabel)
        {
            this.worldSerializedObjectHelper = worldSerializedObjectHelper;

            worldGrid = GetWorldGridAsObject();
            if (worldGrid != null)
                CreateWorldGridSerializedObjectHelper(worldGrid);
                        
            labelWidth = GUILayout.Width(80f);
            fieldWidth = GUILayout.Width(50f);
            templatePopupWidth = GUILayout.Width(150f);
            this.wideLabel = wideLabel;
        }



        //Easy access properties for accessing properties on the world component
        SerializedProperty ActiveRangeIndexProperty { get { return worldSerializedObjectHelper.GetPropertyByName("rangeTemplate"); } }

        SerializedProperty PreviewObjectsProperty { get { return worldSerializedObjectHelper.GetPropertyByName("previewCellObjects"); } }

        SerializedProperty WorldGridProperty { get { return worldSerializedObjectHelper.GetPropertyByName("worldGrid"); } }
        
        bool DrawTemplateDeleteButton { get { return ActiveRangeIndexProperty.intValue != 0; } }


        //Properties for accessing data straight from the world grid object.
        //Only data that cannot be changed while inspecting the world component can be accessed, as 
        //it's guaranteed not to change while this drawer (and the rest of the world drawer) is executing

        bool IsWorld3D
        { get { return worldGrid.WorldType == WorldType.Three_Dimensional; } }

        bool UseLayerRange
        { get { return IsWorld3D; } }

        

        //Easy access propeties for accessing seralized properties on the world grid
        //These can be changed by this gui drawer, so we need to interface with them through 
        //the serialized properties
        SerializedProperty RangeTemplatesProperty
        { get { return worldGridSerializedObjectHelper.GetPropertyByName("rangeTemplates"); } }

        SerializedProperty RangeTemplateNamesProperty
        { get { return worldGridSerializedObjectHelper.GetPropertyByName("rangeTemplateNames"); } }

        

        

        

        void CreateWorldGridSerializedObjectHelper(WorldGridBase worldGrid)
        {
            SerializedObject serialiedObjectForWorldGrid = new SerializedObject(worldGrid);
            worldGridSerializedObjectHelper = new SerializedObjectHelper(serialiedObjectForWorldGrid);
        }

       

        WorldGridBase GetWorldGridAsObject()
        {
            return WorldGridProperty.objectReferenceValue as WorldGridBase;
        }

        SerializedProperty GetActiveRange()
        {
            int rangeTemplateIndex = ActiveRangeIndexProperty.intValue;
            return GetRangeTemplate(rangeTemplateIndex);
        }

        public void DrawGUI()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Cell Object Preview Settings", EditorStyles.boldLabel);

            worldGrid = GetWorldGridAsObject();

            if (worldGrid != null)
            {
                if (worldGridSerializedObjectHelper == null)
                    CreateWorldGridSerializedObjectHelper(worldGrid);

                worldGridSerializedObjectHelper.SerializedObject.Update();
                CheckAllRangesTemplateAccuracy(GetRangeTemplate(0));
                DrawRangeSettings();
                worldGridSerializedObjectHelper.SerializedObject.ApplyModifiedProperties();
            }
            else
            {
                worldGridSerializedObjectHelper = null;
                EditorGUILayout.HelpBox("Preview Options Unavailable. Please provide a World Grid to enable this feature.", MessageType.Info);
            }
        }

        void DrawRangeSettings()
        {          
            DrawLoadRangeTemplateOption();
            EditorGUILayout.Space();

            DrawRangeValueFields();
            EditorGUILayout.Space();

            DrawLoadMethodOption();

            EditorGUILayout.LabelField(addObjectsNote);

            if (GUILayout.Button("Add Cell Objects To Scene Using Range Values"))
                AddCellObjectsToScene();
        }
        
        void DrawLoadRangeTemplateOption()
        {
            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.LabelField(rangeTemplateLabel);

            EditorGUILayout.BeginVertical();

            GUI.SetNextControlName("Template Popup");

            RebuildTemplateNamesArray();
            EditorGUI.BeginChangeCheck();
            ActiveRangeIndexProperty.intValue = EditorGUILayout.Popup(ActiveRangeIndexProperty.intValue, templateNames, templatePopupWidth);
            
            if (EditorGUI.EndChangeCheck())
                GUI.FocusControl("Template Popup");

            if (DrawTemplateDeleteButton)
            {
                GUI.SetNextControlName("Remove Template");
                if (GUILayout.Button("Remove Template", EditorStyles.miniButton, templatePopupWidth))
                {
                    GUI.FocusControl("Remove Template");
                    RemoveRangeTemplate(ActiveRangeIndexProperty.intValue);
                    ActiveRangeIndexProperty.intValue--;
                }
            }

            GUI.SetNextControlName("Create Template");
            if (GUILayout.Button("Create New Template", EditorStyles.miniButton, templatePopupWidth))
            {
                GUI.FocusControl("Create Template");
                CreateNewTemplate();
            }

            EditorGUILayout.EndVertical();
            EditorGUILayout.EndHorizontal();
        }

        void RebuildTemplateNamesArray()
        {
            if (templateNames == null || RangeTemplateNamesProperty.arraySize != templateNames.Length)
                templateNames = new string[RangeTemplateNamesProperty.arraySize];

            for (int i = 0; i < templateNames.Length; i++)
                templateNames[i] = RangeTemplateNamesProperty.GetArrayElementAtIndex(i).stringValue;
        }

        void DrawRangeValueFields()
        {
            SerializedProperty activeRange = GetRangeTemplate(ActiveRangeIndexProperty.intValue);
            if (ActiveRangeIndexProperty.intValue == 0)
            {
                EditorGUILayout.LabelField("Range Values (Uneditable)", EditorStyles.boldLabel);
                DrawNonEditableNameField(activeRange);

                if (UseLayerRange)
                    DrawNonEditableRangeField("First Layer", "Last Layer", activeRange.FindPropertyRelative("firstLayer"), activeRange.FindPropertyRelative("lastLayer"));

                DrawNonEditableRangeField("First Row", "Last Row", activeRange.FindPropertyRelative("firstRow"), activeRange.FindPropertyRelative("lastRow"));

                DrawNonEditableRangeField("First Column", "Last Column", activeRange.FindPropertyRelative("firstColumn"), activeRange.FindPropertyRelative("lastColumn"));
            }
            else
            {
                EditorGUILayout.LabelField("Range Values (Editable)", EditorStyles.boldLabel);
                DrawEditableNameField(activeRange);

                if (UseLayerRange)
                    DrawEditableRangeField("First Layer", "Last Layer", activeRange.FindPropertyRelative("firstLayer"), activeRange.FindPropertyRelative("lastLayer"));

                DrawEditableRangeField("First Row", "Last Row", activeRange.FindPropertyRelative("firstRow"), activeRange.FindPropertyRelative("lastRow"));

                DrawEditableRangeField("First Column", "Last Column", activeRange.FindPropertyRelative("firstColumn"), activeRange.FindPropertyRelative("lastColumn"));
            }
        }

        void CheckAllRangesTemplateAccuracy(SerializedProperty range)
        {
            if (worldGrid.namingConvention != null && worldGrid.namingConvention.NumberingStartsAt0)
            {
                if (range.FindPropertyRelative("lastRow").intValue != worldGrid.Rows - 1
                    || range.FindPropertyRelative("lastColumn").intValue != worldGrid.Columns - 1
                    || range.FindPropertyRelative("lastLayer").intValue != worldGrid.Layers - 1
                    || range.FindPropertyRelative("firstRow").intValue != 0
                    || range.FindPropertyRelative("firstColumn").intValue != 0
                    || range.FindPropertyRelative("firstLayer").intValue != 0)
                        SetRangeToMax(range);
            }
            else
            {
                if (range.FindPropertyRelative("lastRow").intValue != worldGrid.Rows
                    || range.FindPropertyRelative("lastColumn").intValue != worldGrid.Columns
                    || range.FindPropertyRelative("lastLayer").intValue != worldGrid.Layers
                    || range.FindPropertyRelative("firstRow").intValue != 1
                    || range.FindPropertyRelative("firstColumn").intValue != 1
                    || range.FindPropertyRelative("firstLayer").intValue != 1)
                        SetRangeToMax(range);
            }
        }

        void DrawEditableNameField(SerializedProperty rangeProp)
        {
            bool templateNameChanged;
            worldGridSerializedObjectHelper.DrawNestedSerializedPropertyField(rangeProp, "name", "Template Name", out templateNameChanged);

            if(templateNameChanged)
                RewriteTemplateName(ActiveRangeIndexProperty.intValue);
        }

        void DrawNonEditableNameField(SerializedProperty rangeProp)
        {
            EditorGUILayout.TextField("Template Name", rangeProp.FindPropertyRelative("name").stringValue);
        }

        void DrawEditableRangeField(string firstLabel, string lastLabel, SerializedProperty firstValue, SerializedProperty lastValue)
        {
            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.LabelField(firstLabel, labelWidth);
            worldGridSerializedObjectHelper.DrawSerializedPropertyField(firstValue, GUIContent.none);
            EditorGUILayout.LabelField(lastLabel, labelWidth);
            worldGridSerializedObjectHelper.DrawSerializedPropertyField(lastValue, GUIContent.none);

            EditorGUILayout.EndHorizontal();
        }

        void DrawNonEditableRangeField(string firstLabel, string lastLabel, SerializedProperty firstValue, SerializedProperty lastValue)
        {
            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.LabelField(firstLabel, labelWidth);
            EditorGUILayout.IntField(firstValue.intValue, fieldWidth);

            EditorGUILayout.LabelField(lastLabel, labelWidth);
            EditorGUILayout.IntField(lastValue.intValue, fieldWidth);

            EditorGUILayout.EndHorizontal();
        }

        void DrawLoadMethodOption()
        {
            SerializedProperty loadPrefabsFromResourcesFolder = worldGridSerializedObjectHelper.GetPropertyByName("loadPrefabsFromResourcesFolder");

            EditorGUILayout.LabelField(SharedLabels.loadPrefabsFromResourcesFolderLabel1);

            EditorGUILayout.PropertyField(loadPrefabsFromResourcesFolder, SharedLabels.loadPrefabsFromResourcesFolderLabel2);
            
            EditorGUILayout.Space();

            if (!loadPrefabsFromResourcesFolder.boolValue)
            {
                EditorGUILayout.LabelField(SharedLabels.prefabFolderPathLabel1);

                EditorGUILayout.PropertyField(worldGridSerializedObjectHelper.GetPropertyByName ("folderPathWherePrefabsAreStored"), SharedLabels.loadPrefabsFromResourcesFolderLabel2);
                EditorGUILayout.Space();
            }
        }
        
        string loadReadyPath;

        void AddCellObjectsToScene()
        {
            if (!IsRangeValid())
            {
                EditorUtility.DisplayDialog("Invalid Range", "Each 'first' value must be smaller than or equal to its corresponding 'last' value.", "OK");
                return;
            }

            bool loadPrefabsFromResourcesFolder = worldGridSerializedObjectHelper.GetPropertyByName("loadPrefabsFromResourcesFolder").boolValue;

            string folderPathWherePrefabsAreStored = worldGridSerializedObjectHelper.GetPropertyByName("folderPathWherePrefabsAreStored").stringValue;

            if (!loadPrefabsFromResourcesFolder && !StringExtensions.TryGetLoadReadyFolderPath(folderPathWherePrefabsAreStored, ref loadReadyPath))
            {
                EditorUtility.DisplayDialog("Invalid Folder Path", "Cannot load objects because the specified folder does not exist!", "OK");
                return;
            }

            Vector3 worldOrigin;
            bool useThisGameObjectsPositionAsWorldOrigin = worldSerializedObjectHelper.GetPropertyByName("useThisGameObjectsPositionAsWorldOrigin").boolValue;

            if (useThisGameObjectsPositionAsWorldOrigin)
            {
                World world = (World)worldSerializedObjectHelper.SerializedObject.targetObject;
                worldOrigin = world.transform.position;
            }
            else
                worldOrigin = worldSerializedObjectHelper.GetPropertyByName("worldOrigin").vector3Value;
            
            INamingConvention namingConventionToUseForBaseCells = worldGrid.namingConvention.GetCorrectNamingConvention(IsWorld3D);

            Vector3 positionOfFirstCell = FindPositionOfFirstCellToLoad(worldOrigin, namingConventionToUseForBaseCells);

            string formatString = namingConventionToUseForBaseCells.GetStringFormatVersion(IsWorld3D, worldGrid.GroupName);
            int firstIndexValue = namingConventionToUseForBaseCells.NumberingStartsAt0 ? 0 : 1;

            if (worldGrid.WorldType == WorldType.Three_Dimensional)
                Add3DCellObjectsToScene(positionOfFirstCell, formatString, firstIndexValue, worldGrid.emptyGridLocations, worldGrid.positionOffset);
            else if (worldGrid.WorldType == WorldType.Two_Dimensional_On_XY_Axes)
                Add2DCellObjectsToScene(positionOfFirstCell, IncreaseYSpawn, formatString, firstIndexValue, worldGrid.emptyGridLocations, worldGrid.positionOffset);
            else
                Add2DCellObjectsToScene(positionOfFirstCell, IncreaseZSpawn, formatString, firstIndexValue, worldGrid.emptyGridLocations, worldGrid.positionOffset);
            
            loadReadyPath = null;
        }

        Vector3 FindPositionOfFirstCellToLoad(Vector3 worldOrigin, INamingConvention namingConvention)
        {
            SerializedProperty activeRange = GetActiveRange();
            if (namingConvention.NumberingStartsAt0)
                return worldGrid.GetPositionOfEndlessGridCell(new Cell(activeRange.FindPropertyRelative("firstLayer").intValue, activeRange.FindPropertyRelative("firstRow").intValue, activeRange.FindPropertyRelative("firstColumn").intValue), new Cell(0, 0, 0), worldOrigin);

            else
                return worldGrid.GetPositionOfEndlessGridCell(new Cell(activeRange.FindPropertyRelative("firstLayer").intValue - 1, activeRange.FindPropertyRelative("firstRow").intValue - 1, activeRange.FindPropertyRelative("firstColumn").intValue - 1), new Cell(0, 0, 0), worldOrigin);
        }

        bool IsRangeValid()
        {
            SerializedProperty activeRange = GetActiveRange();
            if (IsWorld3D && activeRange.FindPropertyRelative("firstLayer").intValue > activeRange.FindPropertyRelative("lastLayer").intValue)
                return false;

            if (activeRange.FindPropertyRelative("firstRow").intValue > activeRange.FindPropertyRelative("lastRow").intValue)
                return false;

            if (activeRange.FindPropertyRelative("firstColumn").intValue > activeRange.FindPropertyRelative("lastColumn").intValue)
                return false;

            return true;
        }


        

        delegate void IncreaseYOrZSpawn(float increaseAmount, ref float ySpawn, ref float zSpawn);

        void Add2DCellObjectsToScene(Vector3 positionOfFirstCell, IncreaseYOrZSpawn IncreaseYOrZSpawn, string formatString, int firstRowColumnIndexValue, bool[] emptyLocations, Vector3 percentageOffsets)
        {
            if (emptyLocations.Length == 1 && emptyLocations[0] == true)
            {
                Debug.Log("All cells are empty in the World Grid you are trying to load objects for!");
                return;
            }
            
            bool allObjectsInGridPresent = emptyLocations.Length == 1;

            float startingXSpawn = positionOfFirstCell.x;

            float ySpawn = positionOfFirstCell.y;
            float zSpawn = positionOfFirstCell.z;

            Func<int, int, string> GetObjectName;

            GetObjectName = (row, column) => string.Format(formatString, column, row);

            SerializedProperty activeRange = GetActiveRange();
            int firstRow = activeRange.FindPropertyRelative("firstRow").intValue;
            int lastRow = activeRange.FindPropertyRelative("lastRow").intValue;

            for (int row = firstRow; row <= lastRow; row++)
            {
                int worldGridRow = worldGrid.ConvertEndlessGridRowToWorldGridRow_ZeroBased(row - firstRowColumnIndexValue);
                float rowLength = worldGrid.rowLengths.Length == 1 ? worldGrid.rowLengths[0] : worldGrid.rowLengths[worldGridRow];
                float xSpawn = startingXSpawn;

                int firstColumn = activeRange.FindPropertyRelative("firstColumn").intValue;
                int lastColumn = activeRange.FindPropertyRelative("lastColumn").intValue;

                for (int column = firstColumn; column <= lastColumn; column++)
                {
                    int worldGridColumn = worldGrid.ConvertEndlessGridColumnToWorldGridColumn_ZeroBased(column - firstRowColumnIndexValue);
                    float columnWidth = worldGrid.columnWidths.Length == 1 ? worldGrid.columnWidths[0] : worldGrid.columnWidths[worldGridColumn];

                    string objName = GetObjectName(worldGridRow + firstRowColumnIndexValue, worldGridColumn + firstRowColumnIndexValue);

                    if (allObjectsInGridPresent || !emptyLocations[Get2DArrayIndex(worldGridRow, worldGridColumn)])
                    {
                        float yOffset, zOffset;
                        if(worldGrid.WorldType == WorldType.Two_Dimensional_On_XY_Axes)
                        {
                            yOffset = rowLength * percentageOffsets.y;
                            zOffset = 0f;
                        }
                        else
                        {
                            zOffset = rowLength * percentageOffsets.z;
                            yOffset = 0f;
                        }
                        LoadObject(objName, new Vector3(xSpawn, ySpawn, zSpawn) + new Vector3(columnWidth * percentageOffsets.x, yOffset, zOffset));
                    }
                    xSpawn += worldGrid.GetWidthOfWorldGridColumn(worldGridColumn);
                }

                IncreaseYOrZSpawn(worldGrid.GetLengthOfWorldGridRow(worldGridRow), ref ySpawn, ref zSpawn);
            }
        }

        void IncreaseYSpawn(float increaseAmount, ref float ySpawn, ref float zSpawn)
        {
            ySpawn += increaseAmount;
        }

        void IncreaseZSpawn(float increaseAmount, ref float ySpawn, ref float zSpawn)
        {
            zSpawn += increaseAmount;
        }




        void Add3DCellObjectsToScene(Vector3 positionOfFirstCell, string formatString, int firstRowColumnIndexValue, bool[] emptyLocations, Vector3 percentageOffsets)
        {
            if(emptyLocations.Length == 1 && emptyLocations[0] == true)
            {
                Debug.Log("All cells are empty in the World Grid you are trying to load objects for!");
                return;
            }

            bool allObjectsInGridPresent = emptyLocations.Length == 1;
            float startingXSpawn = positionOfFirstCell.x;

            float ySpawn = positionOfFirstCell.y;
            float startingZSpawn = positionOfFirstCell.z;
            
            Func<int, int, int, string> GetObjectName;

            GetObjectName = (layer, row, column) => string.Format(formatString, column, row, layer);

            SerializedProperty activeRange = GetActiveRange();

            int firstLayer = activeRange.FindPropertyRelative("firstLayer").intValue;
            int lastLayer = activeRange.FindPropertyRelative("lastLayer").intValue;

            for (int layer = firstLayer; layer <= lastLayer; layer++)
            {
                int worldGridLayer = worldGrid.ConvertEndlessGridLayerToWorldGridLayer_ZeroBased(layer - firstRowColumnIndexValue);
                float layerHeight = worldGrid.layerHeights.Length == 1 ? worldGrid.layerHeights[0] : worldGrid.layerHeights[worldGridLayer];

                float zSpawn = startingZSpawn;

                int firstRow = activeRange.FindPropertyRelative("firstRow").intValue;
                int lastRow = activeRange.FindPropertyRelative("lastRow").intValue;

                for (int row = firstRow; row <= lastRow; row++)
                {
                    int worldGridRow = worldGrid.ConvertEndlessGridRowToWorldGridRow_ZeroBased(row - firstRowColumnIndexValue);
                    float rowLength = worldGrid.rowLengths.Length == 1 ? worldGrid.rowLengths[0] : worldGrid.rowLengths[worldGridRow];
                    float xSpawn = startingXSpawn;

                    int firstColumn = activeRange.FindPropertyRelative("firstColumn").intValue;
                    int lastColumn = activeRange.FindPropertyRelative("lastColumn").intValue;

                    for (int column = firstColumn; column <= lastColumn; column++)
                    {
                        int worldGridColumn = worldGrid.ConvertEndlessGridColumnToWorldGridColumn_ZeroBased(column - firstRowColumnIndexValue);

                        float columnWidth = worldGrid.columnWidths.Length == 1 ? worldGrid.columnWidths[0] : worldGrid.columnWidths[worldGridColumn];

                        string objName = GetObjectName(worldGridLayer + firstRowColumnIndexValue, worldGridRow + firstRowColumnIndexValue, worldGridColumn + firstRowColumnIndexValue);

                        if (allObjectsInGridPresent || !emptyLocations[Get3DArrayIndex(worldGridLayer, worldGridRow, worldGridColumn)])
                            LoadObject(objName, new Vector3(xSpawn, ySpawn, zSpawn) + new Vector3(columnWidth * percentageOffsets.x, layerHeight * percentageOffsets.y, rowLength * percentageOffsets.z));

                        xSpawn += worldGrid.GetWidthOfWorldGridColumn(worldGridColumn);
                    }

                    zSpawn += worldGrid.GetLengthOfWorldGridRow(worldGridRow);
                }

                ySpawn += worldGrid.GetHeightOfWorldGridLayer(worldGridLayer);
            }
        }

        void LoadObject(string objectName, Vector3 loadLocation)
        {
            try {
                GameObject prefab;


                if (worldGridSerializedObjectHelper.GetPropertyByName("loadPrefabsFromResourcesFolder").boolValue)
                    prefab = Resources.Load(objectName) as GameObject;
                else
#if UNITY_4
                prefab = Resources.LoadAssetAtPath(loadReadyPath + objectName + ".prefab", typeof(GameObject)) as GameObject;
#else
                    prefab = AssetDatabase.LoadAssetAtPath<GameObject>(loadReadyPath + objectName + ".prefab");
#endif

                if (prefab != null)
                {
                    GameObject clone = PrefabUtility.InstantiatePrefab(prefab) as GameObject;

                    if (clone != null)
                    {
                        //3.5-4.x difference
                        clone.SetActive(true);

                        clone.transform.position = loadLocation;
                        clone.name = objectName;
                        PreviewObjectsProperty.InsertArrayElementAtIndex(PreviewObjectsProperty.arraySize);
                        PreviewObjectsProperty.GetArrayElementAtIndex(PreviewObjectsProperty.arraySize - 1).objectReferenceValue = clone;
                    }
                    else
                        Debug.Log(string.Format("The asset named {0} was not a prefab!", objectName));
                }
                else
                    Debug.Log(string.Format("The prefab named {0} could not be found in the specified location.", objectName));
            }
            catch(NullReferenceException e)
            {
                Debug.Log(objectName);
                Debug.Log(worldGridSerializedObjectHelper == null);
                Debug.Log(worldGridSerializedObjectHelper.GetPropertyByName("loadPrefabsFromResourcesFolder") == null);
                throw e;
            }
        }

        //Convert layer, row, and column indexes to a 1 dimensional array index
        int Get3DArrayIndex(int layer, int row, int column)
        {
            return ((row) * worldGrid.Columns + (column)) + (worldGrid.Rows * worldGrid.Columns * (layer));
        }

        //Convert row and column to a 1 dimensional array index
        int Get2DArrayIndex(int row, int column)
        {
            return ((row) * worldGrid.Columns + (column));
        }




        void RemoveRangeTemplate(int rangeTemplate)
        {
            if (rangeTemplate == 0)
                return;
            
            RangeTemplatesProperty.DeleteArrayElementAtIndex(rangeTemplate);
            RangeTemplateNamesProperty.DeleteArrayElementAtIndex(rangeTemplate);
        }

        SerializedProperty GetRangeTemplate(int rangeTemplate)
        {
            return RangeTemplatesProperty.GetArrayElementAtIndex(rangeTemplate);
        }

        void CreateNewTemplate()
        {
            RangeTemplatesProperty.InsertArrayElementAtIndex(RangeTemplatesProperty.arraySize);
            ActiveRangeIndexProperty.intValue = RangeTemplatesProperty.arraySize - 1;
            SerializedProperty activeRange = GetActiveRange();
            SetRangeToMax(activeRange);
            activeRange.FindPropertyRelative("name").stringValue = "Default Range";

            string name = string.Format("({0}) {1}", RangeTemplateNamesProperty.arraySize+1, "Default Range");
            RangeTemplateNamesProperty.InsertArrayElementAtIndex(RangeTemplateNamesProperty.arraySize);
            RangeTemplateNamesProperty.GetArrayElementAtIndex(RangeTemplateNamesProperty.arraySize - 1).stringValue = name;
        }
        
        void SetRangeToMax(SerializedProperty range)
        {
            if (worldGrid.namingConvention != null && worldGrid.namingConvention.NumberingStartsAt0)
            {
                range.FindPropertyRelative("firstLayer").intValue = 0;
                range.FindPropertyRelative("firstRow").intValue = 0;
                range.FindPropertyRelative("firstColumn").intValue = 0;
                range.FindPropertyRelative("lastLayer").intValue = worldGrid.Layers - 1;
                range.FindPropertyRelative("lastRow").intValue = worldGrid.Rows - 1;
                range.FindPropertyRelative("lastColumn").intValue = worldGrid.Columns - 1;
            }
            else
            {
                range.FindPropertyRelative("firstLayer").intValue = 1;
                range.FindPropertyRelative("firstRow").intValue = 1;
                range.FindPropertyRelative("firstColumn").intValue = 1;
                range.FindPropertyRelative("lastLayer").intValue = worldGrid.Layers;
                range.FindPropertyRelative("lastRow").intValue = worldGrid.Rows;
                range.FindPropertyRelative("lastColumn").intValue = worldGrid.Columns;
            }
        }

        void RewriteTemplateName(int rangeTemplate)
        {
            if (rangeTemplate == 0)
                return;

            string rangeTemplateName = RangeTemplatesProperty.GetArrayElementAtIndex(rangeTemplate).FindPropertyRelative("name").stringValue;

            RangeTemplateNamesProperty.GetArrayElementAtIndex(rangeTemplate).stringValue = string.Format("({0}) {1}", rangeTemplate + 1, rangeTemplateName);
        }
        


        GUIContent addObjectsNote = new GUIContent("Special Note about Adding Objects: Please Hover over to Read!",
             "You are free to edit the preview objects, just note that in most cases you will need to apply prefab changes if you want the edits to be permanent.\n\n" +
             "The exception is when editing Terrain Data (anything other than the settings found under 'Terrain Settings'. These changes are permanent as soon as you make them.\n\n" +
             "No attempt will be made to load objects at empty grid locations.");

        GUIContent rangeTemplateLabel = new GUIContent("Range Template*", "Range Templates can be used to load ranges of objects " +
            "from your world grid. You can create, edit, and remove templates at will (though the default Load All Objects template " +
            "cannot be removed).\n\nThese templates are saved to the World Grid asset, so all Worlds that use the World Grid asset will have " +
            "access to the templates.");
    
    }
}