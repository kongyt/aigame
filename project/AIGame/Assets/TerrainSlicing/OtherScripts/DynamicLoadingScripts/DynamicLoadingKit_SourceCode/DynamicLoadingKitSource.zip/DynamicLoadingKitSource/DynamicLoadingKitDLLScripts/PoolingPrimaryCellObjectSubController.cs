//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;
	using System.Collections.Generic;
    using System.Collections.ObjectModel;
#if !UNITY_4
    using UnityEngine.SceneManagement;
#endif
    /// <summary>
    /// Provides an implementation for a Primary Cell Object Sub Controller that pools cell objects when they are not in use.
    /// <para>The pooling system is very simple, so you may wish to create your own sub controller class that implements a more 
    /// advanced system.</para>
    /// </summary>
    /// <title>PoolingPrimaryCellObjectSubController Class</title>
    /// <category>Sub Controllers</category>
    /// <navigationName>PoolingPrimaryCellObjectSubController</navigationName>
    /// <fileName>PoolingPrimaryCellObjectSubController.html</fileName>
    /// <syntax>public sealed class PoolingPrimaryCellObjectSubController : <see cref="PrimaryCellObjectSubController" href="PrimaryCellObjectSubController.html">PrimaryCellObjectSubController</see></syntax>
    /// 
    /// <inspector name="Max Objects to Pool Per Cell" type="int">The maximum number of objects that will be stored in the pool for each cell. If adding a cell object 
    /// to the pool would cause the number of objects for that cell to exceed this max, that object is destroyed instead.
    /// <para>Set this to the lowest possible value you can, as the larger the number, the more memory is allocated up front to store the object references.</para></inspector>
    [AddComponentMenu("Dynamic Loading Kit/Sub Controllers/Pooling Primary Cell Object Controller")]
	public sealed class PoolingPrimaryCellObjectSubController : PrimaryCellObjectSubController
	{		
        [SerializeField]
        internal int maxObjectsInPool = 1;

        /// <summary>
        /// Creates a new PoolingPrimaryCellObjectSubControllerUser, which is a custom type which derives 
        /// from PrimaryCellObjectSubControllerUser. This user object contains an object pool used specifically by this class.
        /// </summary>
        /// <param name="cellObjectGroup" type="ICellObjectGroup" link="ICellObjectGroup.html">
        /// The cell object group being registered.
        /// </param>
        /// <param name="loaderID" type="int">
        /// The loaderID assigned to the sub controller when it registered with the Cell Object Loader it is using.
        /// </param>
        /// <displayName id = "CreateNewUser">CreateNewUser(ICellObjectGroup, int)</displayName>
        /// <syntax>protected sealed override PrimaryCellObjectSubControllerUser CreateNewUser(ICellObjectGroup cellObjectGroup, int loaderID)</syntax>
        /// <returns type = "PrimaryCellObjectSubControllerUser">A new user object created using the worldAssociatedWithUser as input.</returns>
        protected sealed override PrimaryCellObjectSubControllerUser CreateNewUser(ICellObjectGroup cellObjectGroup, int loaderID)
        {
 	         int poolSize = 1;

             if (cellObjectGroup.World.AreRowsEndless || cellObjectGroup.World.AreColumnsEndless ||
                 (cellObjectGroup.World.WorldGrid.worldType == WorldType.Three_Dimensional && cellObjectGroup.World.AreLayersEndless))
             {
                 poolSize = maxObjectsInPool;
             }

             return new PoolingPrimaryCellObjectSubControllerUser(cellObjectGroup, loaderID, poolSize);
        }

        /// <summary>
        /// Attaches the objects associated with the input cells to the cells in a single frame. Looks for the objects in the pool first, and if not found, loads the 
        /// objects into the scene via the Cell Object Loader.
        /// <para>Note that T must implement the <see cref="IAttachableWorldCell" href = "IAttachableWorldCell.html">IAttachableWorldCell</see> interface.</para>
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be attached.</param>
        /// <param name="primaryCellObjectSubControllerID" type="int">The ID of the user requesting the attachment.</param>
        /// <displayName id="AttachCellObjectsToCellsInSingleFrame">AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override void AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID)</syntax>
        public sealed override void AttachCellObjectsToCellsInSingleFrame<T>(List<T> cells, int primaryCellObjectSubControllerID)
        {
            PoolingPrimaryCellObjectSubControllerUser user = (PoolingPrimaryCellObjectSubControllerUser)RegisteredUsers[primaryCellObjectSubControllerID];
            for (int i = cells.Count - 1; i >= 0; i--)
            {
                GameObject gameObject;
                if (user.Pool[cells[i].CellOnWorldGrid].TryGetObjectFromPool(out gameObject))
                {
                    cells[i].AttachCellObjectToCell(gameObject, false);
                    gameObject.SetActive(true);
                    cells.RemoveAt(i);
                }
            }

            if (cells.Count > 0)
                cellObjectLoader.AttachCellObjectsToCellsInSingleFrame<T>(cells, user.LoaderID);
        }

        /// <summary>
        /// Attaches the objects associated with the input cells to the cells over a period of frames. Looks for the objects 
        /// in the pool first, and if not found, has the Cell Object Loader load them into the scene.
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be attached.</param>
        /// <param name="primaryCellObjectSubControllerID" type = "int">The ID of the user requesting the attachment.</param>
        /// <displayName id = "AttachCellObjectsToCells">AttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override IEnumerator&lt;YieldInstruction&gt; AttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public sealed override IEnumerator<YieldInstruction> AttachCellObjectsToCells<T>(List<T> cells, int primaryCellObjectSubControllerID)
        {
            PoolingPrimaryCellObjectSubControllerUser user = (PoolingPrimaryCellObjectSubControllerUser)RegisteredUsers[primaryCellObjectSubControllerID];
            for (int i = cells.Count - 1; i >= 0; i--)
            {
                GameObject gameObject;
                if (user.Pool[cells[i].CellOnWorldGrid].TryGetObjectFromPool(out gameObject))
                {
                    cells[i].AttachCellObjectToCell(gameObject, false);
                    gameObject.SetActive(true);
                    cells.RemoveAt(i);
                }
            }

            if (cells.Count > 0)
            {
                IEnumerator<YieldInstruction> e = cellObjectLoader.LoadAndAttachCellObjectsToCells<T>(cells, user.LoaderID);
                while (e.MoveNext())
                    yield return e.Current;
            }
        }

        /// <summary>
        /// Detaches and pools the objects associated with the input cells over a period of frames. If there is not enough room 
        /// in the pool for an object, it is destroyed instead.
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="deactivatedCells" type = "List&lt;T&gt;">The cells whose objects need to be detached and processed.</param>
        /// <param name="primaryCellObjectSubControllerID" type = "int">The ID of the user requesting the detachment and processing.</param>
        /// <displayName id = "DetachAndProcessCellObjectsFromDeactivatedCells">DetachAndProcessCellObjectsFromDeactivatedCells&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override IEnumerator&lt;YieldInstruction&gt; DetachAndProcessCellObjectsFromDeactivatedCells&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public sealed override IEnumerator<YieldInstruction> DetachAndProcessCellObjectsFromDeactivatedCells<T>(List<T> deactivatedCells, int primaryCellObjectSubControllerID)
        {
            PoolingPrimaryCellObjectSubControllerUser user = (PoolingPrimaryCellObjectSubControllerUser)RegisteredUsers[primaryCellObjectSubControllerID];

            int count = deactivatedCells.Count;
            bool somethingDestroyed = false;

            foreach(T cell in deactivatedCells)
            {
                GameObject gameObject = cell.DetachCellObjectFromCell();
                if (!user.Pool[cell.CellOnWorldGrid].TryAddObjectToPool(gameObject))
                {
                    somethingDestroyed = true;

                    if (cellObjectDestroyer != null)
                    {
                        IEnumerator<YieldInstruction> destroyEnumerator = cellObjectDestroyer.DestroyCellObject(cell.DetachCellObjectFromCell());
                        while (destroyEnumerator.MoveNext())
                            yield return destroyEnumerator.Current;

                        if (YieldForTime != null)
                            yield return YieldForTime;
                    }
                    else
                    {
#if !UNITY_4 && !UNITY_5_3_5
                        GameObject cellObject = cell.DetachCellObjectFromCell();
                        Scene sceneCellBelongsTo = cellObject.scene;
                        //indicates the user is using scene loading (rather than say, prefab loading), as the scene name 
                        //would be different if not.
                        if (sceneCellBelongsTo.name == cellObject.name)
                        {
                            yield return SceneManager.UnloadSceneAsync(sceneCellBelongsTo);
                        }
                        else
                            Destroy(cellObject);
#else
                        Destroy(cell.DetachCellObjectFromCell());
                        if (YieldForTime != null)
                            yield return YieldForTime;
#endif
                    }


                }
            }

            if (somethingDestroyed)
                ApplyMemoryFreeingStrategy();

            yield break;
        }

        class PoolingPrimaryCellObjectSubControllerUser : PrimaryCellObjectSubControllerUser
        {
            public IGridPool<GameObject> Pool { get; private set; }

            public PoolingPrimaryCellObjectSubControllerUser(ICellObjectGroup cellObjectGroup, int loaderID, int poolSize)
                : base(cellObjectGroup, loaderID)
            {
                WorldGridBase worldGrid = cellObjectGroup.World.WorldGrid;
                if (worldGrid.WorldType == WorldType.Three_Dimensional)
                    Pool = new GridPool3D<GameObject>(worldGrid.Layers, worldGrid.Rows, worldGrid.Columns, poolSize);
                else
                    Pool = new GridPool2D<GameObject>(worldGrid.Rows, worldGrid.Columns, poolSize);
            }
        }
	}
}