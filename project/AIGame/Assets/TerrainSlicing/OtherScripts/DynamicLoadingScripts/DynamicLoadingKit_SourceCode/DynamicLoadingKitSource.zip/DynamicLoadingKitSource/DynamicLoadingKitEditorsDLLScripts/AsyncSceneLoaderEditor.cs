//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
	using UnityEditor;
	using UnityEngine;
	using DynamicLoadingKit;

    internal class AsyncSceneLoaderBaseEditor : BaseSceneLoaderBaseEditor
	{
        public AsyncSceneLoaderBaseEditor(SerializedObject serializedObject)
            : base(serializedObject){ }
		
		protected sealed override void DrawInspector()
		{
            helper.DrawSerializedPropertyField("loadPriority", loadPriorityLabel);
            base.DrawInspector();
		}

        GUIContent loadPriorityLabel = new GUIContent("Load Priority*", "This controls how fast " +
				"the objects load into your game. A lower value will increase the time it takes to load a new object, " +
				"but might have less of an impact on framerate.\n\nExperiment to find the best value that works with your game.");
	}

    [CustomEditor(typeof(AsyncSceneLoader))]
    class AsyncSceneLoaderEditor : Editor
    {
        AsyncSceneLoaderBaseEditor baseEditor;

        public override void OnInspectorGUI()
        {
            if (baseEditor == null)
                baseEditor = new AsyncSceneLoaderBaseEditor(serializedObject);
            
            baseEditor.OnInspectorGUI();
        }
    }
}