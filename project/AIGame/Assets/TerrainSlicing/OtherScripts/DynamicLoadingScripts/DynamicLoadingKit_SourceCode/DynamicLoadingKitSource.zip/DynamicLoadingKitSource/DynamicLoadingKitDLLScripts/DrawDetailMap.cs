﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using UnityEngine;

    [AddComponentMenu("Terrain Slicing Kit/Draw Detail Map")]
    public class DrawDetailMap : MonoBehaviour
    {
        [SerializeField]
        Vector3[] points;

        [SerializeField]
        bool justStarted = true;

        [SerializeField]
        float y = 0;

        [SerializeField]
        Color mapColor = Color.white;

        [SerializeField]
        bool drawMap = true;

        void Awake()
        {
            Destroy(this);
        }
    }
}