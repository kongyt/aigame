﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
using System.IO;
using UnityEngine;
using UnityEditor;

public class CreatePrefabs : EditorWindow
{
    static string path = "/TerrainSlicing/Resources";

    //User options/fields
    GameObject[] objectsToPrefabricate;
    bool overwrite;

    bool showFoldout;

    GameObject[] objectSelections;

    //Used for the object selection function
    bool filling, needToSelect;
    private int size1, size2;

    //used for scrolling when the list of objects becomes too long to fit in the editor window
    Vector2 scrollPosition;


    [MenuItem("Assets/Dynamic Loading Kit/Create Prefabs")]
    static void ShowWindow()
    {
        var window = EditorWindow.GetWindow<CreatePrefabs>();
        window.position = new Rect(Screen.width / 2 + 300, 400, 600, 300);
    }

    void OnEnable()
    {
        minSize = new Vector2(600, 395);

        if (!Application.isPlaying)
        {
            showFoldout = true;
            size1 = 2;
            size2 = 2;

            overwrite = false;
            filling = false;
            needToSelect = true;

            objectsToPrefabricate = new GameObject[size1 * size2];

            if (!PlayerPrefs.HasKey("Prefab Save Path"))
            {
                PlayerPrefs.SetString("Prefab Save Path", "/Resources");
                path = "/TerrainSlicing/Resources";
            }
            else
                path = PlayerPrefs.GetString("Prefab Save Path");
        }
    }

    void Update()
    {
        if (Application.isPlaying)
        {
            EditorUtility.DisplayDialog("Error", "The Prefab Creation Tool cannot operate in play mode. Exit play mode and reselect Create Prefab Option.", "Close");
            this.Close();
        }
    }

    //Our GUI
    void OnGUI()
    {
        GUILayout.Label("Configuration", EditorStyles.boldLabel);

        path = EditorGUILayout.TextField(pathToSavePrefabsLabel, path);
        EditorGUILayout.HelpBox("Example : To save in Assets/Resources folder type /Resources", MessageType.Info);
        if (GUILayout.Button("Set this path as Default Prefab Save Path"))
            SavePath();
        overwrite = EditorGUILayout.Toggle(overwritePrefabsLabel, overwrite);
        showFoldout = EditorGUILayout.Foldout(showFoldout, objectsToConvertLabel);

        if (showFoldout)
        {
            if (GUILayout.Button(fillFromSelectionsButtonLabel))
                filling = true;

            if (filling)
                needToSelect = FillOtherSelections();

            if (objectsToPrefabricate.Length != size1 * size2)
            {
                var tempArray = new GameObject[size1 * size2];
                for (int i = 0; i < size1 * size2; i++)
                    if (objectsToPrefabricate.Length > i)
                        tempArray[i] = objectsToPrefabricate[i];

                objectsToPrefabricate = tempArray;
            }
            scrollPosition = GUILayout.BeginScrollView(scrollPosition, GUILayout.Width(590), GUILayout.Height(175));
            for (int i = 0; i < objectsToPrefabricate.Length; i++)
                objectsToPrefabricate[i] = EditorGUILayout.ObjectField("Object " + (i + 1), objectsToPrefabricate[i], typeof(GameObject), true) as GameObject;
            GUILayout.EndScrollView();
        }

        if (GUILayout.Button("Create Prefabs"))
        {
            CreateOtherPrefabs();
            this.Close();
        }
    }


    bool FillOtherSelections()
    {
        if (needToSelect)
        {
            objectSelections = Selection.gameObjects;
            if (objectSelections.Length != objectsToPrefabricate.Length)
            {
                size1 = 1;
                size2 = objectSelections.Length;
                return false;
            }
        }

        if (objectSelections.Length != objectsToPrefabricate.Length)
        {
            this.ShowNotification(new GUIContent("An unknown error occured that really shouldn't have occured. Please contact me immediately!"));
            GUIUtility.keyboardControl = 0; // Added to shift focus to original window rather than the notification
            filling = false;
            return true;
        }

        for (int x = 0; x < objectsToPrefabricate.Length; x++)
            objectsToPrefabricate[x] = objectSelections[x];

        System.Array.Clear(objectSelections, 0, objectSelections.Length);
        filling = false;
        return true;

    }

    void CreateOtherPrefabs()
    {
        var pathToSave = Application.dataPath + path;
        if (!Directory.Exists(pathToSave))
            Directory.CreateDirectory(pathToSave);

        pathToSave = "Assets" + path;
        if (pathToSave[pathToSave.Length - 1] != '/')
            pathToSave = pathToSave + "/";

        if (!overwrite)
        {
            for (int x = 0; x < objectsToPrefabricate.Length; x++)
            {
                if (objectsToPrefabricate[x] != null)
                {
                    if (AssetDatabase.LoadAssetAtPath(pathToSave + objectsToPrefabricate[x].name + ".prefab", typeof(GameObject)))
                    {
                        if (EditorUtility.DisplayDialog("Are you sure?", "The " + objectsToPrefabricate[x].name + " prefab already exists. Do you want to overwrite it?", "Yes", "No"))
                            PrefabUtility.ReplacePrefab(objectsToPrefabricate[x], AssetDatabase.LoadAssetAtPath(pathToSave + objectsToPrefabricate[x].name + ".prefab", typeof(GameObject)), ReplacePrefabOptions.ConnectToPrefab);
                    }
                    else
                        PrefabUtility.CreatePrefab(pathToSave + objectsToPrefabricate[x].name + ".prefab", objectsToPrefabricate[x], ReplacePrefabOptions.ConnectToPrefab);

                    objectsToPrefabricate[x] = null;
                    UnloadUnusedAssets();
                    System.GC.Collect();
                }
            }
        }
        else
        {
            for (int x = 0; x < objectsToPrefabricate.Length; x++)
            {
                if (objectsToPrefabricate[x] != null)
                {
                    if (AssetDatabase.LoadAssetAtPath(pathToSave + objectsToPrefabricate[x].name + ".prefab", typeof(GameObject)))
                        PrefabUtility.ReplacePrefab(objectsToPrefabricate[x], AssetDatabase.LoadAssetAtPath(pathToSave + objectsToPrefabricate[x].name + ".prefab", typeof(GameObject)), ReplacePrefabOptions.ConnectToPrefab);
                    else
                        PrefabUtility.CreatePrefab(pathToSave + objectsToPrefabricate[x].name + ".prefab", objectsToPrefabricate[x], ReplacePrefabOptions.ConnectToPrefab);

                    objectsToPrefabricate[x] = null;
                    UnloadUnusedAssets();

                    System.GC.Collect();
                }
            }
        }
    }

    void UnloadUnusedAssets()
    {
#if UNITY_4
                EditorUtility.UnloadUnusedAssets();
#else
        EditorUtility.UnloadUnusedAssetsImmediate();
#endif
    }


    void SavePath()
    {
        PlayerPrefs.SetString("Prefab Save Path", path);
    }

    GUIContent pathToSavePrefabsLabel = new GUIContent("Save Prefabs @ File Path :", "This is the " +
            "location you wish to save the prefabs in, in relation to the Assets folder. If this directory doesn't " +
            "exist, it will be created.");

    GUIContent overwritePrefabsLabel = new GUIContent("Overwrite Prefabs", "Check this if you wish " +
            "to automatically overwrite existing prefabs when the program tries to create a prefab of the same name " +
            "as one that already exist.\n\nIf left unchecked, the program will bring up a warning message for each " +
            "object that will overwrite an existing prefab, and you can choose to skip prefab generation for that " +
            "object if you don't wish for the existing prefab to be overwritten.");

    GUIContent objectsToConvertLabel = new GUIContent("Objects to Convert", "Fill the fields below " +
            "with the objects you wish to turn into prefabs.\n\nAlternatively, you can select the objects you wish to " +
            "turn into prefabs in the hierarchy, and press the 'Fill From Selections' button to have the script try and " +
            "automatically fill these fields in for you.");

    GUIContent fillFromSelectionsButtonLabel = new GUIContent("Fill From Selections", "Press this button " +
            "to fill the fields below with the selected game objects in the Hierarchy.");

}