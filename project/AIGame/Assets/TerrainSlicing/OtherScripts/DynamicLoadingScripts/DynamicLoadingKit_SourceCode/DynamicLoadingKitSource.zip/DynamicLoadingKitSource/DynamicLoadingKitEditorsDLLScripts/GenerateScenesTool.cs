//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
	using UnityEditor;
	using UnityEngine;

    internal class SceneGenerationTool : EditorWindow
	{
        [MenuItem("Assets/Dynamic Loading Kit/Generate Scenes [Obsolete]")]
        internal static void ShowWindow()
        {
            SceneGenerationTool window = (SceneGenerationTool)EditorWindow.GetWindow(typeof(SceneGenerationTool));
            window.position = new Rect(Screen.width / 2 + 300, 400, 600, 320);
        }

        bool isError;
		
		void OnEnable()
		{
			minSize = new Vector2(650,440);
			
			if(Application.isPlaying)
				isError = true;
			else
				isError = false;
		}
		
		void OnUpdate()
		{
			if(Application.isPlaying)
			{
				isError = true;
				EditorUtility.DisplayDialog("Error", "The Create Scenes Tool cannot operate in play mode. Exit play mode and reselect Create Scenes Option.", "Close");
				this.Close();
			}
		}
		
		void OnGUI()
		{
			if(!isError)
			{
                EditorGUILayout.HelpBox("The Scene Generation Tool is no longer used. To generate scenes, create a Scene Generation File instead. There are three ways to do this:\n\n1) Click the button below. This will generate a file in whatever folder you have selected, or the root Assets folder if no folder is selected.\n\n2) Right click a folder and choose Dynamic Loading Kit -> Create Scene Generation File\n\n3) Select a folder and in the main Unity menu choose Assets -> Dynamic Loading Kit -> Create Scene Generation File. If no folder is selected the file will be placed in the root Assets folder.", MessageType.Warning);

                if (GUILayout.Button("Create Scene Generation File"))
                    SceneGenerationFileEditor.CreateSceneGenerationFile();
            }
		}
    }
}