//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;
	using System.Collections.Generic;
    using System.Collections.ObjectModel;
    #if !UNITY_4
    using UnityEngine.SceneManagement;
    #endif

    /// <summary>
    /// Provides an implementation for a Primary Cell Object Sub Controller that destroys cell objects when they are not needed.
    /// </summary>
    /// <title>NonPoolingPrimaryCellObjectSubController Class</title>
    /// <category>Sub Controllers</category>
    /// <navigationName>NonPoolingPrimaryCellObjectSubController</navigationName>
    /// <fileName>NonPoolingPrimaryCellObjectSubController.html</fileName>
    /// <syntax>public sealed class NonPoolingPrimaryCellObjectSubController : <see cref="PrimaryCellObjectSubController" href="PrimaryCellObjectSubController.html">PrimaryCellObjectSubController</see></syntax>
	[AddComponentMenu("Dynamic Loading Kit/Sub Controllers/Non Pooling Primary Cell Object Sub Controller")]
	public sealed class NonPoolingPrimaryCellObjectSubController : PrimaryCellObjectSubController
	{
        /// <summary>
        /// Attaches the objects associated with the input cells to the cells in a single frame. The objects are first loaded by the 
        /// Cell Object Loader associated with the sub controller.
        /// <para>Note that T must implement the <see cref="IAttachableWorldCell" href = "IAttachableWorldCell.html">IAttachableWorldCell</see> interface.</para>
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be attached.</param>
        /// <param name="primaryCellObjectSubControllerID" type="int">The ID of the user requesting the attachment.</param>
        /// <displayName id="AttachCellObjectsToCellsInSingleFrame">AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override void AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID)</syntax>
        public sealed override void AttachCellObjectsToCellsInSingleFrame<T>(List<T> cells, int primaryCellObjectSubControllerID)
        {
            cellObjectLoader.AttachCellObjectsToCellsInSingleFrame<T>(cells, RegisteredUsers[primaryCellObjectSubControllerID].LoaderID);
        }

        /// <summary>
        /// Attaches the objects associated with the input cells to the cells over a period of frames. Objects are first loaded by the 
        /// Cell Object Loader associated with the sub controller.
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be attached.</param>
        /// <param name="primaryCellObjectSubControllerID" type = "int">The ID of the user requesting the attachment.</param>
        /// <displayName id = "AttachCellObjectsToCells">AttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override IEnumerator&lt;YieldInstruction&gt; AttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public sealed override IEnumerator<YieldInstruction> AttachCellObjectsToCells<T>(List<T> cells, int primaryCellObjectSubControllerID)
        {
            IEnumerator<YieldInstruction> e = cellObjectLoader.LoadAndAttachCellObjectsToCells<T>(cells, RegisteredUsers[primaryCellObjectSubControllerID].LoaderID);
            while (e.MoveNext())
                yield return e.Current;
        }

        /// <summary>
        /// Detaches and destroys the objects associated with the input cells over a period of frames.
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="deactivatedCells" type = "List&lt;T&gt;">The cells whose objects need to be detached and processed.</param>
        /// <param name="primaryCellObjectSubControllerID" type = "int">The ID of the user requesting the detachment and processing.</param>
        /// <displayName id = "DetachAndProcessCellObjectsFromDeactivatedCells">DetachAndProcessCellObjectsFromDeactivatedCells&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override IEnumerator&lt;YieldInstruction&gt; DetachAndProcessCellObjectsFromDeactivatedCells&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public sealed override IEnumerator<YieldInstruction> DetachAndProcessCellObjectsFromDeactivatedCells<T>(List<T> deactivatedCells, int primaryCellObjectSubControllerID)
        {
            if (YieldForTime != null)
            {
                if (cellObjectDestroyer != null)
                {
                    foreach (T cell in deactivatedCells)
                    {
                        IEnumerator<YieldInstruction> destroyEnumerator = cellObjectDestroyer.DestroyCellObject(cell.DetachCellObjectFromCell());
                        while (destroyEnumerator.MoveNext())
                            yield return destroyEnumerator.Current;

                        if(YieldForTime != null)
                            yield return YieldForTime;
                    }
                }
                else
                {
                    foreach (T cell in deactivatedCells)
                    {
#if !UNITY_4 && !UNITY_5_3_5
                        GameObject cellObject = cell.DetachCellObjectFromCell();
                        Scene sceneCellBelongsTo = cellObject.scene;
                        //indicates the user is using scene loading (rather than say, prefab loading), as the scene name 
                        //would be different if not.
                        if (sceneCellBelongsTo.name == cellObject.name)
                        {
                            yield return SceneManager.UnloadSceneAsync(sceneCellBelongsTo);
                        }
                        else
                            Destroy(cellObject);
#else
                        Destroy(cell.DetachCellObjectFromCell());
                        yield return YieldForTime;
#endif
                    }
                }
            }
            else
            {
                if (cellObjectDestroyer != null)
                {
                    foreach (T cell in deactivatedCells)
                    {
                        IEnumerator<YieldInstruction> destroyEnumerator = cellObjectDestroyer.DestroyCellObject(cell.DetachCellObjectFromCell());
                        while (destroyEnumerator.MoveNext())
                            yield return destroyEnumerator.Current;
                    }
                }
                else
                {
                    foreach (T cell in deactivatedCells)
                    {
                        #if !UNITY_4 && !UNITY_5_3_5
                        GameObject cellObject = cell.DetachCellObjectFromCell();
                        Scene sceneCellBelongsTo = cellObject.scene;
                        //indicates the user is using scene loading (rather than say, prefab loading), as the scene name 
                        //would be different if not.
                        if (sceneCellBelongsTo.name == cellObject.name)
                        {
                            yield return SceneManager.UnloadSceneAsync(sceneCellBelongsTo);
                        }
                        else
                            Destroy(cellObject);
#else
                        Destroy(cell.DetachCellObjectFromCell());
#endif
                    }
                }
            }

            ApplyMemoryFreeingStrategy();
        }
	}
}