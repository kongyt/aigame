﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using DynamicLoadingKitEditors;
    using UnityEditor;
    using UnityEngine;
    using System;
    using System.IO;

    
    public class WorldGridBaseEditor : BaseEditor
    {
        #region Fields/Enums

        bool DisplayLayerOptions { get { return IsWorld3D; } }
        bool IsWorld3D { get { return worldTypeProperty.intValue == (int)WorldType.Three_Dimensional; } }

        int layers, rows, columns;

        string expectedPrefabFormat;
        string formatStringRow = "R{0}\n({1})", formatStringColumn = "C{0}\n({1})";
        Texture enableButtonTex, disableButtonTex;

        GUIContent[] worldTypeOptions, dataSetMethodOptions = new GUIContent[3] { setDataUsingDefaultValues, setDataUsingTextAsset, setDataUsingPrefabs };

        SerializedProperty layersProperty, layerSelectProperty, rowsProperty, rowSelectProperty, columnsProperty, columnSelectProperty, worldTypeProperty;

        SerializedProperty emptyGridLocationsProperty, rowLengthsProperty, columnWidthsProperty, layerHeightsProperty;

        string[] newDataSetOptions;
        int[] newDataSetValues;

        enum SetDataMethod { Default_Values, TextAsset, Prefabs }

        #endregion

        #region Constructor/Initialization
        public WorldGridBaseEditor(SerializedObject serializedObject) : base(serializedObject)
        {
            InitializeEditor();
            WorldGridBase worldGrid = serializedObject.targetObject as WorldGridBase;
            if (!worldGrid.DataSet)
                InitializeWorldGrid();            
        }

        void InitializeEditor()
        {
            columnsProperty = helper.GetPropertyByName("columns");
            columnSelectProperty = helper.GetPropertyByName("columnSelect");
            rowsProperty = helper.GetPropertyByName("rows");
            rowSelectProperty = helper.GetPropertyByName("rowSelect");
            layersProperty = helper.GetPropertyByName("layers");
            layerSelectProperty = helper.GetPropertyByName("layerSelect");
            worldTypeProperty = helper.GetPropertyByName("worldType");

            emptyGridLocationsProperty = helper.GetPropertyByName("emptyGridLocations");
            rowLengthsProperty = helper.GetPropertyByName("rowLengths");
            columnWidthsProperty = helper.GetPropertyByName("columnWidths");
            layerHeightsProperty = helper.GetPropertyByName("layerHeights");

            layers = layersProperty.intValue;
            rows = rowsProperty.intValue;
            columns = columnsProperty.intValue;

            enableButtonTex = (Texture2D)AssetDatabase.LoadAssetAtPath("Assets/TerrainSlicing/EditorResources/EnabledOption.png", typeof(Texture2D));
            disableButtonTex = (Texture2D)AssetDatabase.LoadAssetAtPath("Assets/TerrainSlicing/EditorResources/DisabledOption.png", typeof(Texture2D));

            SetInitialOptionData();
            UpdateNewSetDataOptions();
        }

        void SetInitialOptionData()
        {
            SetExpectedPrefabFormat();

            if (helper.GetPropertyByName("cellObjectType").intValue == (int)CellObjectType.Unity_Terrain)
                worldTypeOptions = worldTypeSingleOption;
            else
                worldTypeOptions = worldTypeThreeOptions;
        }

        /// <summary>
        /// Initializes the World Grid, which initializes some arrays and cell object preview fields so they 
        /// work properly.
        /// </summary>
        public void InitializeWorldGrid()
        {
            serializedObject.Update();
            SaveAndRebuildArrays((WorldType)worldTypeProperty.intValue, rowsProperty.intValue, columnsProperty.intValue, layersProperty.intValue);
            InitializeObjectPreviewFields();
            serializedObject.ApplyModifiedProperties();
        }

        

        void SaveAndRebuildArrays(WorldType newWorldType, int newNumRows, int newNumColumns, int newNumLayers)
        {
            SaveAndRebuildEmptyGridLocations(newNumRows, newNumColumns, newNumLayers);
            SaveAndRebuildDimensionsArray(rowsProperty.intValue, newNumRows, rowLengthsProperty);
            SaveAndRebuildDimensionsArray(columnsProperty.intValue, newNumColumns, columnWidthsProperty);

            if (newWorldType != WorldType.Three_Dimensional)
                layerHeightsProperty.arraySize = 0;
            else
                SaveAndRebuildDimensionsArray(layersProperty.intValue, newNumLayers, layerHeightsProperty);

            VerifyRowAndColumnSelect(newNumRows, newNumColumns);
        }

        void SaveAndRebuildEmptyGridLocations(int newNumRows, int newNumColumns, int newNumLayers)
        {
            emptyGridLocationsProperty.RebuildBoolArrayForNewWorldDimensions(false, newNumLayers, newNumRows, newNumColumns, layersProperty.intValue, rowsProperty.intValue, columnsProperty.intValue);
        }

        void SaveAndRebuildDimensionsArray(int oldDimensionsArrayLength, int newDimensionsArrayLength, SerializedProperty arrProperty)
        {
            if (arrProperty.arraySize != 0)
            {
                //if the dimensions array is of length 1, then no change is needed, since any additional values would just be the 
                //same as the single value already being stored.
                if (arrProperty.arraySize != 1 && oldDimensionsArrayLength != newDimensionsArrayLength)
                {
                    if (newDimensionsArrayLength > oldDimensionsArrayLength)
                    {
                        float avgRowLength = arrProperty.ComputeAverage();
                        arrProperty.arraySize = newDimensionsArrayLength;

                        for (int i = oldDimensionsArrayLength; i < arrProperty.arraySize; i++)
                            arrProperty.GetArrayElementAtIndex(i).floatValue = avgRowLength;
                    }
                    else
                        arrProperty.arraySize = newDimensionsArrayLength;

                    if (arrProperty.AreAllFlaotValuesTheSame())
                        arrProperty.arraySize = 1;
                }
            }
            else
            {
                arrProperty.arraySize = 1;
                arrProperty.GetArrayElementAtIndex(0).floatValue = 500f;
            }
        }

        void VerifyRowAndColumnSelect(int newNumRows, int newNumColumns)
        {
            int lastValidRowSelect = newNumRows - 4;
            if (lastValidRowSelect < 0)
                lastValidRowSelect = 0;
            else if (rowSelectProperty.intValue > lastValidRowSelect)
                rowSelectProperty.intValue = lastValidRowSelect;

            int lastValidColumnSelect = newNumColumns - 4;
            if (lastValidColumnSelect < 0)
                lastValidColumnSelect = 0;
            else if (columnSelectProperty.intValue > lastValidColumnSelect)
                columnSelectProperty.intValue = lastValidColumnSelect;
        }

        void InitializeObjectPreviewFields()
        {
            UpdateAllObjectsRangeTemplate();
        }

        void UpdateAllObjectsRangeTemplate()
        {
            SerializedProperty rangeTemplatesProperty = helper.GetPropertyByName("rangeTemplates");
            SerializedProperty allObjectsRange;
            if (rangeTemplatesProperty.arraySize == 0)
            {
                rangeTemplatesProperty.InsertArrayElementAtIndex(0);
                allObjectsRange = rangeTemplatesProperty.GetArrayElementAtIndex(0);
                allObjectsRange.FindPropertyRelative("name").stringValue = "Load All Objects";
            }
            else
                allObjectsRange = rangeTemplatesProperty.GetArrayElementAtIndex(0);

            SetRangeToMax(allObjectsRange);
        }

        void SetRangeToMax(SerializedProperty range)
        {
            WorldGridBase worldGrid = helper.SerializedObject.targetObject as WorldGridBase;
            if (worldGrid.namingConvention != null && worldGrid.namingConvention.NumberingStartsAt0)
            {
                range.FindPropertyRelative("firstLayer").intValue = 0;
                range.FindPropertyRelative("firstRow").intValue = 0;
                range.FindPropertyRelative("firstColumn").intValue = 0;
                range.FindPropertyRelative("lastLayer").intValue = worldGrid.Layers - 1;
                range.FindPropertyRelative("lastRow").intValue = worldGrid.Rows - 1;
                range.FindPropertyRelative("lastColumn").intValue = worldGrid.Columns - 1;
            }
            else
            {
                range.FindPropertyRelative("firstLayer").intValue = 1;
                range.FindPropertyRelative("firstRow").intValue = 1;
                range.FindPropertyRelative("firstColumn").intValue = 1;
                range.FindPropertyRelative("lastLayer").intValue = worldGrid.Layers;
                range.FindPropertyRelative("lastRow").intValue = worldGrid.Rows;
                range.FindPropertyRelative("lastColumn").intValue = worldGrid.Columns;
            }
        }
        #endregion

        #region GUI Drawing

        protected sealed override void DrawInspector()
        {

            DrawDefaultGroupNameOption();
            DrawNamingConventionOption();
            EditorGUILayout.HelpBox(expectedPrefabFormat, MessageType.Info);
            DrawCellObjectTypeOption();
            DrawWorldTypeOption();

            EditorGUILayout.HelpBox("The current number of layers, rows, and columns is shown in the the parentheses to the right of each label. To change these values, enter a new value in the appropriate field and click on the button below the field.", MessageType.Info);

            if (DisplayLayerOptions)
                DrawNumberOfLayersOption();

            DrawNumberOfRowsOption();
            DrawNumberOfColumnsOption();

            EditorGUILayout.Space();

            DrawGridHelpInfo();
            DrawGrid();
            EditorGUILayout.Space();
            
            if (helper.DrawSerializedPropertyFoldoutField("showNewDataSetFoldout", "New Data Set Methods"))
                DrawNewSetDataConfigurationOptions();

            EditorGUILayout.Space();
            if (helper.DrawSerializedPropertyFoldoutField("showOldDataSetFoldout", "Old Data Set Methods"))
                DrawOldSetDataConfigurationOptions();
            
            EditorGUILayout.Space();
            DrawPositionOffsetOption();
        }

        void DrawDefaultGroupNameOption()
        {
            bool changed;
            SerializedProperty prop = helper.GetPropertyByName("gridName");
            helper.DrawSerializedPropertyField(prop, gridNameLabel, out changed);
            if (changed)
                OnGridNameChanged(prop.stringValue);
        }

        void DrawNamingConventionOption()
        {
            bool changed;
            SerializedProperty prop = helper.GetPropertyByName("namingConvention");
            helper.DrawSerializedPropertyField(prop, SharedLabels.namingConventionLabel, out changed);

            if (changed)
                OnNamingConventionChanged(prop.objectReferenceValue as NamingConvention);
        }

        void DrawCellObjectTypeOption()
        {
            bool changed;
            SerializedProperty prop = helper.GetPropertyByName("cellObjectType");
            helper.DrawSerializedPropertyField(prop, cellObjectTypeLabel, out changed);

            if (changed)
                OnCellObjectTypeChanged((CellObjectType)prop.intValue);
        }

        void DrawWorldTypeOption()
        {
            WorldType oldWorldType = (WorldType)worldTypeProperty.intValue;

            bool changed;
            helper.DrawSerializedPropertyPopupField(worldTypeProperty, worldTypeLabel, worldTypeOptions, out changed);
            
            if (changed)
                OnWorldTypeChanged((WorldType)worldTypeProperty.intValue, oldWorldType);
        }

        void DrawNumberOfLayersOption()
        {
            GUIContent layersLabel = new GUIContent(string.Format("Layers* ({0})", layersProperty.intValue), "The number of cells on the grids Y Axis.\n\nThis option is not available when using Unity Terrains or any other 2D world.");
            layers = EditorGUILayout.IntField(layersLabel, layers);
            
            if (layers < 1)
                layers = 1;

            if (!playMode && GUILayout.Button("Update Number of Layers") && layers != layersProperty.intValue)
            {
                SaveAndRebuildArrays((WorldType)worldTypeProperty.intValue, rowsProperty.intValue, columnsProperty.intValue, layers);
                layersProperty.intValue = layers;
            }
        }

        void DrawNumberOfRowsOption()
        {
            GUIContent rowsLabel = new GUIContent(string.Format("Rows* ({0})", rowsProperty.intValue), "The number of cells on either the grids Z or Y Axis (depending on the World Type).");
            rows = EditorGUILayout.IntField(rowsLabel, rows);
            if (rows < 1)
                rows = 1;

            if (!playMode && GUILayout.Button("Update Number of Rows") && rows != rowsProperty.intValue)
            {
                SaveAndRebuildArrays((WorldType)worldTypeProperty.intValue, rows, columnsProperty.intValue, layersProperty.intValue);
                rowsProperty.intValue = rows;
            }
        }

        void DrawNumberOfColumnsOption()
        {
            GUIContent columnsLabel = new GUIContent(string.Format("Columns* ({0})", columnsProperty.intValue), "The number of cells on the grids X Axis.");
            columns = EditorGUILayout.IntField(columnsLabel, columns);
            if (columns < 1)
                columns = 1;

            if (!playMode && GUILayout.Button("Update Number of Columns") && columns != columnsProperty.intValue)
            {
                SaveAndRebuildArrays((WorldType)worldTypeProperty.intValue, rowsProperty.intValue, columns, layersProperty.intValue);
                columnsProperty.intValue = columns;
            }
        }

        void DrawGridHelpInfo()
        {
            if (helper.DrawSerializedPropertyFoldoutField("showGridHelpFoldout", "Helpful Info (Click to Expand)"))
            {
                EditorGUILayout.HelpBox("The grid below is a visual representation of your World Grid. The left most columns represents each row in the grid (R1, R2, etc.), while the bottom most row represents each column (C1, C2, etc.).\n\nEach row or column has a value in parentheses. This is the row length or column width of that row/column, which can be changed via the options below the grid.\n\nEach cell in the grid is represented by either a red or green square. A green square denotes that the cell in question is not empty, i.e., that it has a valid terrain/object associated with it. A red square denotes an empty cell.", MessageType.Info, true);

                EditorGUILayout.HelpBox("You can change a single cell from empty to not empty or vice versa by clicking on it. You can also change the designation of an entire row or column by clicking on the button for that row or column (R1, C2, etc.).\n\nWhen using a 3D world, you can change the designation for every cell in a single layer by pressing the 'Change All Cells In Layer' button. Finally, you can change the designation of every cell in the grid by pressing the 'Change Designation of All Cells In Grid' button.\n\nChanging the designation of an entire row, column, layer, grid works by examining the row/column/layer/grid and finding if any cells are empty. If one or more cells are empty, their designation is changed to not empty and all other cells are left alone (resulting in a row/column/layer/grid with all cells set to not empty). If no cells are found to be empty (i.e., all cells are marked as not empty), then all cells in that row, column, layer, or grid are changed to empty (red squares).", MessageType.Info, true);

                EditorGUILayout.HelpBox("Also note that this grid ignores whatever Naming Convention you are using, so if your actual group begins at 0 instead of 1, you will need to take that into account (simply add 1 to the row/column/layer of your game object to get the equivalent row/column/layer in the grid.", MessageType.Info, true);
            }
        }

        void DrawGrid()
        {
            if (DisplayLayerOptions)
            {
                layerSelectProperty.intValue = EditorGUILayout.IntSlider("Layer", layerSelectProperty.intValue + 1, 1, layersProperty.intValue) - 1;

                int layerHeightsIndex = layerHeightsProperty.arraySize == 1 ? 0 : layerSelectProperty.intValue;
                EditorGUILayout.LabelField(string.Format("Layer {0} Height: {1}", layerSelectProperty.intValue + 1, layerHeightsProperty.GetArrayElementAtIndex(layerHeightsIndex).floatValue));
            }

            if (DisplayLayerOptions)
                DisplayArray(layerSelectProperty.intValue);
            else
                DisplayArray(0);
        }

        void DisplayArray(int layer)
        {
            GUIStyle style = new GUIStyle(GUI.skin.button);
            style.fixedHeight = 60f;
            style.fixedWidth = 60f;

            GUIStyle emptyStyle = new GUIStyle(style);
            emptyStyle.fixedHeight = 20f;
            emptyStyle.normal.background = null;
            emptyStyle.active.background = null;
            emptyStyle.normal.background = null;
            emptyStyle.normal.background = null;

            if (columnsProperty.intValue > 4)
            {
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button(" ", emptyStyle))
                {

                }
                
                columnSelectProperty.intValue = (int)GUILayout.HorizontalScrollbar(columnSelectProperty.intValue, 1f, 0f, columnsProperty.intValue - 3, GUILayout.Width(252f));
                EditorGUILayout.EndHorizontal();
            }

            int startingRow = rowSelectProperty.intValue + 3;
            if (startingRow >= rowsProperty.intValue)
                startingRow = rowsProperty.intValue - 1;

            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.BeginVertical(GUILayout.Width(60f));
            for (int row = startingRow; row >= rowSelectProperty.intValue; row--)
            {
                int rowIndex = rowLengthsProperty.arraySize == 1 ? 0 : row;
                if (GUILayout.Button(string.Format(formatStringRow, row + 1, rowLengthsProperty.GetArrayElementAtIndex(rowIndex).floatValue), style))
                {
                    if(!playMode)
                    {
                        if (IsRowAllFalse(row, layer))
                            SetRow(true, row, layer);
                        else
                            SetRow(false, row, layer);
                    }                    
                }
            }

            if (GUILayout.Button(layerButton, style))
            {
                if (!playMode)
                {
                    if (IsLayerAllFalse(layer))
                        SetLayer(true, layer);
                    else
                        SetLayer(false, layer);
                }
            }

            EditorGUILayout.EndVertical();

            for (int column = columnSelectProperty.intValue; column <= columnSelectProperty.intValue + 3 && column < columnsProperty.intValue; column++)
            {
                EditorGUILayout.BeginVertical(GUILayout.Width(60f));
                for (int row = startingRow; row >= rowSelectProperty.intValue; row--)
                {
                    int index = emptyGridLocationsProperty.arraySize == 1 ? 0 : column + (row * columnsProperty.intValue) + (rowsProperty.intValue * columnsProperty.intValue * layer);

                    if (!emptyGridLocationsProperty.GetArrayElementAtIndex(index).boolValue)
                    {
                        if (GUILayout.Button(enableButtonTex, style))
                        {
                            if (!playMode)
                            {
                                if (emptyGridLocationsProperty.arraySize == 1)
                                {
                                    emptyGridLocationsProperty.ResizeBoolArrayAndSetAllValuesToSingleValue(rowsProperty.intValue * columnsProperty.intValue * layersProperty.intValue, false);

                                    index = column + (row * columnsProperty.intValue) + (rowsProperty.intValue * columnsProperty.intValue * layer);
                                    emptyGridLocationsProperty.GetArrayElementAtIndex(index).boolValue = true;
                                }
                                else
                                {
                                    emptyGridLocationsProperty.GetArrayElementAtIndex(index).boolValue = true;
                                    //check if all values are the same now that this cell was changed
                                    if (emptyGridLocationsProperty.DoAllBoolValuesMatchInputVaue(true))
                                    {
                                        emptyGridLocationsProperty.arraySize = 1;
                                        emptyGridLocationsProperty.GetArrayElementAtIndex(0).boolValue = true;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if (GUILayout.Button(disableButtonTex, style))
                        {
                            if (!playMode)
                            {
                                if (emptyGridLocationsProperty.arraySize == 1)
                                {
                                    emptyGridLocationsProperty.ResizeBoolArrayAndSetAllValuesToSingleValue(rowsProperty.intValue * columnsProperty.intValue * layersProperty.intValue, true);

                                    index = column + (row * columnsProperty.intValue) + (rowsProperty.intValue * columnsProperty.intValue * layer);

                                    //now just need to correct the cell that was changed
                                    emptyGridLocationsProperty.GetArrayElementAtIndex(index).boolValue = false;
                                }
                                else
                                {
                                    emptyGridLocationsProperty.GetArrayElementAtIndex(index).boolValue = false;
                                    //check if all values are the same now that this cell was changed
                                    if (emptyGridLocationsProperty.DoAllBoolValuesMatchInputVaue(false))
                                    {
                                        emptyGridLocationsProperty.arraySize = 1;
                                        emptyGridLocationsProperty.GetArrayElementAtIndex(0).boolValue = false;
                                    }
                                }
                            }
                        }
                    }
                }

                int columnIndex = columnWidthsProperty.arraySize == 1 ? 0 : column;
                if (GUILayout.Button(string.Format(formatStringColumn, column + 1, columnWidthsProperty.GetArrayElementAtIndex(columnIndex).floatValue), style))
                {
                    if (!playMode)
                    {
                        if (IsColumnAllFalse(column, layer))
                            SetColumn(true, column, layer);
                        else
                            SetColumn(false, column, layer);
                    }
                }
                EditorGUILayout.EndVertical();

            }

            if (rowsProperty.intValue > 4)
            {

                rowSelectProperty.intValue = (int)GUILayout.VerticalScrollbar(rowSelectProperty.intValue, 1f, rowsProperty.intValue - 3, 0f, GUILayout.Height(249f));
            }

            EditorGUILayout.EndHorizontal();
            if (GUILayout.Button(allLayersButton, GUILayout.Width(316f)))
                SetGrid(IsGridAllFalse());
        }

        void DrawPositionOffsetOption()
        {
            EditorGUILayout.LabelField("Offsets (Mouse Over Each Option for info)");
            EditorGUILayout.Space();

            SerializedProperty positionOffsetProperty = helper.GetPropertyByName("positionOffset");
            Vector3 positionOffset = positionOffsetProperty.vector3Value;
            WorldType worldType = (WorldType)worldTypeProperty.intValue;

            //always display this
            float xCellOffsetPercent = EditorGUILayout.Slider(xCellOffsetPercentLabel, positionOffset.x, 0f, 1f, GUILayout.Width(316f));

            float yCellOffsetPercent = positionOffset.y;
            float zCellOffsetPercent = positionOffset.z;

            if (worldType == WorldType.Two_Dimensional_On_XZ_Axes || worldType == WorldType.Three_Dimensional)
                zCellOffsetPercent = EditorGUILayout.Slider(zCellOffsetPercentLabel, positionOffset.z, 0f, 1f, GUILayout.Width(316f));

            if (worldType == WorldType.Two_Dimensional_On_XY_Axes || worldType == WorldType.Three_Dimensional)
                yCellOffsetPercent = EditorGUILayout.Slider(yCellOffsetPercentLabel, positionOffset.y, 0f, 1f, GUILayout.Width(316f));

            if (!Mathf.Approximately(xCellOffsetPercent, positionOffset.x)
                || !Mathf.Approximately(yCellOffsetPercent, positionOffset.y)
                || !Mathf.Approximately(zCellOffsetPercent, positionOffset.z))
            {
                positionOffsetProperty.vector3Value = new Vector3(xCellOffsetPercent, yCellOffsetPercent, zCellOffsetPercent);
            }
        }

        #endregion

        #region Methods that help in updating the grid in the inspector

        void SetRow(bool value, int row, int layer)
        {
            emptyGridLocationsProperty.SetRowInBoolArray(value, row, layer, layersProperty.intValue, rowsProperty.intValue, columnsProperty.intValue);
        }

        bool IsRowAllFalse(int row, int layer)
        {
            return emptyGridLocationsProperty.AreAllBoolsInRowEqualToValue(false, row, layer, rowsProperty.intValue, columnsProperty.intValue);
        }

        void SetColumn(bool value, int column, int layer)
        {
            emptyGridLocationsProperty.SetColumnInBoolArray(value, column, layer, layersProperty.intValue, rowsProperty.intValue, columnsProperty.intValue);
        }

        bool IsColumnAllFalse(int column, int layer)
        {
            return emptyGridLocationsProperty.AreAllBoolsInColumnEqualToValue(false, column, layer, rowsProperty.intValue, columnsProperty.intValue);
        }

        void SetLayer(bool value, int layer)
        {
            emptyGridLocationsProperty.SetLayerInBoolArray(value, layer, layersProperty.intValue, rowsProperty.intValue, columnsProperty.intValue);
        }

        bool IsLayerAllFalse(int layer)
        {
            return emptyGridLocationsProperty.AreAllBoolsInLayerEqualToValue(false, layer, rowsProperty.intValue, columnsProperty.intValue);
        }

        void SetGrid(bool value)
        {
            emptyGridLocationsProperty.arraySize = 1;
            emptyGridLocationsProperty.GetArrayElementAtIndex(0).boolValue = value;
        }

        bool IsGridAllFalse()
        {
            if (emptyGridLocationsProperty.arraySize == 1 && emptyGridLocationsProperty.GetArrayElementAtIndex(0).boolValue == false)
                return true;

            for (int i = 0; i < layersProperty.intValue; i++)
            {
                if (!IsLayerAllFalse(i))
                    return false;
            }
            return true;
        }

        #endregion

        #region Data Set Methods

        void DrawNewSetDataConfigurationOptions()
        {
            SerializedProperty dataSetChoiceProperty = helper.GetPropertyByName("newDataSetOptionsChoice");

            dataSetChoiceProperty.intValue = EditorGUILayout.IntPopup(dataSetChoiceProperty.intValue, newDataSetOptions, newDataSetValues);

            int dataSetChoice = dataSetChoiceProperty.intValue;
            SerializedProperty indexToSetProperty = helper.GetPropertyByName("indexToSet");

            if (dataSetChoice <= 2)
            {
                string label;
                int maxSliderVal;

                if (dataSetChoice == 0)
                {
                    label = "Layer To Set";
                    if(indexToSetProperty.intValue > layersProperty.intValue)
                        indexToSetProperty.intValue = layersProperty.intValue;
                    
                    maxSliderVal = layersProperty.intValue;
                }
                else if (dataSetChoice == 1)
                {
                    label = "Row To Set";
                    if(indexToSetProperty.intValue > rowsProperty.intValue)
                        indexToSetProperty.intValue = rowsProperty.intValue;
                    
                    maxSliderVal = rowsProperty.intValue;
                }
                else
                {
                    label = "Column To Set";
                    if(indexToSetProperty.intValue > columnsProperty.intValue)
                        indexToSetProperty.intValue = columnsProperty.intValue;
                    
                    maxSliderVal = columnsProperty.intValue;
                }

                int indexToSet = EditorGUILayout.IntField(label, indexToSetProperty.intValue);
                if (indexToSet < 1)
                    indexToSet = 1;
                else if (indexToSet > maxSliderVal)
                    indexToSet = maxSliderVal;

                if (indexToSet != indexToSetProperty.intValue)
                    indexToSetProperty.intValue = indexToSet;
            }

            helper.DrawSerializedPropertyField("setValue", "Value To Set");

            if (!playMode && GUILayout.Button("Set"))
                SetData();
        }

        void SetData()
        {
            SerializedProperty newDataSetOptionsChoiceProperty = helper.GetPropertyByName("newDataSetOptionsChoice");
            SerializedProperty setValueProperty = helper.GetPropertyByName("setValue");
            SerializedProperty indexToSetProperty = helper.GetPropertyByName("indexToSet");

            if (newDataSetOptionsChoiceProperty.intValue == 0)
            {
                if(layerHeightsProperty.arraySize == 1)
                    layerHeightsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(layersProperty.intValue, layerHeightsProperty.GetArrayElementAtIndex(0).floatValue);

                layerHeightsProperty.GetArrayElementAtIndex(indexToSetProperty .intValue- 1).floatValue = setValueProperty.floatValue;

                if (layerHeightsProperty.AreAllFlaotValuesTheSame())
                    layerHeightsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(1, setValueProperty.floatValue);
            }
            else if (newDataSetOptionsChoiceProperty.intValue == 1)
            {
                if (rowLengthsProperty.arraySize == 1)
                    rowLengthsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(rowsProperty.intValue, rowLengthsProperty.GetArrayElementAtIndex(0).floatValue);

                rowLengthsProperty.GetArrayElementAtIndex(indexToSetProperty.intValue - 1).floatValue = setValueProperty.floatValue;

                if (rowLengthsProperty.AreAllFlaotValuesTheSame())
                    rowLengthsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(1, setValueProperty.floatValue);
            }
            else if (newDataSetOptionsChoiceProperty.intValue == 2)
            {
                if (columnWidthsProperty.arraySize == 1)
                    columnWidthsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(columnsProperty.intValue, columnWidthsProperty.GetArrayElementAtIndex(0).floatValue);

                columnWidthsProperty.GetArrayElementAtIndex(indexToSetProperty.intValue - 1).floatValue = setValueProperty.floatValue;

                if (columnWidthsProperty.AreAllFlaotValuesTheSame())
                    columnWidthsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(1, setValueProperty.floatValue);
            }
            else if (newDataSetOptionsChoiceProperty.intValue == 3)
            {
                layerHeightsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(1, setValueProperty.floatValue);
            }
            else if (newDataSetOptionsChoiceProperty.intValue == 4)
            {
                rowLengthsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(1, setValueProperty.floatValue);
            }
            else if (newDataSetOptionsChoiceProperty.intValue == 5)
            {
                columnWidthsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(1, setValueProperty.floatValue);
            }
            else
            {
                if(worldTypeProperty.intValue == (int)WorldType.Three_Dimensional)
                    layerHeightsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(1, setValueProperty.floatValue);

                rowLengthsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(1, setValueProperty.floatValue);

                columnWidthsProperty.ResizeFloatArrayAndSetAllValuesToSingleValue(1, setValueProperty.floatValue);
            }
        }

        void UpdateNewSetDataOptions()
        {
            if(worldTypeProperty.intValue == (int)WorldType.Three_Dimensional)
            {
                newDataSetOptions = new string[7]
                {
                    "Set Single Layer Height",
                    "Set Single Row Length",
                    "Set Single Column Width",
                    "Set All Layer Heights",
                    "Set All Row Lengths",
                    "Set All Column Widths",
                    "Set All Dimensions"
                };

                newDataSetValues = new int[7] { 0, 1, 2, 3, 4, 5, 6 };
            }
            else
            {
                newDataSetOptions = new string[5]
                {
                    "Set Single Row Length",
                    "Set Single Column Width",
                    "Set All Row Lengths",
                    "Set All Column Widths",
                    "Set All Dimensions"
                };

                newDataSetValues = new int[5] { 1, 2, 4, 5, 6 };
                SerializedProperty newDataSetOptionsChoiceProperty = helper.GetPropertyByName("newDataSetOptionsChoice");
                if (newDataSetOptionsChoiceProperty.intValue == 0 || newDataSetOptionsChoiceProperty.intValue == 3)
                    newDataSetOptionsChoiceProperty.intValue = 1;
            }
        }

        void DrawOldSetDataConfigurationOptions()
        {
            SerializedProperty dataSetMethodProperty = helper.GetPropertyByName("dataSetMethod");
            dataSetMethodProperty.intValue = EditorGUILayout.Popup(setDataMethodLabel, dataSetMethodProperty.intValue, dataSetMethodOptions);

            EditorGUILayout.Space();

            if ((SetDataMethod)dataSetMethodProperty.intValue == SetDataMethod.Prefabs || (SetDataMethod)dataSetMethodProperty.intValue == SetDataMethod.Default_Values)
                DrawDataSetPrefabOrDefaultValuesOptions();
            else //Set method set to use text asset
            {
                helper.DrawSerializedPropertyField("assetWithData", dataAssetLabel);
            }

            if (!playMode && GUILayout.Button(setDataButtonLabel))
                GetAndSetData();
        }

        void DrawDataSetPrefabOrDefaultValuesOptions()
        {
            if (DisplayLayerOptions)
            {
                helper.DrawSerializedPropertyField("defaultLayerHeight", defaultLayerHeightLabel);
            }

            helper.DrawSerializedPropertyField("defaultRowLength", defaultRowLengthLabel);
            helper.DrawSerializedPropertyField("defaultColumnWidth", defaultColumnWidthLabel);

            EditorGUILayout.Space();

            //Additional options when data set method is Prfabs
            if ((SetDataMethod)helper.GetPropertyByName("dataSetMethod").intValue == SetDataMethod.Prefabs)
                DrawDataSetPrefabOptions();
        }

        void DrawDataSetPrefabOptions()
        {
            SerializedProperty loadPrefabsFromResourcesFolderProperty = helper.GetPropertyByName("loadPrefabsFromResourcesFolder");

            EditorGUILayout.LabelField(SharedLabels.loadPrefabsFromResourcesFolderLabel1);
            helper.DrawSerializedPropertyField(loadPrefabsFromResourcesFolderProperty, SharedLabels.loadPrefabsFromResourcesFolderLabel2);

            if (!loadPrefabsFromResourcesFolderProperty.boolValue)
            {
                EditorGUILayout.LabelField(SharedLabels.prefabFolderPathLabel1);
                helper.DrawSerializedPropertyField("folderPathWherePrefabsAreStored", SharedLabels.prefabFolderPathLabel2);
            }
        }

        

        #endregion

        #region value change checking

        void OnGridNameChanged(string newGridName)
        {
            SetExpectedPrefabFormat();
        }

        void OnNamingConventionChanged(NamingConvention newNamingConvention)
        {
            if (newNamingConvention == null || newNamingConvention.ValidateNamingConvention(IsWorld3D))
                SetExpectedPrefabFormat();
        }

        void OnCellObjectTypeChanged(CellObjectType newCellObjectType)
        {
            if (newCellObjectType == CellObjectType.Unity_Terrain)
            {
                WorldType newWorldType = WorldType.Two_Dimensional_On_XZ_Axes;
                if (worldTypeProperty.intValue != (int)newWorldType)
                {
                    WorldType oldWorldType = (WorldType)worldTypeProperty.intValue;
                    worldTypeProperty.intValue = (int)newWorldType;
                    OnWorldTypeChanged(newWorldType, oldWorldType);
                }
                worldTypeOptions = worldTypeSingleOption;
            }
            else if (newCellObjectType == CellObjectType.Other_Has_Renderer)
                worldTypeOptions = worldTypeThreeOptions; 
            else //no renderer
            {
                SerializedProperty dataSetMethodProperty = helper.GetPropertyByName("dataSetMethod");
                if (dataSetMethodProperty.intValue == 2)
                    dataSetMethodProperty.intValue = 0;

                worldTypeOptions = worldTypeThreeOptions;
            }
        }

        void OnWorldTypeChanged(WorldType newWorldType, WorldType oldWorldType)
        {
            bool updatenewSetDataOptions = false;
            NamingConvention namingConvention = helper.GetPropertyByName("namingConvention").objectReferenceValue as NamingConvention;

            if (newWorldType == WorldType.Three_Dimensional)
            {
                if(namingConvention != null && !namingConvention.ValidateNamingConvention(true))
                {
                    Debug.LogError("The naming convention provided is not valid for a 3D World. Removing . . .");
                    helper.GetPropertyByName("namingConvention").objectReferenceValue = null;
                }

                updatenewSetDataOptions = true;
                SetExpectedPrefabFormat();
                SaveAndRebuildArrays(newWorldType, rowsProperty.intValue, columnsProperty.intValue, layersProperty.intValue);
            }
            else
            {
                if (namingConvention != null && !namingConvention.ValidateNamingConvention(false))
                {
                    Debug.LogError("The naming convention provided is not valid for a 2D World. Removing . . .");
                    helper.GetPropertyByName("namingConvention").objectReferenceValue = null;
                    SetExpectedPrefabFormat();
                }

                //What is the current value?
                if (oldWorldType == WorldType.Three_Dimensional)
                {
                    SaveAndRebuildArrays(newWorldType, rowsProperty.intValue, columnsProperty.intValue, 1);
                    layersProperty.intValue = 1;
                    SetExpectedPrefabFormat();
                    updatenewSetDataOptions = true;
                }
            }

            if (updatenewSetDataOptions)
                UpdateNewSetDataOptions();
        }

        void SetExpectedPrefabFormat()
        {
            expectedPrefabFormat = "Expected Prefab/Scene Format: " + GetExpectedPrefabFormatEnding();
        }

        string GetExpectedPrefabFormatEnding()
        {
            NamingConvention namingConvention = helper.GetPropertyByName("namingConvention").objectReferenceValue as NamingConvention;

            string gridName = helper.GetPropertyByName("gridName").stringValue;
            WorldType worldType = (WorldType)worldTypeProperty.intValue;

            if (namingConvention == null)
                return worldType == WorldType.Three_Dimensional ? gridName + "_Layer_Row_Column" : gridName + "_Row_Column";
            else
            {
                string ending = namingConvention.Format;
                ending = ending.Replace("%x", "Column");
                ending = ending.Replace("%y", "Row");
                ending = ending.Replace("%g", gridName);
                if (worldType == WorldType.Three_Dimensional)
                    ending = ending.Replace("%z", "Layer");

                return ending;
            }
        }

        #endregion

        #region Old Data Set Methods

        void GetAndSetData()
        {
            IWorldGridDataRetriever dataRetriever;

            GridValues<int> gridDimensions = new GridValues<int>(layersProperty.intValue, rowsProperty.intValue, columnsProperty.intValue);

            GridValues<float> gridDefaultMeasurements = new GridValues<float>(helper.GetPropertyByName("defaultLayerHeight").floatValue, helper.GetPropertyByName("defaultRowLength").floatValue, helper.GetPropertyByName("defaultColumnWidth").floatValue);

            SerializedProperty dataSetMethodProperty = helper.GetPropertyByName("dataSetMethod");

            if ((SetDataMethod)dataSetMethodProperty.intValue == SetDataMethod.TextAsset)
            {
                if (helper.GetPropertyByName("assetWithData").objectReferenceValue == null)
                {
                    EditorUtility.DisplayDialog("Text Asset Missing", "Cannot set data because no text asset has been assigned. Assign a text asset or choose a different setting method.", "OK");
                    return;
                }

                dataRetriever = new WorldGridDataReader((TextAsset)helper.GetPropertyByName("assetWithData").objectReferenceValue, WorldType.Three_Dimensional, gridDimensions);
            }
            else if ((SetDataMethod)dataSetMethodProperty.intValue == SetDataMethod.Prefabs)
            {
                string loadReadyPath = null;

                if (!helper.GetPropertyByName("loadPrefabsFromResourcesFolder").boolValue)
                {
                    if (!StringExtensions.TryGetLoadReadyFolderPath(helper.GetPropertyByName("folderPathWherePrefabsAreStored").stringValue, ref loadReadyPath))
                    {
                        EditorUtility.DisplayDialog("Invalid Folder Path", "Cannot set data because the folder specified is not valid. Hover over the label for the folder path field for info on how to format the path.", "OK");
                        return;
                    }
                }

                WorldType worldType = (WorldType)worldTypeProperty.intValue;

                INamingConvention namingConventionToUse = ((NamingConvention)helper.GetPropertyByName("namingConvention").objectReferenceValue).GetCorrectNamingConvention(worldType == WorldType.Three_Dimensional);

                dataRetriever = new WorldGridDataCalculator(loadReadyPath, helper.GetPropertyByName("gridName").stringValue,
                (CellObjectType)helper.GetPropertyByName("cellObjectType").intValue, worldType, gridDimensions, gridDefaultMeasurements, namingConventionToUse);
            }
            else
                dataRetriever = new DefaultDataRetriever((WorldType)worldTypeProperty.intValue, gridDimensions, gridDefaultMeasurements);


            TryToSetData(dataRetriever.RetrieveWorldGridData());
        }

        void TryToSetData(WorldGridSetupData setupData)
        {
            WorldType worldType = (WorldType)worldTypeProperty.intValue;

            int gridLocationsExpected = worldType == WorldType.Three_Dimensional ? rowsProperty.intValue * columnsProperty.intValue * layersProperty.intValue : rowsProperty.intValue * columnsProperty.intValue;

            bool emptiesGridLocationsSet = VerifyData<bool>(setupData.EmptyGridLocations, gridLocationsExpected);

            bool columnWidthsSet = VerifyData<float>(setupData.ColumnWidths, columnsProperty.intValue);
            bool rowLengthsSet = VerifyData<float>(setupData.RowLengths, rowsProperty.intValue);

            bool layerHeightsSet;
            if (worldType == WorldType.Three_Dimensional)
                layerHeightsSet = VerifyData<float>(setupData.LayerHeights, layersProperty.intValue);
            else
                layerHeightsSet = true;

            if (!emptiesGridLocationsSet || !columnWidthsSet || !rowLengthsSet || !layerHeightsSet)
            {
                EditorUtility.DisplayDialog("Error", "Setting the Data Failed: See Console Log for more info.", "Ok");

                System.Collections.Generic.List<string> errors = new System.Collections.Generic.List<string>(4);
                if (!layerHeightsSet) errors.Add("Layer Heights");
                if (!rowLengthsSet) errors.Add("Row Lengths");
                if (!columnWidthsSet) errors.Add("Column Widths");
                if (!emptiesGridLocationsSet) errors.Add("Empty Grid Locations");

                string errorMessage = "There was an issue setting the following data";
                foreach (string error in errors)
                    errorMessage += " : " + error;

                Debug.LogError(errorMessage);
            }
            else
            {
                emptyGridLocationsProperty.CopyBoolArrayToBoolArrayProperty(setupData.EmptyGridLocations, true);
                rowLengthsProperty.CopyFloatArrayToFloatArrayProperty(setupData.RowLengths, true);
                columnWidthsProperty.CopyFloatArrayToFloatArrayProperty(setupData.ColumnWidths, true);

                if (worldType == WorldType.Three_Dimensional)
                    layerHeightsProperty.CopyFloatArrayToFloatArrayProperty(setupData.LayerHeights, true);
                else
                    layerHeightsProperty.arraySize = 0;
            }
        }
        
        bool VerifyData<T>(T[] data, int expectedLengthOfData)
        {
            if (data == null || data.Length != expectedLengthOfData)
                return false;
            else
                return true;
        }

        #endregion

        #region Labels
        GUIContent allLayersButton = new GUIContent("Change Designation of All Cells In Grid", "If all cells in every layer of the grid are not empty, will change all cells to empty. Otherwise, will set all empty cells to not empty.");

        GUIContent layerButton = new GUIContent("Change\nAll Cells\nIn Layer", "If all cells in the current layer of the grid are not empty, will change all cells to empty. Otherwise, will set all empty cells to not empty."); 

        GUIContent cellObjectTypeLabel = new GUIContent("Cell Object Type*", "The type of objects associated with this World Grid. If using Terrain, this must be set to Unity Terrain in order for Terrain Neighboring to work, which will allow the seems between your terrains to be blended.\n\nIf not using Terrains, then the designation only has on impact on the 'Set Using Prefabs' option under 'Old Data Set Methods'. If 'Other_No_Renderer' is set as the cell object type, the tool will attempt to get the size of each prefab from the renderer component on the prefab when the 'Set Data*' button is pressed.");

        GUIContent dataAssetLabel = new GUIContent("Text Asset With Data*", "Instead of setting the data from prefabs, you can store the necessary information in a Text Asset and then drag that " +
            "asset here.\n\nSee 'Assets/TerrainSlicing/OtherScripts/DynamicLoadingScripts/example.txt for an example on what information should be in the asset and how to format it.\n\nHere's an example of " +
            "a 2D world's data (do not include the stuff in ()'s )\n\n200 (Row Length)\n200 (Row Length)\n\n150 (Column Width)\n250 (Column Width)\n\nFalse (Grid Location at 1_1 is not empty)\n" +
            "False (1_2 not empty)\nFalse(2_1 not empty)\nFalse(2_2 not empty)\n\nIf all values for a given data type (row lengths, for example) are equal, as they are in the example above, you " +
            "can represent all values with a single value instead. For example, the example above could be written like this:\n\n200\n\n150\n250\n\nFalse\n\nNotice that the column widths could not " +
            "be written as a single value, because not all values were equal to each other!");

        GUIContent defaultLayerHeightLabel = new GUIContent("Default Layer Height*", "The default height of each layer on the grid (measured along the Y Axis).\n\nUsed when setting the data using " +
            "default values or when a layer height cannot be calculated from the specified prefabs.\n\nThis option is not available when using Unity Terrains or any other 2D world.");

        GUIContent defaultColumnWidthLabel = new GUIContent("Default Column Width*", "The default width of each column on the grid (measured along the X Axis).\n\nUsed when setting the data using " +
            "default values or when a column width cannot be calculated from the specified prefabs.");

        GUIContent defaultRowLengthLabel = new GUIContent("Default Row Length*", "The default length of each row on the grid (measured along the Z axis when using a 2D-XZ or 3D world, or along the Y axis when using a 2D-XY world)." +
            "\n\nUsed when setting the data using default values or when a row length cannot be calculated from the specified prefabs.");
        
        GUIContent gridNameLabel = new GUIContent("Default Group Name*", "The base name shared by the default cell objects in the group this grid is representing, i.e., the name before the _1_1, _1_2, etc. of your objects.\n\n" + 
            "It is possible to load variants of these base objects by changing the group name during runtime. This is done via the World's ChangeGroupName method.\n\nIn order to load variants " + 
            "at the beginning of the game, you must change the group name before the World has started loading its initial objects.\n\nTo accomplish this, change the Script Execution Order of the script that calls the " + 
            "ChangeGroupName method so it's set to run before the Default Time (Edit -> Project Settings -> Script Execution Order). GroupName changes will persist between game sessions.\n\n" +
            "You can also reset the Group Name back to this default group name via the World's ResetGroupName method.");

        GUIContent setDataMethodLabel = new GUIContent("Method to Set Data*", "The method you'd like to use to set the requisite data.");

        GUIContent setDataButtonLabel = new GUIContent("Set Data*", "The main function of this asset is to store crucial inforation about your world, such as the length of each row, " +
            "width of each column, height of each layer (if using a 3D world) and which cells on the world are empty.\n\nTo set this data, make sure the information above is correct and provide either a text asset with the necessary data, " +
            "the folder path where your prefabs for this world grid are stored, and/or default values.");

        GUIContent worldTypeLabel = new GUIContent("World Type*", "Is the world two or three dimensional? If two dimensional, which axes is the world using (controls where objects are placed)?\n\nSelect and then hover over each choice to see more information.");

        static GUIContent unityTerrainsContent = new GUIContent("Unity Terrains", "The cell objects for this world grid are Unity Terrains.");

        static GUIContent nonTerrainsWithRendererContent = new GUIContent("Non Terrain With Renderer", "The cell objects for this world grid are not Unity Terrains, but do have a Renderer Component.");

        static GUIContent nonTerrainsWithoutRendererContent = new GUIContent("Non Terrain Without Renderer", "The cell objects for this world grid are not Unity Terrains, and do not have a Renderer Component.");

        GUIContent[] cellObjectTypeOptions = new GUIContent[3] { unityTerrainsContent, nonTerrainsWithRendererContent, nonTerrainsWithoutRendererContent };

        //Some stuff for some of the options
        static GUIContent twoD_XZContent = new GUIContent("Two Dimensional using XZ Axes", "Columns are on the X axis and rows are on the Z axis. " +
               "The Y position of cell objects is fixed and the player can move freely on the Y axis without effecting loading.\n\nSuitable for most games, and must be used when using Unity Terrains.");

        static GUIContent twoD_XYContent = new GUIContent("Two Dimensional using XY Axes", "Columns are on the X axis and rows are on the Y axis. " +
        "The Z position of cell objects is fixed and the player can move freely on the Z axis without effecting loading.\n\nSuitable for 2D side scrolling games.");

        static GUIContent threeDContent = new GUIContent("Three Dimensional", "Columns are on the X axis, rows are on the Z axis, and layers are on the Y axis. Just imagine a rubix cube.\n\n" +
        "Make sure your objects bounds line up layer to layer. For example, you cannot have a 10m (width on x axis) x 10m (length on z axis) cube on layer 2 sitting directly square atop " +
        "a 100m x 100m cube.");

        GUIContent[] worldTypeSingleOption = new GUIContent[1] { twoD_XZContent };
        GUIContent[] worldTypeThreeOptions = new GUIContent[3] { twoD_XZContent, twoD_XYContent, threeDContent };

        static GUIContent setDataUsingDefaultValues = new GUIContent("Set Using Default Values", "The height of each layer, length of each row, and width of each column will be set to the default values. " +
                "All Grid locations will be marked as NOT EMPTY.");

        static GUIContent setDataUsingTextAsset = new GUIContent("Set Using Text Asset", "Data will be set using the Text Asset provided. The default values will not be used.");

        static GUIContent setDataUsingPrefabs = new GUIContent("Set Using Prefabs", "Data is set using the prefabs found in the specified folder. If a prefab is not found for " +
            "a cell, that cell will be marked as empty.\n\nThe row lengths, column widths, and layer heights (3D worlds only) will be set according to the following rules:\n\nFor terrains, terrainData.size is used. If " +
            "an entire row/column/layer has no prefabs from which to get the dimension, the default value for that dimension will be used.\n\nFor Non Terrains with a Renderer Component, renderer.bounds.size is used. If " +
            "an entire row/column/layer has no prefabs from which to get the dimension, the default value for that dimension will be used.\n\nFor Non Terrains without a Renderer Component, the default " +
            "values will be used to set all the dimensional data.");


        //Offset Labels
        GUIContent xCellOffsetPercentLabel = new GUIContent("X Cell Offset %*", "The amount the objects in your cells will be offet on the X axis in relation to " +
            "the total width of your cell.\n\nFor instance, .5 (50%) will set the position of your object to the mid point (on the X axis) of your cell.\n\n" +
            "For objects who's pivot point is in the center of the object (such as the default Unity objects), this will effectively center the object in your cell.\n\n" +
            "You can leave this value at 0 if your objects pivot point is at the bottom left, and the object and cell's width is the same.\n\nPlease consult the " +
            "full guide for more information.");

        GUIContent yCellOffsetPercentLabel = new GUIContent("Y Cell Offset %*", "The amount the objects in your cells will be offet on the Y axis in relation to " +
            "the total length of your cell.\n\nFor instance, .5 (50%) will set the position of your object to the mid point (on the Y axis) of your cell.\n\n" +
            "For objects who's pivot point is in the center of the object (such as the default Unity objects), this will effectively center the object in your cell.\n\n" +
            "You can leave this value at 0 if your objects pivot point is at the bottom left, and the object and cell's length is the same.\n\nPlease consult the " +
            "full guide for more information.");

        GUIContent zCellOffsetPercentLabel = new GUIContent("Z Cell Offset %*", "The amount the objects in your cells will be offet on the Z axis in relation to " +
            "the total length of your cell.\n\nFor instance, .5 (50%) will set the position of your object to the mid point (on the Z axis) of your cell.\n\n" +
            "For objects who's pivot point is in the center of the object (such as the default Unity objects), this will effectively center the object in your cell.\n\n" +
            "You can leave this value at 0 if your objects pivot point is at the bottom left, and the object and cell's length is the same.\n\nPlease consult the " +
            "full guide for more information.");

        #endregion
    }
}