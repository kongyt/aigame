﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using UnityEditor;
    using UnityEngine;
    using DynamicLoadingKit;
    using System;
    using Object = UnityEngine.Object;

    public class PersistentDataControllerEditor : BaseEditor
    {
        GUIContent[] options;
        bool displayComponentManagerField, displayComponentField;

        string componentManagerLabel = "Component Manager ID", worldLabel = "World ID", activeGridLabel = "Active Grid ID", label = "Active Grid ID";

        public PersistentDataControllerEditor(SerializedObject serializedObject)
            : base(serializedObject)
        {
            options = new GUIContent[15] { option0, option1, option2, option3, option4, option5, option6, option7, option8, option9, option10, option11, option12, option13, option14 };
        }

        protected sealed override void DrawInspector()
        {
            UpdateLabel();
            UpdateFieldsDrawn();

            helper.DrawSerializedPropertyField("sceneID", sceneIDLabel);
            EditorGUILayout.Space();

            EditorGUILayout.LabelField("Data Clearing (select and hover over an option to see more info about it)", EditorStyles.boldLabel);

            bool changeDetected;
            helper.DrawSerializedPropertyPopupField("optionChosen", clearActionLabel, options, out changeDetected);
            if (changeDetected)
            {
                UpdateLabel();
                UpdateFieldsDrawn();
            }

            if (displayComponentManagerField)
                helper.DrawSerializedPropertyField("componentManagerID", componentManagerLabel);

            if (displayComponentField)
                helper.DrawSerializedPropertyField("ID", label);

            if (!playMode)
            {
                if (GUILayout.Button("Clear Data"))
                    RemovePersistentDataForComponent();

                EditorGUILayout.Space();
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Use the following button with caution!", EditorStyles.boldLabel);
                if (GUILayout.Button(removeAllDataLabel))
                    RemoveAll();
            }
        }

        void UpdateLabel()
        {
            int optionChosen = helper.GetPropertyByName("optionChosen").intValue;
            if (optionChosen == 0
                || optionChosen == 5
                || optionChosen == 13)
            {
                label = activeGridLabel;
            }
            else if (optionChosen == 2
                || optionChosen == 7
                || optionChosen == 14)
            {
                label = worldLabel;
            }
        }

        void UpdateFieldsDrawn()
        {
            int optionChosen = helper.GetPropertyByName("optionChosen").intValue;
            if (optionChosen == 13)
            {
                displayComponentField = true;
                displayComponentManagerField = false;
            }
            else
            {
                displayComponentManagerField = true;

                if (optionChosen == 0
                    || optionChosen == 5
                    || optionChosen == 2
                    || optionChosen == 7)
                {
                    displayComponentField = true;
                }
                else
                    displayComponentField = false;
            }
        }

        void RemovePersistentDataForComponent()
        {
            string className = "DynamicLoadingKitEditors.ClearType" + helper.GetPropertyByName("optionChosen").intValue; ;
            Type t = Type.GetType(className);
            IClearType clearType = (IClearType)Activator.CreateInstance(t);

            if (clearType.TryClearData(helper))
                EditorUtility.DisplayDialog("Data Cleared", "Good News! The data was successfully cleared!", "OK");
            else
                EditorUtility.DisplayDialog("Data Not Cleared", "Uh Oh! The data could not be cleared. Ensure the ID's are correct.", "OK");
        }


        void RemoveAll()
        {
            ActiveGrid[] activeGridsInScene = Object.FindObjectsOfType(typeof(ActiveGrid)) as ActiveGrid[];
            int activeGridDataRemoved = RemoveAllComponentData<ActiveGrid>(activeGridsInScene, "_AG_");

            World[] worldsInScene = Object.FindObjectsOfType(typeof(World)) as World[];
            int worldDataRemoved = RemoveAllComponentData<World>(worldsInScene, "_W_");

            ComponentManager[] componentManagersInScene = Object.FindObjectsOfType(typeof(ComponentManager)) as ComponentManager[];

            int componentManagerDataRemoved = 0;
            for (int i = 0; i < componentManagersInScene.Length; i++ )
            {
                ClearComponentManagerData c = new ClearComponentManagerData(helper.GetPropertyByName("sceneID").stringValue + "_CM_" + componentManagersInScene[i].ID);
                if (c.TryClearData(helper))
                    componentManagerDataRemoved++;
            }

            EditorUtility.DisplayDialog("Result", string.Format("Data was removed for {0} Active Grids, {1} Worlds and {2} Component Managers.", activeGridDataRemoved, worldDataRemoved, componentManagerDataRemoved), "OK");
        }

        int RemoveAllComponentData<T>(T[] componentsInScene, string componentLabel) where T : IIdentifiable
        {
            int componentDataRemoved = 0;
            if (componentsInScene != null)
            {
                for (int i = 0; i < componentsInScene.Length; i++)
                {
                    string key = helper.GetPropertyByName("sceneID").stringValue + componentLabel + componentsInScene[i].ID;
                    if (((PersistentDataController)helper.SerializedObject.targetObject).TryDeleteData(key))
                        componentDataRemoved++;
                }
            }
            return componentDataRemoved;
        }

        #region GUIContent Labels
        GUIContent removeAllDataLabel = new GUIContent("Clear All Persistent Scene Data*", "Removes all scene data associated with this Persistent Data Controller.\n\n" +
            "This includes any Component Manager and Active Grid data that is associated with this Persistent Data Controller.\n\nThis effectively wipes the scene clean, so USE WITH CAUTION!");

        GUIContent sceneIDLabel = new GUIContent("Scene ID*", "A Unique Key for " +
                "Persistent Data Storage.\n\nAll component manager, worlds, and active grids that use this persistent data controller will use this " +
                "Scene ID along with their specific ID to create a unique key for persistent data storage. This allows you to use the same component ID " +
                "(worldID for World components, for example) between scenes (as long as this scene ID is not reused in another scene).");

        GUIContent clearActionLabel = new GUIContent("Clear Method*", "What data do you want to clear?");

        GUIContent option0 = new GUIContent("Clear Obsolete Active Grid", "Clears the specified obsolete active grid from the specified component manager's data so " +
            "that the active grid is no longer obsolete.\n\nThis will make it so the active grid is not destroyed the next time your game enters play mode.\n\n" +
            "This is only useful for inspector created active grids which were made obsolete when they were destroyed during your game.");

        GUIContent option1 = new GUIContent("Clear All Obsolete Active Grids", "Clears all obsolete active grids from the specified component manager's data so " +
            "that the active grids are no longer obsolete.\n\nThis will make it so these active grids are not destroyed the next time your game enters play mode.\n\n" +
            "This is only useful for inspector created active grids which were made obsolete when they were destroyed during your game.");

        GUIContent option2 = new GUIContent("Clear Obsolete World", "Clears the specified obsolete world from the specified component manager's data so " +
            "that the world is no longer obsolete.\n\nThis will make it so the world is not destroyed the next time your game enters play mode.\n\n" +
            "This is only useful for inspector created worlds which were made obsolete when they were destroyed during your game.");

        GUIContent option3 = new GUIContent("Clear All Obsolete Worlds", "Clears all obsolete worlds from the specified component manager's data so " +
            "that the worlds are no longer obsolete.\n\nThis will make it so these worlds are not destroyed the next time your game enters play mode.\n\n" +
            "This is only useful for inspector created worlds which were made obsolete when they were destroyed during your game.");

        GUIContent option4 = new GUIContent("Clear All Obsolete Data", "Clears all obsolete active grids and worlds from the specified component manager's data so " +
            "that the active grids and worlds are no longer obsolete.\n\nThis will make it so these active grids and worlds are not destroyed the next time your game enters play mode.\n\n" +
            "This is only useful for inspector created active grids and worlds which were made obsolete when they were destroyed during your game.");

        GUIContent option5 = new GUIContent("Clear Runtime Created Active Grid", "Clears the specified runtime created active grid from the specified component manager's data." +
            "\n\nThis will make it so the runtime created active grid is not created the next time your game enters play mode.\n\n" +
            "This is only useful for Active Grids you have created via one of the Component Manager's CreateActiveGrid methods.");

        GUIContent option6 = new GUIContent("Clear All Runtime Created Active Grids", "Clears all runtime created active grids from the specified component manager's data." +
            "\n\nThis will make it so the runtime created active grids are not created the next time your game enters play mode.\n\n" +
            "This is only useful for Active Grids you have created via one of the Component Manager's CreateActiveGrid methods.");

        GUIContent option7 = new GUIContent("Clear Runtime Created World", "Clears the specified runtime created world from the specified component manager's data." +
            "\n\nThis will make it so the runtime created world is not created the next time your game enters play mode.\n\n" +
            "This is only useful for Worlds you have created via one of the Component Manager's CreateWorld methods.");

        GUIContent option8 = new GUIContent("Clear All Runtime Created Worlds", "Clears all runtime created worlds from the specified component manager's data." +
            "\n\nThis will make it so the runtime created worlds are not created the next time your game enters play mode.\n\n" +
            "This is only useful for Worlds you have created via one of the Component Manager's CreateWorld methods.");

        GUIContent option9 = new GUIContent("Clear All Runtime Created Data", "Clears all runtime created active grids and worlds from the specified component manager's data." +
            "\n\nThis will make it so the runtime created active grids and worlds are not created the next time your game enters play mode.\n\n" +
            "This is only useful for Active Grids created via one of the Component Manager's CreateActiveGrid methods and Worlds you have created via one of the Component Manager's CreateWorld methods.");

        GUIContent option10 = new GUIContent("Clear All Obsolete and Runtime Created Active Grid Data", "Clears all obsolete active grids and runtime created active grids from the specified component manager's data." +
            "\n\nThis will make it so the previously obsolete active grids will not be destroyed on Play, and the runtime created active grids will not be created the next time your game enters play mode.");

        GUIContent option11 = new GUIContent("Clear All Obsolete and Runtime Created World Data", "Clears all obsolete worlds and runtime created worlds from the specified component manager's data." +
            "\n\nThis will make it so the previously obsolete worlds will not be destroyed on Play, and the runtime created worlds will not be created the next time your game enters play mode.");

        GUIContent option12 = new GUIContent("Clear All Obsolete and Runtime Created Data", "Clears all obsolete active grids/worlds and runtime created active grids/worlds from the specified component manager's data." +
            "\n\nThis will make it so the previously obsolete active grids/worlds will not be destroyed on Play, and the runtime created active grids/worlds will not be created the next time your game enters play mode.");

        GUIContent option13 = new GUIContent("Clear Inspector Created Active Grid Data", "Clears the saved persistent data for the specified Inspector Created Active Grid.\n\n" +
            "This makes it so the next time you enter Play, the default values of the Active Grid will be used.");

        GUIContent option14 = new GUIContent("Clear All Inspector Created Active Grid Data", "Clears the saved persistent data for all Inspector Created Active Grids in the current scene.\n\n" +
           "This makes it so the next time you enter Play, the default values of the Active Grids will be used.");

        GUIContent option15 = new GUIContent("Clear Inspector Created World Data", "Clears the saved persistent data for the specified Inspector Created World.\n\n" +
            "This makes it so the next time you enter Play, the World's Origin Cell will be reset to its default values (if your World is not set to " +
            "stay centered about the origin, there is no need to clear its data, since it's Origin Cell will always be the default.");

        GUIContent option16 = new GUIContent("Clear All Inspector Created World Data", "Clears the saved persistent data for all Inspector Created Worlds in the current scene.\n\n" +
            "This makes it so the next time you enter Play, each World's Origin Cell will be reset to its default value.");

        GUIContent option17 = new GUIContent("Clear All Inspector Created Active Grid and World Data", "Clears the saved persistent data for all Inspector Created Active Grids and Worlds in the current scene.\n\n" +
            "This makes it so the next time you enter Play, the default values of the Active Grids will be used, and each World's Origin Cell will be reset to its default value.");

        #endregion
    }
}