//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{	
	using UnityEngine;
	using System.Collections;
	using System.Collections.Generic;
	using System;
	
    /// <summary>
    /// Represents a cell in a <see href = "World.html">World</see>.
    /// </summary>
    /// <title>IWorldCell Interface</title>
    /// <category>Interfaces</category>
    /// <navigationName>IWorldCell</navigationName>
    /// <fileName>IWorldCell.html</fileName>
    /// <syntax>public interface IWorldCell</syntax>
	public interface IWorldCell
	{
        /// <summary>
        /// Gets the cells index on the World Grid associated with the World the cell belongs to.
        /// </summary>
        /// <type link = "Cell.html">Cell</type>
        Cell CellOnWorldGrid    { get; }

        /// <summary>
        /// Gets the cells index on the Endless Grid associated with the World the cell belongs to.
        /// </summary>
        /// <type link = "Cell.html">Cell</type>
        Cell CellOnEndlessGrid { get; }

        /// <summary>
        /// Gets the cells height, measured along the Y axis. This will always be 0 if the world is not three dimensional.
        /// </summary>
        /// <type>float</type>
        float Height            { get; }

        /// <summary>
        /// Gets the cells length, measured along the Y axis if using a 2D XY world, or along the Z axis otherwise.
        /// </summary>
        /// <type>float</type>
        float Length            { get; }

        /// <summary>
        /// Gets the cells width, always measured along the X axis.
        /// </summary>
        /// <type>float</type>
        float Width             { get; }
         
        /// <summary>
        /// Gets the cells position in world space.
        /// </summary>
        /// <type link = "http://docs.unity3d.com/ScriptReference/Vector3.html">Vector3</type>
        Vector3 CellPosition { get; }
	}

    /// <summary>
    /// Represents a cell in a <see href = "World.html">World</see> that can have an object "attached" to it.
    /// </summary>
    /// <title>IAttachableWorldCell Interface</title>
    /// <category>Interfaces</category>
    /// <navigationName>IAttachableWorldCell</navigationName>
    /// <fileName>IAttachableWorldCell.html</fileName>
    /// <syntax>public interface IAttachableWorldCell : <see cref="IWorldCell" href = "IWorldCell.html">IWorldCell</see></syntax>
    public interface IAttachableWorldCell : IWorldCell
    {
        /// <summary>
        /// Gets the cell object attached to this cell. Returns null if no object is attached.
        /// </summary>
        /// <type link = "http://docs.unity3d.com/ScriptReference/GameObject.html">GameObject</type>
        GameObject CellObject { get; }

        /// <summary>
        /// Gets the position that the cell object should be placed at. You can position the object manually, or 
        /// let it be automatically positioned via AttachCellObjectToCell (by passing in false for 
        /// objectPositionedCorrectlyAlready).
        /// </summary>
        /// <type>bool</type>
        Vector3 CellObjectPosition { get; }

        /// <summary>
        /// Attaches a GameObject to the cell. If creating a custom Cell Object Loader or Primary Cell Object 
        /// Sub Controller class, you should either let the WorldCell position the cell object correctly by 
        /// passing in false for objectPositionedCorrectlyAlready, or position the object manually (or instantiate it 
        /// at the correct position) and pass in true.
        /// </summary>
        /// <param name="obj" type = "GameObject" link = "http://docs.unity3d.com/ScriptReference/GameObject.html">
        /// The object to attach to the cell.
        /// </param>
        /// <param name="objectPositionedCorrectlyAlready" type="bool">
        /// If false, the object will be moved to its correct position. If you've already positioned the object at the correct 
        /// location (CellObjectPosition), you must pass in true.
        /// </param>
        /// <displayName id = "AttachCellObjectToCell">AttachCellObjectToCell(GameObject, bool)</displayName>
        /// <syntax>void AttachCellObjectToCell(GameObject obj, bool objectPositionedCorrectlyAlready)</syntax>
        void AttachCellObjectToCell(GameObject obj, bool objectPositionedCorrectlyAlready);  
    }

    /// <summary>
    /// Represents a cell in a <see href = "World.html">World</see> that can have an object "detached" from it.
    /// </summary>
    /// <title>IDetachableWorldCell Interface</title>
    /// <category>Interfaces</category>
    /// <navigationName>IDetachableWorldCell</navigationName>
    /// <fileName>IDetachableWorldCell.html</fileName>
    /// <syntax>public interface IDetachableWorldCell : <see cref="IWorldCell" href = "IWorldCell.html">IWorldCell</see></syntax>
    public interface IDetachableWorldCell : IWorldCell
    {
        /// <summary>
        /// Detaches and returns the GameObject attached to the cell.
        /// </summary>
        /// <displayName id = "DetachCellObjectFromCell">DetachCellObjectFromCell()</displayName>
        /// <syntax>GameObject DetachCellObjectFromCell()</syntax>
        /// <returns type = "GameObject" link = "http://docs.unity3d.com/ScriptReference/GameObject.html">The GameObject that was previously attached to the cell.</returns>
        GameObject DetachCellObjectFromCell();
    }

    /// <summary>
    /// Represents an object which can be Identified via an ID.
    /// </summary>
    /// <title>IIdentifiable Interface</title>
    /// <category>Interfaces</category>
    /// <navigationName>IIdentifiable</navigationName>
    /// <fileName>IIdentifiable.html</fileName>
    /// <syntax>public interface IIdentifiable</syntax>
    public interface IIdentifiable
    {
        /// <summary>
        /// Gets the identification number of the IIdentifiable object.
        /// </summary>
        /// <type>int</type>
        int ID { get; }
    }

    /// <summary>
    /// Represents a user that wishes to be notified when certain events occur on a World. You can register this user 
    /// via <see cref="World.Register" href="World.html#Register">World.Register</see>
    /// </summary>
    /// <title>IWorldUser Interface</title>
    /// <category>Interfaces</category>
    /// <navigationName>IWorldUser</navigationName>
    /// <fileName>IWorldUser.html</fileName>
    /// <syntax>public interface IWorldUser</syntax>
    public interface IWorldUser
    {
        /// <summary>
        /// Called when the World the user is registered to is about to be destroyed.
        /// </summary>
        /// <displayName id="OnWorldDestroyed">OnWorldDestroyed()</displayName>
        /// <syntax> void OnWorldDestroyed()</syntax>
        void OnWorldDestroyed();

        /// <summary>
        /// Called when the World the user is registered to is shifted.
        /// </summary>
        /// <param name="shiftAmount" type="Vector3">
        /// The amount of shift.
        /// </param>
        /// <param name="newOriginCell" type="Cell" link="Cell.html">
        /// The new origin cell of the World after the shift.
        /// </param>
        /// <param name="endlessGridResetAddition" type="Cell" link="Cell.html">
        /// When the world shifts, it resets the endless grid indexes 
        /// as well. This ensures the endless grid values cannot exceed the maximum integer value (unlikely but possible). 
        /// This paramater tracks that reset. Basically, if you have a list of endless grid cells you are keeping track of, 
        /// you should add this value to each of those cells so they are in sync with the World.
        /// </param>
        /// <displayName id="OnWorldShifted">OnWorldShifted(Vector3, Cell, Cell)</displayName>
        /// <syntax>void OnWorldShifted(Vector3 shiftAmount, Cell newOriginCell, Cell endlessGridResetAddition)</syntax>
        void OnWorldShifted(Vector3 shiftAmount, Cell newOriginCell, Cell endlessGridResetAddition);

        /// <summary>
        /// Called when the World the user is registered to has its origin cell changed.
        /// </summary>
        /// <param name="newOriginCell" type="Cell" link="Cell.html">The new origin cell of the World.</param>
        /// <displayName id="">
        /// OnOriginCellChanged(Cell)
        /// </displayName>
        /// <syntax>void OnOriginCellChanged(Cell newOriginCell)</syntax>
        void OnOriginCellChanged(Cell newOriginCell);
    }

    /// <summary>
    /// Represents a Naming Convention
    /// </summary>
    /// <title>INamingConvention Interface</title>
    /// <category>Interfaces</category>
    /// <navigationName>INamingConvention</navigationName>
    /// <fileName>INamingConvention.html</fileName>
    /// <syntax>public interface INamingConvention</syntax>
    public interface INamingConvention
    {
        /// <summary>
        /// Gets the format of the naming convention. This describes the format of the text following the 
        /// group name of the terrain or object (the group name is the name common to all objects/terrain in the same group).
        /// </summary>
        /// <type>string</type>
        string Format { get; }

        /// <summary>
        /// Gets a value indicating whether the naming convention calls for row/column/layer numbers to start at 0.
        /// If false, the numbers will start at 1 instead.
        /// </summary>
        /// <type>bool</type>
        bool NumberingStartsAt0 { get; }
    }

    /// <summary>
    /// Represents a Cell Object Group
    /// </summary>
    /// <title>ICellObjectGroup Interface</title>
    /// <category>Interfaces</category>
    /// <navigationName>ICellObjectGroup</navigationName>
    /// <fileName>ICellObjectGroup.html</fileName>
    /// <syntax>public interface ICellObjectGroup</syntax>
    public interface ICellObjectGroup
    {
        /// <summary>
        /// Gets the group name associated with the cell object group.
        /// </summary>
        /// <type>string</type>
        string GroupName { get; }

        /// <summary>
        /// Gets the Naming Convention associated with the cell object group.
        /// </summary>
        /// <type>bool</type>
        INamingConvention NamingConvention { get; }

        /// <summary>
        /// Gets the World associated with the cell object group.
        /// </summary>
        /// <type link = "World.html">World</type>
        World World { get; }
    }

    public interface IPreciseNumber
    {
        void Add(IPreciseNumber valueToAdd);
        void Add(float valueToAdd);
        void Subtract(IPreciseNumber valueToSubtract);
        void MultiplyBy(IPreciseNumber valueToMultiplyBy);
        void MultiplyBy(int valueToMultilyBy);
        void DivideBy(IPreciseNumber valueToDivideBy);

        float ToFloat();
        void SetToFloat(float setTo);
    }

    public interface IPreciseVector3
    {
        IPreciseNumber x { get; }
        IPreciseNumber y { get; }
        IPreciseNumber z { get; }

        IPreciseVector3 Add(IPreciseVector3 valueToAdd);
        IPreciseVector3 Subtract(IPreciseVector3 valueToSubtract);
        IPreciseVector3 MultiplyBy(IPreciseVector3 valueToMultiplyBy);
        IPreciseVector3 DivideBy(IPreciseVector3 valueToDivideBy);

        Vector3 ToVector3();
        void SetToVector3(Vector3 setTo);
    }
}