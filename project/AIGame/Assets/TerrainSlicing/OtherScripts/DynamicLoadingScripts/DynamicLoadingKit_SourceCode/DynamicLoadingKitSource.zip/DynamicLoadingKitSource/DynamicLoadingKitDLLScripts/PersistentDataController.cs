﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;

    /// <summary>
    /// Provides a base implementation for Persistent Data Controllers. These components control how data is saved and loaded
    /// between game sessions.
    /// <para>In order to utilize some of the inspector options (such as the ability to clear persistent data) when creating your own class which derives from PersistentDataController, you will need to create a custom inspector for your
    /// custom class. Please follow the template in the EditorTemplates.txt file 
    /// (found in the "TerrainSlicing/OtherScripts/DynamicLoadingScripts/Editor" folder) when creating this editor script.</para>
    /// </summary>
    /// <title>PersistentDataController Abstract Class</title>
    /// <category>Primary Components</category>
    /// <navigationName>PersistentDataController</navigationName>
    /// <fileName>PersistentDataController.html</fileName>
    /// <syntax>public abstract class PersistentDataController : MonoBehaviour</syntax>
    /// <inspector name ="Active Grid ID" type="int">The ID of the Active Grid whose data should be cleared when the "Clear Data" button is pressed. This option 
    /// is hidden with some Clear Methods.</inspector>
    /// <inspector name ="Clear All Persistent Scene Data" type="Button">Clears all persistent scene data related to
    /// this Persistent Data Controller. This will effectively "reset" your scene and should be used with caution.</inspector>
    /// <inspector name ="Clear Data" type="Button">Clears the persistent data in relation to the current "Clear Method" and ID's.</inspector>
    /// <inspector name ="Clear Method" type="Dropdown">The clear operation that will take place when the "Clear Data" button is pressed. Select 
    /// a method and hover over it to see more information about it.</inspector>
    /// <inspector name ="Component Manager ID" type="int">The ID of the Component Manager whose data should be cleared when the "Clear Data" button is pressed. This option 
    /// is hidden with some Clear Methods.
    /// <para>As there should only ever be one Component Manager in your scene at a time, it is unlikely that you will need to change this value.</para></inspector>
    /// <inspector name ="Scene ID" type="string">A unique string ID that identifies this Persistent Data Controller. The Component Manager, which initiates all
    /// persistent data saving/loading in the DLK, automatically prepends this ID to every key passed to the Persistent Data Controller. This allows
    /// Component Manager's and Active Grids in different scenes to utilize the same ID.
    /// <para>Persistent Data Controllers in different scenes MUST HAVE different ID's.</para></inspector>
    public abstract class PersistentDataController : MonoBehaviour
    {
        [SerializeField]
        internal int optionChosen, ID, componentManagerID;

        [SerializeField]
        internal string sceneID = "Make me Unique";

        /// <summary>
        /// Gets the Scene ID of this Persistent Data Controller
        /// </summary>
        /// <type>string</type>
        public string SceneID { get { return sceneID; } }

        /// <summary>
        /// When overridden by a derived class, saves the specified data using the specified key.
        /// </summary>
        /// <param name="key" type="string">The key used to save the persistent data.</param>
        /// <param name="data" type="string">The persistent data that will be saved.</param>
        /// <displayName id="SaveData">SaveData(string, string)</displayName>
        /// <syntax>public abstract void SaveData(string key, string data)</syntax>
        public abstract void SaveData(string key, string data);

        /// <summary>
        /// When overridden by a derived class, attempts to get the persistent data associated with the specified key.
        /// </summary>
        /// <param name="key" type="string">The key used to try and retrieve the persistent data.</param>
        /// <param name="data" type="out string">A string which will contain the data if successfully retrieved.</param>
        /// <returns type="bool">A value indicating whether the data was successfully retrieved. If false, "data" will be null.</returns>
        /// <displayName id="TryGetData">TryGetData(string, out string)</displayName>
        /// <syntax>public abstract bool TryGetData(string key, out string data)</syntax>
        public abstract bool TryGetData(string key, out string data);

        /// <summary>
        /// When overridden by a derived class, attempts to delete the persistent data associated with the specified key.
        /// </summary>
        /// <param name="key" type="string">The key used to identify the persistent data that should be deleted.</param>
        /// <returns type ="bool">A value indicating whether the persistent data was successfully deleted.</returns>
        /// <displayName id="TryDeleteData">TryDeleteData(string)</displayName>
        /// <syntax>public abstract bool TryDeleteData(string key)</syntax>
        public abstract bool TryDeleteData(string key);
    }
}