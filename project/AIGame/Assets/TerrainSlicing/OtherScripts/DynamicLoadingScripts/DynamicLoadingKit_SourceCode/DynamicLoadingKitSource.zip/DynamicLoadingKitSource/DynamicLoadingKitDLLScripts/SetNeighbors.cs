﻿using System;
using System.Collections.Generic;
using System.Linq;
//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using UnityEngine;

    [AddComponentMenu("Dynamic Loading Kit/Set Neighbors")]
    public class SetNeighbors
    {
        [SerializeField]
        int columns = 1, rows = 1;

        [SerializeField]
        bool emptyLocations = false, showFoldout = true;

        [SerializeField]
        Terrain[] terrains;

        //int[,] test;

        void Start()
        {
            if (!SetTheNeighbors())
                Debug.Log("Set Neighbors Failed.");
        }

        bool SetTheNeighbors()
        {
            bool allTerrainsFilled = true;
            int row;
            int col;
            int i;

            for (i = 0; i < rows * columns; i++)
            {
                if (terrains[i] == null)
                    allTerrainsFilled = false;
            }

            if (!allTerrainsFilled && !emptyLocations)
            {
                Debug.Log("Empty locations were found when they were not expected to exist.");
                return false;
            }
            else
            {
                //Create an empty 1 terrain wide buffer around our terrains, which will make setting neighbors easier
                Terrain[,] terrainsToSet = new Terrain[rows + 2, columns + 2];
                i = 0;
                for (row = 0; row < terrainsToSet.GetLength(0); row++)
                {
                    for (col = 0; col < terrainsToSet.GetLength(1); col++)
                    {
                        if (row == 0 || row == rows + 1 || col == 0 || col == columns + 1)
                            terrainsToSet[row, col] = null;
                        else
                        {
                            terrainsToSet[row, col] = terrains[i];
                            i++;
                        }
                    }
                }

                //Set Neighbors
                for (row = 1; row <= rows; row++)
                {
                    for (col = 1; col <= columns; col++)
                    {
                        if (terrainsToSet[row, col] != null)
                            terrainsToSet[row, col].SetNeighbors(terrainsToSet[row, col - 1], terrainsToSet[row + 1, col], terrainsToSet[row, col + 1], terrainsToSet[row - 1, col]);
                    }
                }
                return true;
            }
        }
    }
}