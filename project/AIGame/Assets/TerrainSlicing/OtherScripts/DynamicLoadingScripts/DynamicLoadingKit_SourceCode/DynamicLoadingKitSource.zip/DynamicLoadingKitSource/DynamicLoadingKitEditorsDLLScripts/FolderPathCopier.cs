﻿// Credit to Baconaise on Unity Answers for the Reflection code used to access the copy/paste clip board
using UnityEngine;
using UnityEditor;
using System;
using System.IO;
using System.Reflection;
using Object = UnityEngine.Object;

namespace DynamicLoadingKitEditors
{
    internal static class FolderPathCopier
    {
        #if UNITY_4
        static PropertyInfo m_systemCopyBufferProperty = null;

        static PropertyInfo GetSystemCopyBufferProperty()
        {
            if (m_systemCopyBufferProperty == null)
            {
                Type T = typeof(GUIUtility);
                m_systemCopyBufferProperty = T.GetProperty("systemCopyBuffer", BindingFlags.Static | BindingFlags.NonPublic);
                if (m_systemCopyBufferProperty == null)
                    throw new Exception("Can't access internal member 'GUIUtility.systemCopyBuffer' it may have been removed / renamed");
            }
            return m_systemCopyBufferProperty;
        }
        #endif
        static string ClipBoard
        {
#if UNITY_4
            get
            {
                PropertyInfo P = GetSystemCopyBufferProperty();
                return (string)P.GetValue(null, null);
            }
            set
            {
                PropertyInfo P = GetSystemCopyBufferProperty();
                P.SetValue(null, value, null);
            }
#else
            get
            {
                return GUIUtility.systemCopyBuffer;
            }
            set
            {
                GUIUtility.systemCopyBuffer = value;
            }
#endif
        }

        [MenuItem("Assets/Dynamic Loading Kit/Copy Relative Folder Path")]
        public static void CopyRelativeFolderPath()
        {
            string path = GetSelectedAbsoluteFolderPath();
            path = path.Remove(0, 6);//Removes Assets from beginning of folder path
            ClipBoard = path;
        }

        [MenuItem("Assets/Dynamic Loading Kit/Copy Absolute Folder Path")]
        public static void CopyAbsoluteFolderPath()
        {
            ClipBoard = GetSelectedAbsoluteFolderPath();
        }

        static string GetSelectedAbsoluteFolderPath()
        {
            string path = "Assets";

            Object[] selections = Selection.GetFiltered(typeof(Object), SelectionMode.Assets);

            path = AssetDatabase.GetAssetPath(selections[0]);
            
            if (path[0] == 'a')//Check to make sure the path begins with 'A' and not 'a'. Change it to 'A' if it is an 'a'.
                path = "A" + path.Substring(1, path.Length - 1);

            return path;
        }
    }
}