﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using UnityEngine;
    using System.IO;

    public static class StringExtensions
    {
        public static bool TryGetLoadReadyFolderPath(string relativePathNotReadyForLoading, ref string loadReadyPath)
        {
            if (relativePathNotReadyForLoading == null || relativePathNotReadyForLoading == "")
                return false;

            string pathThatMayNotExists = Application.dataPath + relativePathNotReadyForLoading;
            if (!pathThatMayNotExists.DoesPathExist())
                return false;
            else
            {
                loadReadyPath = relativePathNotReadyForLoading.ConvertRelativePathToAbsolutePath(true);
                return true;
            }
        }

        public static string ConvertRelativePathToAbsolutePath(this string stringToConvert, bool isPathDirectory)
        {
            if (stringToConvert == null || stringToConvert.Length == 0)
                stringToConvert = "/";
            else if (stringToConvert[0] != '/')
                stringToConvert = "/" + stringToConvert;

            string validPath = "Assets" + stringToConvert;
            if (isPathDirectory && validPath[validPath.Length - 1] != '/')
                validPath = validPath + "/";

            return validPath;
        }

        public static bool DoesPathExist(this string path)
        {
            if (Directory.Exists(path))
                return true;
            else
                return false;
        }

        public static bool IsNullOrWhiteSpace(this string value)
        {
            if (value != null)
            {
                for (int i = 0; i < value.Length; i++)
                {
                    if (!char.IsWhiteSpace(value[i]))
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public static bool IsWhiteSpace(this string value)
        {
            if (value == null)
                return false;

            for (int i = 0; i < value.Length; i++)
            {
                if (!char.IsWhiteSpace(value[i]))
                {
                    return false;
                }
            }

            return true;
        }
    }
}
