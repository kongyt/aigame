﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using UnityEngine;
    using UnityEditor;
    using System.Reflection;

    [CustomEditor(typeof(DrawDetailMap))]
    class DrawDetailMapEditor : Editor
    {


        private Vector3[] points;
	    private Vector3 pos;
	    private Vector3 lastPos;
	    private Quaternion rot;
	    private float internalY;
	
	    private bool isTerrain;
	    private int i;

        private SerializedProperty drawMapProp;
	    private SerializedProperty mapColorProp;
        private SerializedProperty gridHeightProp;
        SerializedProperty gameObjectProperty, justStartedProp, pointsProp;

        void OnEnable()
        {
            drawMapProp = serializedObject.FindProperty("drawMap");
            mapColorProp = serializedObject.FindProperty("mapColor");
            gridHeightProp = serializedObject.FindProperty("y");
            gameObjectProperty = serializedObject.FindProperty("gameObject");
            justStartedProp = serializedObject.FindProperty("justStarted");
            pointsProp = serializedObject.FindProperty("points");
            serializedObject.Update();

            GameObject gO = (GameObject)gameObjectProperty.objectReferenceValue;
            Terrain terrain = gO.GetComponent("Terrain") as Terrain;
            if (terrain == null)
            {
                isTerrain = false;
                Debug.Log("Object is not a Terrain - This script will only work on Terrains!");
            }
            else
            {
                isTerrain = true;
                TerrainData data = terrain.terrainData;
                pos = gO.transform.position;
                lastPos = pos;
                rot = gO.transform.rotation;
                internalY = gridHeightProp.floatValue;
                if (justStartedProp.boolValue)//If this script was just attached to the terrain, get the position for the cut area from the terrains position
                {
                    CalculatePoints(data);
                    justStartedProp.boolValue = false;
                }
                else //else the position is stored in the CutOutTerrain script and we get the position from there. This keeps the cut area from constantly resetting when we deselect the terrain.
                {
                    if (points == null)
                        points = new Vector3[pointsProp.arraySize];
                    else if (points.Length != pointsProp.arraySize)
                        System.Array.Resize<Vector3>(ref points, pointsProp.arraySize);

                    for (int i = 0; i < points.Length; i++)
                        points[i] = pointsProp.GetArrayElementAtIndex(i).vector3Value;
                }

            }
            serializedObject.ApplyModifiedProperties();
        }

        void OnDestroy()
        {
            serializedObject.Update();

            if (pointsProp.arraySize != points.Length)
                pointsProp.arraySize = points.Length;

            for (int i = 0; i < points.Length; i++)
                pointsProp.GetArrayElementAtIndex(i).vector3Value = points[i];

            serializedObject.ApplyModifiedProperties();
        }

        void OnSceneGUI()
        {
            if (isTerrain)
            {
                serializedObject.Update();
                Handles.color = mapColorProp.colorValue;
                pos = ((GameObject)gameObjectProperty.objectReferenceValue).transform.position;
                if (pos != lastPos)//Check if the terrain has moved -- shouldn't happen but just in case, we need to move our handles position.
                {

                    float changeX = pos.x - lastPos.x;
                    float changeZ = pos.z - lastPos.z;
                    float changeY = pos.y - lastPos.y;
                    Vector3 change = new Vector3(changeX, changeY, changeZ);

                    for (i = 0; i < points.Length; i++)
                        points[i] += change;
                    
                    lastPos = pos;
                }

                if (!Mathf.Approximately(gridHeightProp.floatValue, internalY))
                {
                    Vector3 change = new Vector3(0f, gridHeightProp.floatValue - internalY, 0f);
                    for (i = 0; i < points.Length; i++)
                        points[i] += change;

                    internalY = gridHeightProp.floatValue;
                }

                if (drawMapProp.boolValue)
                {
                    for (i = 0; i < 3; i++)
                        Handles.DrawLine(points[i], points[i + 1]);

                    //Complete the square by connecting Bottom Right and Bottom left point
                    Handles.DrawLine(points[0], points[3]);

                    //Now draw the inside lines				
                    for (i = 4; i < points.Length; i += 2)
                        Handles.DrawLine(points[i], points[i + 1]);
                }
            }
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.PropertyField(drawMapProp);

            if (drawMapProp.boolValue)
            {
                EditorGUILayout.PropertyField(gridHeightProp);
                EditorGUILayout.PropertyField(mapColorProp);
                EditorGUILayout.Space();

                EditorGUILayout.HelpBox("Update the grid if you have changed the detail resolution or detail resolution per patch settings on your terrain.", MessageType.Warning);
                if (GUILayout.Button("Update Grid"))
                    CalculatePoints(((GameObject)gameObjectProperty.objectReferenceValue).GetComponent<Terrain>().terrainData);
            }

            serializedObject.ApplyModifiedProperties();
        }

        void CalculatePoints(TerrainData data)
        {
            float width = data.size.x;
            float length = data.size.z;
            int detRes = data.detailResolution;
            int divisions = detRes / GetDetailResolutionPerPatch(data);
            int vectorLength = ((divisions - 1) * 4) + 4;
            points = new Vector3[vectorLength];
            int cutoff = vectorLength - ((divisions - 1) * 2);

            //Bottom left points
            points[0] = lastPos;

            //Top Left point
            points[1] = lastPos + new Vector3(0f, 0f, length);

            //Top Right Point
            points[2] = points[1] + new Vector3(width, 0f, 0f);

            //Bottom right point
            points[3] = lastPos + new Vector3(width, 0f, 0f);

            //The inside points
            float incrementX = width / divisions;
            float incrementZ = length / divisions;
            float posX = lastPos.x + incrementX;
            float posZ = lastPos.z + incrementZ;
            float x = lastPos.x;
            float x2 = x + width;
            float z = lastPos.z;
            float z2 = z + length;
            float y = lastPos.y;

            for (i = 4; i < points.Length; i += 2)
            {
                if (i < cutoff)
                {
                    points[i] = new Vector3(x, y, posZ);
                    points[i + 1] = new Vector3(x2, y, posZ);
                    posZ += incrementZ;
                }
                else
                {
                    points[i] = new Vector3(posX, y, z);
                    points[i + 1] = new Vector3(posX, y, z2);
                    posX += incrementX;
                }
            }

            float gridHeight = gridHeightProp.floatValue;
            Vector3 change = new Vector3(0f, gridHeight, 0f);
            for (i = 0; i < points.Length; i++)
                points[i] += change;

            if (pointsProp.arraySize != points.Length)
                pointsProp.arraySize = points.Length;

            for (int i = 0; i < points.Length; i++)
                pointsProp.GetArrayElementAtIndex(i).vector3Value = points[i];
        }

        int GetDetailResolutionPerPatch(TerrainData terrainData)
        {
            PropertyInfo propertyInfo = typeof(TerrainData).GetProperty("detailResolutionPerPatch", BindingFlags.NonPublic | BindingFlags.Instance);

            return (int)propertyInfo.GetValue(terrainData, null);
        }

    }
}
