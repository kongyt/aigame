//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    /// <summary>
    /// Specifies the type of an <see cref="ActiveGrid" href="ActiveGrid.html">Active Grid</see>.
    /// </summary>
    /// <title>ActiveGridType Enumeration</title>
    /// <category>Enums</category>
    /// <navigationName>ActiveGridType</navigationName>
    /// <fileName>ActiveGridType.html</fileName>
    /// <syntax>public enum ActiveGridType</syntax>
    /// <enumMember name="Outer_Ring_Grid">
    /// An Active Grid with an outer grid. The loaded cells include the inner grid (one ore more whole cells)
    /// and one or more rings of cells representing the outer grid.
    /// A minimum of 9 cells will be loaded at a time.
    /// </enumMember>
    /// <enumMember name="Sectioned_Grid">
    /// An Active Grid with a cell divided into four equal sections. The inner grid is the sectioned cell the player 
    /// is currently in. The loaded cells include the cell the inner grid is in, as well as the 3 cells that are "touching" 
    /// the inner grid. 4 (for 2D worlds) or 8 (for 3D worlds) cells will be loaded at a time.
    /// </enumMember>
    public enum ActiveGridType
    {
        Outer_Ring_Grid,
        Sectioned_Grid
    }

    /// <summary>
    /// Specifies which boundary was crossed by a tracked entity.
    /// <para>For 2D worlds, there are four boundaries (West, East, North, and South). Together these boundaries form a rectangle.
    /// For XZ worlds, this rectangle lies on the XZ plane, with the West boundary having the lowest X value and South boundary having
    /// the lowest Z value.</para>
    /// <para>For XY worlds, the West boundary still has the lowest X value, but the South boundary instead has the lowest Y value.</para>
    /// <para>For 3D worlds, the Top and Bottom boundaries are also used, forming a cube rather than a rectangle. The West and East are the
    /// boundaries with the lowest and highest X values respectively, the South and North are the boundaries with the lowest and highest
    /// Z values respectively, and the Bottom and Top are the boundaries with the lowest and highest Y values respectively.</para>
    /// </summary>
    /// <title>BoundaryCrossed Enumeration</title>
    /// <category>Enums</category>
    /// <navigationName>BoundaryCrossed</navigationName>
    /// <fileName>BoundaryCrossed.html</fileName>
    /// <syntax>public enum BoundaryCrossed</syntax>
    /// <enumMember name ="None">No boundary was crossed.</enumMember>
    /// <enumMember name ="West">West boundary was crossed.</enumMember>
    /// <enumMember name ="East">East boundary was crossed.</enumMember>
    /// <enumMember name ="North">North boundary was crossed.</enumMember>
    /// <enumMember name ="South">South boundary was crossed.</enumMember>
    /// <enumMember name ="Top">Top boundary was crossed (Only relevant when using 3D world).</enumMember>
    /// <enumMember name ="Bottom">Bottom boundary was crossed (Only relevant when using 3D world).</enumMember>
    public enum BoundaryCrossed 
    { 
        None, West, East, North, South, Top, Bottom 
    }

    /// <summary>
    /// Specifies object types for the cell objects used in the Dynamic Loading Kit.
    /// </summary>
    /// <title>CellObjectType Enumeration</title>
    /// <category>Enums</category>
    /// <navigationName>CellObjectType</navigationName>
    /// <fileName>CellObjectType.html</fileName>
    /// <syntax>public enum CellObjectType</syntax>
    /// <enumMember name ="Unity_Terrain">The objects are non Unity Terrains that do not have a Renderer Component.</enumMember>
    /// <enumMember name ="Other_Has_Renderer">The objects are Unity Terrains.</enumMember>
    /// <enumMember name ="Other_No_Renderer">The objects are non Unity Terrains that have a Renderer Component.</enumMember>
    public enum CellObjectType  { Unity_Terrain, Other_Has_Renderer, Other_No_Renderer }

    /// <summary>
    /// Specifies directions on the world.
    /// </summary>
    /// <title>Direction Enumeration</title>
    /// <category>Enums</category>
    /// <navigationName>Direction</navigationName>
    /// <fileName>Direction.html</fileName>
    /// <syntax>public enum Direction</syntax>
    /// <enumMember name ="West">West Direction (Along Negative X Axis)</enumMember>
    /// <enumMember name ="East">East Direction (Along Positive X Axis).</enumMember>
    /// <enumMember name ="North">North Direction (Along Positive Z (For XZ Worlds) or Y (For XY Worlds) Axes).</enumMember>
    /// <enumMember name ="South">South Direction (Along Negative Z (For XZ Worlds) or Y (For XY Worlds) Axes).</enumMember>
    /// <enumMember name ="Up">Up Direction (3D worlds only Along Positive Y Axis).</enumMember>
    /// <enumMember name ="Down">Down Direction (3D Worlds Only Along Negative Y Axis).</enumMember>
    public enum Direction       { West, East, North, South, Up, Down }

    /// <summary>
    /// Specifies a strategy for freeing memory.
    /// </summary>
    /// <title>MemoryFreeingStrategy Enumeration</title>
    /// <category>Enums</category>
    /// <navigationName>MemoryFreeingStrategy</navigationName>
    /// <fileName>MemoryFreeingStrategy.html</fileName>
    /// <syntax>public enum MemoryFreeingStrategy</syntax>
    /// <enumMember name ="Manual">Memory is not freed automatically. You have trigger it manually.</enumMember>
    /// <enumMember name ="Auto_UnloadUnusedResourcesOnly">Memory is freed automatically by calling the Resources.UnloadUnusedAssets method.</enumMember>
    /// <enumMember name ="Auto_GCCollectOnly">Memory is freed automatically by calling the System.GC.Collection method.</enumMember>
    /// <enumMember name ="Auto_Both">Memory is freed automatically by calling the Resources.UnloadUnusedAssets method as well as the System.GC.Collect method.</enumMember>
    public enum MemoryFreeingStrategy { Manual, Auto_UnloadUnusedResourcesOnly, Auto_GCCollectOnly, Auto_Both }

    /// <summary>
    /// Specifies the position of a terrain in relation to another terrain.
    /// </summary>
    /// <title>TerrainNeighbor Enumeration</title>
    /// <category>Enums</category>
    /// <navigationName>TerrainNeighbor</navigationName>
    /// <fileName>TerrainNeighbor.html</fileName>
    /// <syntax>public enum TerrainNeighbor</syntax>
    /// 
    /// <enumMember name ="Left">The terrain neighbor is to the left of the base terrain (along the X Axis).</enumMember>
    /// <enumMember name ="Top">The terrain neighbor is above the base terrain (along the Z Axis).</enumMember>
    /// <enumMember name ="Right">The terrain neighbor is to the right of the base terrain (along the X Axis).</enumMember>
    /// <enumMember name ="Bottom">The terrain neighbor is below the base terrain (along the Z Axis).</enumMember>
    public enum TerrainNeighbor { Left, Top, Right, Bottom }

    /// <summary>
    /// Specifies a type of world a World Grid (and the objects associated with that grid) is meant for.
    /// </summary>
    /// <title>WorldType Enumeration</title>
    /// <category>Enums</category>
    /// <navigationName>WorldType</navigationName>
    /// <fileName>WorldType.html</fileName>
    /// <syntax>public enum WorldType</syntax>
    /// <enumMember name ="Two_Dimensional_On_XY_Axes">A world with two dimensions. Columns are on the X axis while rows are on the Y axis (2D side scrolling games anyone?).</enumMember>
    /// <enumMember name ="Two_Dimensional_On_XZ_Axes">A world with two dimensions. Columns are on the X Axis while rows are on the Z Axis.</enumMember>
    /// <enumMember name ="Three_Dimensional">A world with three dimensions.
    /// <para>Columns are on the X axis, rows on the Z axis, and layers on the Y axis.</para></enumMember>
    public enum WorldType       { Two_Dimensional_On_XZ_Axes, Two_Dimensional_On_XY_Axes, Three_Dimensional }

    /// <summary>
    /// Specifies the state of a <see cref="World" href="World.html">World</see>.
    /// </summary>
    /// <title>WorldState Enumeration</title>
    /// <category>Enums</category>
    /// <navigationName>WorldState</navigationName>
    /// <fileName>WorldState.html</fileName>
    /// <syntax>public enum WorldState</syntax>
    /// <enumMember name ="Uninitialized">
    /// The initial state of the World, before it has been initialized by a component manager. If creating the world via 
    /// one of the component manager's create world methods, the world will never be in this state, since the component manager automatically 
    /// initializes the world when it is created.
    /// </enumMember>
    /// <enumMember name ="Idle">
    /// The state of the World after Initialization, while the world has no registered users and/or cell user request. Once the world exits the Idle 
    /// state, it will only enter it again if all users registered with the World unregister with it.
    /// </enumMember>
    /// <enumMember name ="WaitingForRequest">
    /// Standard phase when the World has no cell user add/remove request to process. Note that this is different than idle. While idle, 
    /// the World's update loop is suspended. In the WaitingForRequest state, the update loop is running (checking whether any new 
    /// requests have been received).
    /// </enumMember>
    ///  <enumMember name ="ProcessingRequest">
    /// The World enters this state when it has received cell user add and/or remove request. In this state, duplicate and/or offsetting 
    /// request are removed.
    /// </enumMember>
    /// <enumMember name ="UpdatingWorldWithoutShift">
    /// The World enters this state after processing a batch of cell user add/remove request, when at least one request
    /// survives the processing phase, and no origin shift is needed. In this state, objects are removed/added from the scene as needed.
    /// </enumMember>
    /// <enumMember name ="UpdatingWorldWithShift">
    /// The World enters this state after processing a batch of cell user add/remove request, when at least one request
    /// survives the processing phase, and an origin shift is needed. In this state, objects are removed/added from the scene as needed while 
    /// the origin shift is simultaneously processed. During this state any Active Grids registered with the World are notified so they can 
    /// enter a 'busy' state until the shift is complete.
    /// </enumMember>
    /// <enumMember name ="UpdatingWorldWithExplicitOriginCellUpdate">
    /// The World enters this state after processing a batch of cell user add/remove request, when at least one request
    /// survives the processing phase, and an expicit origin cell update has been requested. In this state, objects are removed/added from the scene 
    /// as needed, while the origin cell is simultaneously updated. This only occurs when you use the 
    /// <see cref="ActiveGrid.TryMakeCellOriginCell" href="ActiveGrid.html#TryMakeCellOriginCell">TryMakeCellOriginCell</see> method of the Active Grid 
    /// component. During this state any Active Grids registered with the World are notified so they can 
    /// enter a 'busy' state until the cell update is complete.
    /// </enumMember>
    /// <enumMember name ="CompletingWorldShift">
    /// The World enters this state after updating the origin cell (either explicitly or via an origin shift). During this state, the world 
    /// notifies any registered users that an origin shift or explicit update has occured. Active Grids receive a special notification that triggers 
    /// the change in position of the player associated with the Active Grid. The active grids also exit their 'busy' state at this time so other 
    /// multi-frame actions can be called.
    /// </enumMember>
    public enum WorldState      { Uninitialized, Idle, WaitingForRequest, ProcessingRequest, UpdatingWorldWithoutShift, UpdatingWorldWithShift, UpdatingWorldWithExplicitOriginCellUpdate, CompletingWorldShift }

    internal enum MultiFrameActionType { OriginCellChange, WorldShift, Desync, MoveToLocation, SyncToNewWorld, SyncToNewWorldAroundPlayer, MoveToLocationAndSyncToNewWorld }
}