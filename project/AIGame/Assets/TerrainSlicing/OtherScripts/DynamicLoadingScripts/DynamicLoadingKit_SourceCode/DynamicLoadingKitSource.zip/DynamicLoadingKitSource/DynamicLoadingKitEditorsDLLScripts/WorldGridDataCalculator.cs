//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
	using UnityEngine;
	using UnityEditor;
	using DynamicLoadingKit;
    using System;

    internal enum BoundsComponent { x, y, z }

    internal class WorldGridDataCalculator : IWorldGridDataRetriever
    {
        GridValues<int> gridDimensions;
        GridValues<float> defaultGridMeasurements;

        float[] rowLengths, columnWidths, layerHeights;
        bool[] emptyGridLocations, lengthFoundForRow, widthFoundForColumn, heightFoundForLayer;

        bool loadPrefabsFromResourcesFolder;

        string worldGridName, loadReadyPrefabFolderPath;
        WorldType worldType;
        CellObjectType cellObjectType;

        Func<int, int, int, string> GetProgressBarText;

        PrefabProcessor prefabProcessor;
        INamingConvention namingConvention;

        internal WorldGridDataCalculator(string loadReadyPrefabFolderPath, string worldGridName,
            CellObjectType cellObjectType, WorldType worldType,
            GridValues<int> gridDimensions, GridValues<float> defaultGridMeasurements, INamingConvention namingConvention)
        {
            this.loadReadyPrefabFolderPath = loadReadyPrefabFolderPath;
            loadPrefabsFromResourcesFolder = loadReadyPrefabFolderPath == null ? true : false;

            this.worldType = worldType;
            this.worldGridName = worldGridName;
            this.defaultGridMeasurements = defaultGridMeasurements;
            this.cellObjectType = cellObjectType;
            this.namingConvention = namingConvention;

            if (worldType == WorldType.Three_Dimensional)
            {
                GetProgressBarText = (layer, row, column) => string.Format("Layer {0}, Row {1}, Column {2}", layer, row, column);
                this.gridDimensions = gridDimensions;
            }
            else
            {
                GetProgressBarText = (layer, row, column) => string.Format("Row {1}, Column {2}", layer, row, column);
                this.gridDimensions = new GridValues<int>(1, gridDimensions.rowValue, gridDimensions.columnValue);
            }

            GridValues<BoundsComponent> boundsComponents;
            if (worldType == WorldType.Three_Dimensional || worldType == WorldType.Two_Dimensional_On_XZ_Axes)
                boundsComponents = new GridValues<BoundsComponent>(BoundsComponent.y, BoundsComponent.z, BoundsComponent.x);
            else
                boundsComponents = new GridValues<BoundsComponent>(BoundsComponent.z, BoundsComponent.y, BoundsComponent.x);

            prefabProcessor = new PrefabProcessor(this, boundsComponents);
        }



        internal sealed override WorldGridSetupData RetrieveWorldGridData()
        {
            CreateSpaceForArrays();
            int layers = gridDimensions.layerValue, rows = gridDimensions.rowValue, columns = gridDimensions.columnValue;
            float incrementAmount = 1f / (layers * rows * columns);
            float progress = 0f;

            for (int layer = 0; layer < layers; layer++)
            {
                for (int row = 0; row < rows; row++)
                {
                    for (int column = 0; column < columns; column++)
                    {
                        prefabProcessor.ProcessPrefabForCell(layer, row, column);

#if UNITY_4
                        EditorUtility.UnloadUnusedAssets();
                        GC.Collect();
                        EditorApplication.SaveScene();
#else
                        EditorUtility.UnloadUnusedAssetsImmediate();
                        GC.Collect();
                        UnityEditor.SceneManagement.EditorSceneManager.SaveOpenScenes();
#endif
#if UNITY_4 || UNITY_5_3_5
                        EditorApplication.SaveAssets();
#else
                        AssetDatabase.SaveAssets();
#endif

                        progress += incrementAmount;
                        EditorUtility.DisplayProgressBar("Calculating Data", GetProgressBarText(layer + 1, row + 1, column + 1), progress);
                    }
                }
            }

            EditorUtility.ClearProgressBar();

            FillMissingData();

            if (!WasAtLeastOnePrefabFoundInFolder())
                Debug.LogWarning("Data could not be calculated from prefabs. Please ensure the prefabs are named correctly, and that the prefab is " +
                    "a terrain or has a Renderer component");

            return new WorldGridSetupData(emptyGridLocations, layerHeights, rowLengths, columnWidths);
        }

        bool WasAtLeastOnePrefabFoundInFolder()
        {
            return !emptyGridLocations.AreAllValuesTrue();
        }

        void CreateSpaceForArrays()
        {
            int layers = gridDimensions.layerValue, rows = gridDimensions.rowValue, columns = gridDimensions.columnValue;
            rowLengths = new float[rows];
            columnWidths = new float[columns];

            lengthFoundForRow = new bool[rows];
            widthFoundForColumn = new bool[columns];

            if (worldType == WorldType.Three_Dimensional)
            {
                layerHeights = new float[layers];
                heightFoundForLayer = new bool[layers];
            }

            emptyGridLocations = new bool[rows * columns * layers];
        }

        void FillMissingData()
        {
            FillMissingDataWithDefaultValue(widthFoundForColumn, columnWidths, defaultGridMeasurements.columnValue);
            FillMissingDataWithDefaultValue(lengthFoundForRow, rowLengths, defaultGridMeasurements.rowValue);

            if (worldType == WorldType.Three_Dimensional)
                FillMissingDataWithDefaultValue(heightFoundForLayer, layerHeights, defaultGridMeasurements.layerValue);
        }
        //Sets missing data to default and returns true if there was missing data, or false if there wasn't
        void FillMissingDataWithDefaultValue(bool[] doesDataExist, float[] data, float defaultValue)
        {
            for (int i = 0; i < data.Length; i++)
            {
                if (!doesDataExist[i])
                {
                    data[i] = defaultValue;
                }
            }
        }

        

        class PrefabProcessor
        {
            DimensionGetter dimensionGetter;

            Func<int, int, int, GameObject> GetPrefab;
            Func<int, int, int, int> GetEmptyGridLocationIndex;
            Func<GameObject, Component> GetComponentFromGameObject;

            WorldGridDataCalculator parent;
            string formatString;
            bool subtract1FromIndexes;

            public PrefabProcessor(WorldGridDataCalculator parent, GridValues<BoundsComponent> boundsComponents)
            {
                this.parent = parent;
                subtract1FromIndexes = parent.namingConvention.NumberingStartsAt0;


                if (parent.cellObjectType == CellObjectType.Unity_Terrain)
                {
                    dimensionGetter = new TerrainDimensionGetter();
                    GetComponentFromGameObject = gameObject => gameObject.GetComponent(typeof(Terrain)) as Terrain;
                }
                else if(parent.cellObjectType == CellObjectType.Other_Has_Renderer)
                {
                    dimensionGetter = new RendererDimensionGetter(boundsComponents);
                    GetComponentFromGameObject = gameObject => gameObject.GetComponent(typeof(Renderer)) as Renderer;
                }
                

                if (parent.worldType == WorldType.Three_Dimensional)
                {
                    if (parent.loadPrefabsFromResourcesFolder)
                        GetPrefab = Load3DObjectFromResourcesFolder;
                    else
                        GetPrefab = Load3DObjectFromNormalFolder;

                    formatString = parent.namingConvention.GetStringFormatVersion(true, parent.worldGridName);

                    GetEmptyGridLocationIndex = (layer, row, column) => (row * parent.gridDimensions.columnValue + column) + (parent.gridDimensions.columnValue * parent.gridDimensions.rowValue * layer);
                }
                else
                {
                    if (parent.loadPrefabsFromResourcesFolder)
                        GetPrefab = Load2DObjectFromResourcesFolder;
                    else
                        GetPrefab = Load2DObjectFromRegularFolder;

                    formatString = parent.namingConvention.GetStringFormatVersion(false, parent.worldGridName);

                    GetEmptyGridLocationIndex = (layer, row, column) => row * parent.gridDimensions.columnValue + column;
                }
            }

            GameObject Load3DObjectFromResourcesFolder(int layer, int row, int column)
            {
                if(subtract1FromIndexes)
                {
                    layer--;
                    row--;
                    column--;
                }
                string assetToLoad = Get3DObjectName(layer, row, column);
                return Resources.Load(assetToLoad) as GameObject;
            }
            
            GameObject Load3DObjectFromNormalFolder(int layer, int row, int column)
            {
                if (subtract1FromIndexes)
                {
                    layer--;
                    row--;
                    column--;
                }
                string assetToLoad = parent.loadReadyPrefabFolderPath + Get3DObjectName(layer, row, column) + ".prefab";
                #if UNITY_4
                return Resources.LoadAssetAtPath(assetToLoad, typeof(GameObject)) as GameObject;
                #else
                return AssetDatabase.LoadAssetAtPath<GameObject>(assetToLoad);
                #endif
            }

            string Get3DObjectName(int layer, int row, int column)
            {
                return string.Format(formatString, column, row, layer);
            }

            GameObject Load2DObjectFromResourcesFolder(int layer, int row, int column)
            {
                if (subtract1FromIndexes)
                {
                    row--;
                    column--;
                }
                string assetToLoad = Get2DObjectName(row, column);
                return Resources.Load(assetToLoad) as GameObject;
            }

            GameObject Load2DObjectFromRegularFolder(int layer, int row, int column)
            {
                if (subtract1FromIndexes)
                {
                    row--;
                    column--;
                }
                string assetToLoad = parent.loadReadyPrefabFolderPath + Get2DObjectName(row, column) + ".prefab";
#if UNITY_4
                return Resources.LoadAssetAtPath(assetToLoad, typeof(GameObject)) as GameObject;
#else
                return AssetDatabase.LoadAssetAtPath<GameObject>(assetToLoad);
#endif
            }

            string Get2DObjectName(int row, int column)
            {
                return string.Format(formatString, column, row);
            }

            public void ProcessPrefabForCell(int cellLayer, int cellRow, int cellColumn)
            {
                GameObject gameObject = GetPrefab(cellLayer + 1, cellRow + 1, cellColumn + 1);
                int indexInEmptyGridArray = GetEmptyGridLocationIndex(cellLayer, cellRow, cellColumn);

                if (gameObject != null)
                {
                    parent.emptyGridLocations[indexInEmptyGridArray] = false; //location is not empty

                    if (parent.cellObjectType == CellObjectType.Other_No_Renderer)
                        SetDataUsingDefaultValues(cellLayer, cellRow, cellColumn);
                    else
                    {
                        Component component = null;
                        component = GetComponentFromGameObject(gameObject);

                        if (component != null)
                        {
                            SetDataUsingComponent(component, cellLayer, cellRow, cellColumn);
                            component = null;
                        }
                    }                        

                    gameObject = null;
                }
                else
                    parent.emptyGridLocations[indexInEmptyGridArray] = true; //location is empty

            }

            void SetDataUsingComponent(Component component, int cellLayer, int cellRow, int cellColumn)
            {
                //Check if we need the current column and/or row's width/length, and get them if so.
                if (!parent.lengthFoundForRow[cellRow])
                {
                    parent.rowLengths[cellRow] = dimensionGetter.GetLength(component);
                    parent.lengthFoundForRow[cellRow] = true;
                }

                if (!parent.widthFoundForColumn[cellColumn])
                {
                    parent.columnWidths[cellColumn] = dimensionGetter.GetWidth(component);
                    parent.widthFoundForColumn[cellColumn] = true;
                }

                if (parent.worldType == WorldType.Three_Dimensional && !parent.heightFoundForLayer[cellLayer])
                {
                    parent.layerHeights[cellLayer] = dimensionGetter.GetHeight(component);
                    parent.heightFoundForLayer[cellLayer] = true;
                }
            }

            void SetDataUsingDefaultValues(int cellLayer, int cellRow, int cellColumn)
            {
                //Check if we need the current column and/or row's width/length, and get them if so.
                if (!parent.lengthFoundForRow[cellRow])
                {
                    parent.rowLengths[cellRow] = parent.defaultGridMeasurements.rowValue;
                    parent.lengthFoundForRow[cellRow] = true;
                }

                if (!parent.widthFoundForColumn[cellColumn])
                {
                    parent.columnWidths[cellColumn] = parent.defaultGridMeasurements.columnValue;
                    parent.widthFoundForColumn[cellColumn] = true;
                }

                if (parent.worldType == WorldType.Three_Dimensional && !parent.heightFoundForLayer[cellLayer])
                {
                    parent.layerHeights[cellLayer] = parent.defaultGridMeasurements.layerValue;
                    parent.heightFoundForLayer[cellLayer] = true;
                }
            }
        }
    }
}