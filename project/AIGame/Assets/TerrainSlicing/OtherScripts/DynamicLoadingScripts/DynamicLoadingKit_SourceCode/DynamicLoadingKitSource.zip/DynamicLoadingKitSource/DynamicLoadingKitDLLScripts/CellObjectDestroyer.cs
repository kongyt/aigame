﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.

using UnityEngine;
using System.Collections.Generic;

namespace DynamicLoadingKit
{
    /// <summary>
    /// Provides a base implementation for Cell Object Destroyers.
    /// <para>Cell Object Destroyers can be used to customize the destruction strategy used by the DLK. Basically, whenever an object
    /// needs to be destroyed, rather than calling GameObject.Destroy on the object (the default behaviour when no Cell Object Destroyer is present),
    /// the object will be passed off to the Cell Object Destroyer.</para>
    /// <para>This allows you to create custom destruction solutions that fit your particular child-parent hiearchy.</para>
    /// <para>For instance,
    /// you can create a destroyer that destroys all grandchildren in one frame, then all those grandchildren's parents in the next frame, and finally
    /// the root game object in the last frame.</para>
    /// <para>The Destroyer must be supplied in the "Cell Object Destroyer" option in the inspector of whatever
    /// <see cref="PrimaryCellObjectSubController" href = "PrimaryCellObjectSubController.html">PrimaryCellObjectSubController</see> Component you are using.</para>
    /// </summary>
    /// <title>CellObjectDestroyer Abstract Class</title>
    /// <category>Secondary Components</category>
    /// <navigationName>CellObjectDestroyer</navigationName>
    /// <fileName>CellObjectDestroyer.html</fileName>
    /// <syntax>public abstract class CellObjectDestroyer : MonoBehaviour</syntax>
    public abstract class CellObjectDestroyer : MonoBehaviour
    {
        /// <summary>
        /// When overridden by a derived class, can be used to destroy a cell object in a more performant manner than simply using GameObject.Destroy.
        /// </summary>
        /// <param name="cellObject" type = "GameObject">The cell object that needs to be destroyed.</param>
        /// <displayName id="DestroyCellObject">DestroyCellObject(GameObject)</displayName>
        /// <syntax>public abstract IEnumerator&lt;YieldInstruction&gt; DestroyCellObject(GameObject cellObject)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public abstract IEnumerator<YieldInstruction> DestroyCellObject(GameObject cellObject);
    }

    /// <summary>
    /// Provides a simple implementation for a Cell Object Destroyer, 
    /// which destroys a specific number of child objects (one level deep) per frame. 
    /// <para>The root object is only destroyed after all children have been destroyed.</para>
    /// <para>As the name implies, this is a rather simple implementation, and is not suitable for more complex child-parent hiearchies.
    /// In those cases, it is recommended to create a custom Cell Object Destroyer.</para>
    /// </summary>
    /// <title>SimpleCellObjectDestroyer Class</title>
    /// <category>Secondary Components</category>
    /// <navigationName>SimpleCellObjectDestroyer</navigationName>
    /// <fileName>SimpleCellObjectDestroyer.html</fileName>
    /// <syntax>public class SimpleCellObjectDestroyer : <see cref="CellObjectDestroyer" href = "CellObjectDestroyer.html">CellObjectDestroyer</see></syntax>
    /// <inspector name = "Children To Destroy Per Frame" type = "int">The number of children to destroy per frame.</inspector>
    [AddComponentMenu("Dynamic Loading Kit/Secondary Components/Simple Cell Object Destroyer")]
    public sealed class SimpleCellObjectDestroyer : CellObjectDestroyer
    {
        [SerializeField]
        int childrenToDestroyPerFrame = 3;

        /// <summary>
        /// Destroys x children per frame, where x is whatever you set the "Children To Destroy Per Frame" option in the insepctor to.
        /// </summary>
        /// <param name="cellObject" type = "GameObject">The cell object that needs to be destroyed.</param>
        /// <displayName id="DestroyCellObject">DestroyCellObject(GameObject)</displayName>
        /// <syntax>public sealed override IEnumerator&lt;YieldInstruction&gt; DestroyCellObject(GameObject cellObject)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public sealed override IEnumerator<YieldInstruction> DestroyCellObject(GameObject cellObject)
        {
            Transform cellObjectTransform = cellObject.transform;

            int children = cellObjectTransform.childCount;

            while (true)
            {
                int max = children < childrenToDestroyPerFrame ? children : childrenToDestroyPerFrame;
                for (int i = 0; i < max; i++, children--)
                    Destroy(cellObjectTransform.GetChild(i).gameObject);

                if(children == 0)
                {
                    Destroy(cellObject);
                    yield break;
                }
                else
                    yield return null;
            }
        }
    }
}