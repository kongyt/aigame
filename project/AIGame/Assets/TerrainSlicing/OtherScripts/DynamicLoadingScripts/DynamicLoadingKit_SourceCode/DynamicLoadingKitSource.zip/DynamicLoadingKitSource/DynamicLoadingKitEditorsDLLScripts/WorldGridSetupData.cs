//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    internal struct WorldGridSetupData
    {
        internal WorldGridSetupData(bool[] emptyGridLocations, float[] layerHeights, float[] rowLengths, float[] columnWidths)
            : this()
        {
            EmptyGridLocations = emptyGridLocations;
            ColumnWidths = columnWidths;
            RowLengths = rowLengths;
            LayerHeights = layerHeights;
        }

        internal bool[] EmptyGridLocations { get; private set; }
        internal float[] ColumnWidths { get; private set; }
        internal float[] RowLengths { get; private set; }
        internal float[] LayerHeights { get; private set; }
    }
}