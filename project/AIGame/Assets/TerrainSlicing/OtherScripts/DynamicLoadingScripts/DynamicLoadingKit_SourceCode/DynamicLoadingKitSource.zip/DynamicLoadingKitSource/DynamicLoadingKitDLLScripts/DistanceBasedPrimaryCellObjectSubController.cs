﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;

#if !UNITY_4
    using UnityEngine.SceneManagement;
#endif

    /// <summary>
    /// Provides an implementation for a Primary Cell Object Sub Controller that deactivates cell objects when they are not in 
    /// use until the cells those objects belong to are a specified distance from the active cell the player is in (when they 
    /// are destroyed).
    /// </summary>
    /// <title>DistanceBasedPrimaryCellObjectSubController Class</title>
    /// <category>Sub Controllers</category>
    /// <navigationName>DistanceBasedPrimaryCellObjectSubController</navigationName>
    /// <fileName>DistanceBasedPrimaryCellObjectSubController.html</fileName>
    /// <syntax>
    /// public sealed class DistanceBasedPrimaryCellObjectSubController : 
    /// <see cref="PrimaryCellObjectSubController" href="PrimaryCellObjectSubController.html">PrimaryCellObjectSubController</see>
    /// </syntax>
    /// <inspector name="Active Grids" type="ActiveGrid[]">
    /// The active grids to use to determine the distance checks. Have to provide them in order to subscribe to their 
    /// CellPlayerIsInChanged event.
    /// </inspector>
    /// <inspector name="Distance To Destroy Objects" type="int">
    /// When the cell a deactivated object belongs to is this distance away from the cell the player is in, it will be destroyed.
    /// </inspector>
    /// <inspector name="Check Frequency" type="float">
    /// When an object is determined to be obsolete, it is added to a list. This component periodically checks to see if 
    /// there are any obsolete objects. This value determines the frequency of the check.
    /// </inspector>
    [AddComponentMenu("Dynamic Loading Kit/Sub Controllers/Distance Based Primary Cell Object Controller")]
    public sealed class DistanceBasedPrimaryCellObjectSubController : PrimaryCellObjectSubController
    {
        //assign active grids. It's likely you will only have one, but it is theoretically possible for 
        //multiple active grids to exist, and we'd like to support all of them using a single 
        //DistanceBasedPrimaryCellObjectSubController component in the single.
        [SerializeField]
        ActiveGrid[] activeGrids;

        //objects destroyed when their distance from cell player is in is >= to this value
        [SerializeField]
        int distanceToDestroyObjects = 8;

        [SerializeField]
        float checkFrequency = 5f;

        List<ObsoleteObject> obsoleteObjectsToDestroy = new List<ObsoleteObject>();
        WaitForSeconds waitYield;

        void Start()
        {
            waitYield = new WaitForSeconds(checkFrequency);

            //try to retrieve AGs from this game object if none are assigned via the inspector.
            if (activeGrids == null || activeGrids.Length == 0)
                activeGrids = GetComponents<ActiveGrid>();

            if (activeGrids == null || activeGrids.Length == 0)
                throw new System.Exception("No Active Grids found. One is needed for this component to work properly.");

            for (int i = 0; i < activeGrids.Length; i++)
            {
                if (activeGrids[i] != null)
                    activeGrids[i].CellPlayerIsInChanged += OnCellPlayerIsInChanged;
            }

            StartCoroutine(DestroyObsoleteObjects());
        }

        IEnumerator<YieldInstruction> DestroyObsoleteObjects()
        {
            //run forever
            while (true)
            {
                if (obsoleteObjectsToDestroy.Count == 0)
                    yield return waitYield;
                else
                {
                    for (int i = 0; i < obsoleteObjectsToDestroy.Count; i++)
                    {
                        DistanceBasedPrimaryCellObjectSubControllerUser user = (DistanceBasedPrimaryCellObjectSubControllerUser)RegisteredUsers[obsoleteObjectsToDestroy[i].userID];

                        GameObject primaryCellObjectWhichIsObsolete;

                        //It's unlikely but possible that there are duplicate obsolete objects and/or that 
                        //a user has come along and retrieved one of the obsolete objects, so we need to 
                        //make sure it is still there.
                        if (user.Pool.TryGetValue(obsoleteObjectsToDestroy[i].owningCell, out primaryCellObjectWhichIsObsolete))
                        {
                            user.Pool.Remove(obsoleteObjectsToDestroy[i].owningCell);
                            IEnumerator<YieldInstruction> destroyEnumerator = DestroyObject(primaryCellObjectWhichIsObsolete);

                            while (destroyEnumerator.MoveNext())
                                yield return destroyEnumerator.Current;
                        }
                    }
                    obsoleteObjectsToDestroy.Clear();
                }
            }
        }

        //If you are planning to destroy this component and not the Active Grid, you should unsubscribe from the 
        //Active Grid. This is unlikely however so I will leave commented.
        //void OnDestroy()
        //{
        //    for (int i = 0; i < activeGrids.Length; i++)
        //    {
        //        if (activeGrids[i] != null)
        //            activeGrids[i].CellPlayerIsInChanged -= OnCellPlayerIsInChanged;
        //    }
        //}

        //Here we will do the distance check and mark objects as obsolete. The actual destruction will 
        //occur in the DestroyObsoleteObjects coroutine, for performance reasons.

        //Ideally we would only do this for the user connected to the Active Grid in the sender argument, 
        //but it is not possible to make that connection right now, so we'll just check all users (which is 
        //likely just a single user).
        void OnCellPlayerIsInChanged(object sender, CellPlayerIsInChangedEventArgs args)
        {
            ActiveGrid ag = (ActiveGrid)sender;

            DistanceBasedPrimaryCellObjectSubControllerUser user = (DistanceBasedPrimaryCellObjectSubControllerUser)RegisteredUsers[ag.WorldSyncedTo.PrimaryCellObjectSubControllerID];

            user.cellPlayerIsIn = args.EndlessGridCellPlayerIsIn;
            
            //iterate over all the cells in the pool
            Dictionary<Cell, GameObject>.Enumerator allCellsEnumerator = user.Pool.GetEnumerator();
            while (allCellsEnumerator.MoveNext())
            {
                Cell owningCell = allCellsEnumerator.Current.Key;
                int distanceFromCellPlayerIsIn = user.CalculateDistanceBetweenCells(user.cellPlayerIsIn, owningCell);

                if (distanceFromCellPlayerIsIn >= distanceToDestroyObjects)
                    obsoleteObjectsToDestroy.Add(new ObsoleteObject(user.LoaderID, owningCell));
            }
        }

        //Users are required because more than one World may utilize a single Primary Cell Object Sub Controller.
        //Users store per user data such as the object names to load for the World
        //This method is called when a user registers with the controller.
        /// <summary>
        /// Creates a new DistanceBasedPrimaryCellObjectSubControllerUser, which is a custom type which derives 
        /// from PrimaryCellObjectSubControllerUser. This user object contains an object pool 
        /// used specifically by this class.
        /// </summary>
        /// <param name="cellObjectGroup" type="ICellObjectGroup" link="ICellObjectGroup.html">
        /// The cell object group being registered.
        /// </param>
        /// <param name="loaderID" type="int">
        /// The loaderID assigned to the sub controller when it registered with the Cell Object Loader it is using.
        /// </param>
        /// <displayName id = "CreateNewUser">CreateNewUser(ICellObjectGroup, int)</displayName>
        /// <syntax>protected sealed override PrimaryCellObjectSubControllerUser CreateNewUser(ICellObjectGroup cellObjectGroup, int loaderID)</syntax>
        /// <returns type = "PrimaryCellObjectSubControllerUser">A new user object created using the worldAssociatedWithUser as input.</returns>
        protected sealed override PrimaryCellObjectSubControllerUser CreateNewUser(ICellObjectGroup cellObjectGroup, int loaderID)
        {
            return new DistanceBasedPrimaryCellObjectSubControllerUser(cellObjectGroup, loaderID);
        }

        /// <summary>
        /// Attaches the objects associated with the input cells to the cells in a single frame. 
        /// Looks for the objects in the pool first, and if not found, loads the 
        /// objects into the scene via the Cell Object Loader.
        /// <para
        /// >Note that T must implement the 
        /// <see cref="IAttachableWorldCell" href = "IAttachableWorldCell.html">IAttachableWorldCell</see> interface.
        /// </para>
        /// </summary>
        /// <typeparam name="T">
        /// The type of the cells.
        /// </typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">
        /// The cells whose objects need to be attached.
        /// </param>
        /// <param name="primaryCellObjectSubControllerID" type="int">
        /// The ID of the user requesting the attachment.
        /// </param>
        /// <displayName id="AttachCellObjectsToCellsInSingleFrame">
        /// AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt;, int)
        /// </displayName>
        /// <syntax>
        /// public sealed override void AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID)
        /// </syntax>
        public sealed override void AttachCellObjectsToCellsInSingleFrame<T>(List<T> cells, int primaryCellObjectSubControllerID)
        {
            DistanceBasedPrimaryCellObjectSubControllerUser user = (DistanceBasedPrimaryCellObjectSubControllerUser)RegisteredUsers[primaryCellObjectSubControllerID];
            for (int i = cells.Count - 1; i >= 0; i--)
            {
                GameObject primaryCellObject;
                if (user.Pool.TryGetValue(cells[i].CellOnEndlessGrid, out primaryCellObject))
                {
                    cells[i].AttachCellObjectToCell(primaryCellObject, false);
                    user.Pool.Remove(cells[i].CellOnEndlessGrid);
                    gameObject.SetActive(true);
                    cells.RemoveAt(i);
                }
            }

            //If there are cells whose primary cell objects were not in the pool, then we need to create new 
            //objects via the cell object loader
            if (cells.Count > 0)
                CellObjectLoader.AttachCellObjectsToCellsInSingleFrame<T>(cells, user.LoaderID);
        }

        /// <summary>
        /// Attaches the objects associated with the input cells to the cells over a period of frames. Looks for the objects 
        /// in the pool first, and if not found, has the Cell Object Loader load them into the scene.
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be attached.</param>
        /// <param name="primaryCellObjectSubControllerID" type = "int">The ID of the user requesting the attachment.</param>
        /// <displayName id = "AttachCellObjectsToCells">AttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override IEnumerator&lt;YieldInstruction&gt; AttachCellObjectsToCells&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public sealed override IEnumerator<YieldInstruction> AttachCellObjectsToCells<T>(List<T> cells, int primaryCellObjectSubControllerID)
        {
            DistanceBasedPrimaryCellObjectSubControllerUser user = (DistanceBasedPrimaryCellObjectSubControllerUser)RegisteredUsers[primaryCellObjectSubControllerID];
            for (int i = cells.Count - 1; i >= 0; i--)
            {
                GameObject primaryCellObject;
                if (user.Pool.TryGetValue(cells[i].CellOnEndlessGrid, out primaryCellObject))
                {
                    cells[i].AttachCellObjectToCell(primaryCellObject, false);
                    user.Pool.Remove(cells[i].CellOnEndlessGrid);
                    gameObject.SetActive(true);
                    cells.RemoveAt(i);
                }
            }

            if (cells.Count > 0)
            {
                IEnumerator<YieldInstruction> e = CellObjectLoader.LoadAndAttachCellObjectsToCells<T>(cells, user.LoaderID);
                while (e.MoveNext())
                    yield return e.Current;
            }
        }

        /// <summary>
        /// Detaches and pools the objects associated with the input cells over a period of frames. If there is not enough room 
        /// in the pool for an object, it is destroyed instead.
        /// </summary>
        /// <typeparam name="T">The type of the cells.</typeparam>
        /// <param name="deactivatedCells" type = "List&lt;T&gt;">The cells whose objects need to be detached and processed.</param>
        /// <param name="primaryCellObjectSubControllerID" type = "int">The ID of the user requesting the detachment and processing.</param>
        /// <displayName id = "DetachAndProcessCellObjectsFromDeactivatedCells">DetachAndProcessCellObjectsFromDeactivatedCells&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public sealed override IEnumerator&lt;YieldInstruction&gt; DetachAndProcessCellObjectsFromDeactivatedCells&lt;T&gt;(List&lt;T&gt; cells, int primaryCellObjectSubControllerID)</syntax>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        public sealed override IEnumerator<YieldInstruction> DetachAndProcessCellObjectsFromDeactivatedCells<T>(List<T> deactivatedCells, int primaryCellObjectSubControllerID)
        {
            DistanceBasedPrimaryCellObjectSubControllerUser user = (DistanceBasedPrimaryCellObjectSubControllerUser)RegisteredUsers[primaryCellObjectSubControllerID];

            int count = deactivatedCells.Count;
            bool somethingDestroyed = false;

            foreach (T cell in deactivatedCells)
            {
                GameObject primaryCellObject = cell.DetachCellObjectFromCell();
                primaryCellObject.SetActive(false);

                //object exist already, so destroy copy
                //This shouldn't happen if you are not using an endless world, but I'll leave it here 
                //in case you want to modify the code to work with an endless world. In that case, it would be better 
                //to somehow store both objects and use the cells EndlessGridCell value as key rather than WorldGridCell 
                //value, but that is not currently possible in this version of the kit.

                //Also destroy if the distance from the cell the player is in is greater than or equal to the 
                //distance at which objects should be destroyed.
                if (user.Pool.ContainsKey(cell.CellOnEndlessGrid) || user.CalculateDistanceBetweenCells(cell.CellOnEndlessGrid, user.cellPlayerIsIn) >= distanceToDestroyObjects)
                {
                    somethingDestroyed = true;
                    IEnumerator<YieldInstruction> destroyEnumerator = DestroyObject(primaryCellObject);
                    while (destroyEnumerator.MoveNext())
                        yield return destroyEnumerator.Current;
                }
                else
                {
                    user.Pool[cell.CellOnEndlessGrid] = primaryCellObject;
                }
            }

            if (somethingDestroyed)
                ApplyMemoryFreeingStrategy();

            yield break;
        }

        IEnumerator<YieldInstruction> DestroyObject(GameObject primaryCellObject)
        {
            if (CellObjectDestroyer != null)
            {
                IEnumerator<YieldInstruction> destroyEnumerator = CellObjectDestroyer.DestroyCellObject(primaryCellObject);
                while (destroyEnumerator.MoveNext())
                    yield return destroyEnumerator.Current;

                if (YieldForTime != null)
                    yield return YieldForTime;
            }
            else
            {
#if !UNITY_4
                Scene sceneCellBelongsTo = primaryCellObject.scene;
                //indicates the user is using scene loading (rather than say, prefab loading), as the scene name 
                //would be different if not.
                if (sceneCellBelongsTo.name == primaryCellObject.name)
                {
                    yield return SceneManager.UnloadSceneAsync(sceneCellBelongsTo);
                }
                else
                    Destroy(primaryCellObject);
#else
                    Destroy(primaryCellObject);
                    if (YieldForTime != null)
                        yield return YieldForTime;
#endif
            }
        }

        class DistanceBasedPrimaryCellObjectSubControllerUser : PrimaryCellObjectSubControllerUser
        {
            public Dictionary<Cell, GameObject> Pool { get; private set; }
            public Func<Cell, Cell, int> CalculateDistanceBetweenCells { get; private set; }
            public Cell cellPlayerIsIn;

            int rows, columns, layers, cellsPerLayer;

            public DistanceBasedPrimaryCellObjectSubControllerUser(ICellObjectGroup cellObjectGroup, int loaderID)
                : base(cellObjectGroup, loaderID)
            {
                EqualityComparer<Cell> cellComparer;

                WorldGridBase worldGrid = cellObjectGroup.World.WorldGrid;

                rows = worldGrid.Rows;
                columns = worldGrid.Columns;
                cellsPerLayer = rows * columns;
                if (worldGrid.WorldType == WorldType.Three_Dimensional)
                {
                    cellComparer = new ThreeDimensionalCellComparer();
                    CalculateDistanceBetweenCells = CalculateDistanceBetweenCells3D;
                    layers = worldGrid.Layers;
                }
                else
                {
                    cellComparer = new TwoDimensionalCellComparer();
                    CalculateDistanceBetweenCells = CalculateDistanceBetweenCells2D;
                    layers = 1;
                }

                Pool = new Dictionary<Cell, GameObject>(cellComparer);
            }
            
            int CalculateDistanceBetweenCells2D(Cell cell1, Cell cell2)
            {
                int rowDistance = Mathf.Abs(cell1.Row - cell2.Row);
                int columnDistance = Mathf.Abs(cell1.Column - cell2.Column);

                if (columnDistance > rowDistance)
                    return columnDistance;
                else
                    return rowDistance;
            }
            
            int CalculateDistanceBetweenCells3D(Cell cell1, Cell cell2)
            {
                int rowDistance = Mathf.Abs(cell1.Row - cell2.Row);
                int columnDistance = Mathf.Abs(cell1.Column - cell2.Column);
                int layerDistance = Mathf.Abs(cell1.Layer - cell2.Layer);

                int largestValue = rowDistance;
                if (columnDistance > largestValue)
                    largestValue = columnDistance;

                if (layerDistance > largestValue)
                    return layerDistance;
                else
                    return largestValue;
            }
        }

        struct ObsoleteObject
        {
            public readonly int userID;
            public readonly Cell owningCell;

            public ObsoleteObject(int userID, Cell owningCell)
            {
                this.userID = userID;
                this.owningCell = owningCell;
            }
        }
    }
}