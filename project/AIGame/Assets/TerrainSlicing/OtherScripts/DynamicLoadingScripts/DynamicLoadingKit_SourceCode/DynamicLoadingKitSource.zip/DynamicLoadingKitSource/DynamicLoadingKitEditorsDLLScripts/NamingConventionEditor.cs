﻿namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using UnityEditor;
    using UnityEngine;

    [CustomEditor(typeof(NamingConvention))]
    public class NamingConventionEditor : Editor
    {
        SerializedProperty formatProperty, numberingStartsAt0Property;
        
        public sealed override void OnInspectorGUI()
        {
            if (formatProperty == null)
                formatProperty = serializedObject.FindProperty("format");

            if (numberingStartsAt0Property == null)
                numberingStartsAt0Property = serializedObject.FindProperty("numberingStartsAt0");

            serializedObject.Update();

            EditorGUILayout.HelpBox("The default naming convention is GroupName_Row_Column (with values starting at 1). This Naming Convention asset can be utilized to provide the Dynamic Loading Kit with an alternate naming convention. If a component or tool has a field for a Naming Convention asset but no asset is provided, the default naming convention will be used.", MessageType.Info);

            EditorGUILayout.HelpBox("At runtime, the following special characters are replaced by specific values:\n\n%g is replaced by the Group Name\n%x is replaced by the Column\n%y is replaced by the Row\n%z is replaced by the Layer (only use this value if you're using a 3D World Grid)", MessageType.Info);

            EditorGUILayout.PropertyField(formatProperty, formatLabel);
            EditorGUILayout.PropertyField(numberingStartsAt0Property, numberingStartsAt0Label);

            if(Application.isPlaying)
                EditorGUILayout.LabelField("Editing is not allowed while in play mode!");
            else
                serializedObject.ApplyModifiedProperties();
        }

        [MenuItem("Assets/Dynamic Loading Kit/Create Naming Convention Asset")]
        public static void CreateNamingConventionAsset()
        {
            ScriptableObjectAssetCreator.GenerateScriptableObjectAssetAtSelectedFolder<NamingConvention>("NamingConvention");
        }

        GUIContent formatLabel = new GUIContent("Format*", "The format of the naming convention. %g will be replaced by the group name, %x will be replaced by the column, %y will be replaced by the row, and %z will be replaced by the layer of the object/terrain at runtime; all other characters will be interpreted literally.\n\nFor example, a format of '%g_x%x_y%y' will result in the first terrain/object in the group's name to be GroupName_x0_y0 (this is Terrain Composer's format), assuming 'Numbering Starts At 0' is set to true.");

        GUIContent numberingStartsAt0Label = new GUIContent("Numbering Starts At 0*", "Does row/column/layer numbering start at 0? If numbering starts at 1 (as in the default naming convention), set this option to false. If it starts at 0 (as in the Terrain Composer naming convention), set this option to true.\n\nIf you're not sure, look at the first terrain/object in your group (the one with the smallest x and z value).");
    }
}
