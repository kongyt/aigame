﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System;
    using System.Text;
    using System.Collections.Generic;
    using Random = UnityEngine.Random;
    using Object = UnityEngine.Object;

    //Ignore for now, there's some kind of error in the xsl generation for this.
    ///// <summary>
    ///// Encapsulates a generic method that tries to get a value TValue using the specified key TKey.
    ///// The return value indicates whether the get operation is successful.
    ///// </summary>
    ///// <title>
    ///// TryGet&lt;TKey, TValue&gt; Delegate
    ///// </title>
    ///// <category>
    ///// Delegates
    ///// </category>
    ///// <navigationName>
    ///// TryGet
    ///// </navigationName>
    ///// <fileName>
    ///// TryGet.html
    ///// </fileName>
    ///// <syntax>
    ///// public delegate bool TryGet&lt;TKey, TValue&gt;(TKey key, out TValue value)
    ///// </syntax>
    ///// <typeparam name="TKey">
    ///// The type of the key.
    ///// </typeparam>
    ///// <typeparam name="TValue">
    ///// The type of the value.
    ///// </typeparam>
    ///// <param name="key" type = "TKey">
    ///// The key used to try and retrieve value.
    ///// </param>
    ///// <param name="value" type = "out TValue">
    ///// When this method returns, contains the value associated with
    ///// the specified key, if the key is found; otherwise, an unspecified value.
    ///// </param>
    ///// <returns type = "bool">
    ///// A value indicating if the value was successfully retrieved.
    ///// </returns>
    public delegate bool TryGet<TKey, TValue>(TKey key, out TValue value);

    /// <summary>
    /// Defines a manager which handles a variety of task, from handling persistent data to configuring all Worlds and
    /// Active Grids in the scene. There should only be one Component Manager in each of your scenes.
    /// <para>
    /// You can destroy and create Active Grids and Worlds during runtime via the Component Manager class. To create these 
    /// components at runtime, you will need to provide one or more prototypes. Prototypes store default configuration data 
    /// as well as references to other crucial components that cannot be identified at runtime. Prototypes should be attached 
    /// to disabled game objects.
    /// </para>
    /// <para>
    /// If Use Custom Save/Load Solution is NOT checked, the component manager will automatically search for persistent 
    /// data via the Persistent Data Controller provided, and will save persistent data either automatically when the game 
    /// exits (if Auto Save Data On Game Exit is checked), or when the Save method is called. This is excellent for 
    /// debugging in the editor, but for a production quality game, you will probably want to use 
    /// a different loading method. This can be done by checking "Use Custom Save/Load Solution," and using 
    /// GetSaveData and LoadSaveData.
    /// </para>
    /// <para>
    /// GetSaveData will return a string which reflects the current state of the component manager and all persistent 
    /// Active Grids and Worlds in the current scene. It can be serialized or stored in whatever manner you wish.
    /// </para>
    /// <para>
    /// When you wish to load your save, you deserialize the string or retrieve it from where it's stored and load it via LoadSaveData. 
    /// There is a limited window in which persistent data can be loaded via this method. This window 
    /// will close immediately when CreatePersistentActiveGrid, CreateNonPersistentActiveGrid, CreatePersistentWorld, 
    /// or CreateNonPersistentWorld are called for the first time. It will also close once 
    /// the Component Manager has been initialized. You can delay initialization by unchecking "Initialize On Awake," but you 
    /// will have to manually call Initialize or InitializeGradually. This technique should only be used if 
    /// </para>
    /// <para>
    /// A) You are instantiating or loading the Dynamic Loading Manager via Application.LoadLevel or Application.LoadLevelAsync, 
    /// and Awake is called on the Component Manager before you have a chance to pass in load data, or 
    /// </para>
    /// <para>
    /// B) You need to make sure that the initialization occurs over a series of frames for performance reasons. 
    /// In this case use InitializeGradually.
    /// </para>
    /// <para>
    /// More information on these topics (and more) can be found in the Dynamic Loading Kit Full Guide.
    /// </para>
    /// </summary>
    /// <title>ComponentManager Class</title>
    /// <category>Primary Components</category>
    /// <navigationName>ComponentManager</navigationName>
    /// <fileName>ComponentManager.html</fileName>
    /// <syntax>public sealed class ComponentManager : MonoBehaviour, <see href = "IIdentifiable.html">IIdentifiable</see></syntax>
    /// 
    /// <inspector name="Active Grid Prototypes" type="int">
    /// The number of Active Grid Prototypes (see the 
    /// <see href="http://deepspacelabs.net/files/Dynamic%20Loading%20Kit_Full_Guide.pdf">
    /// Dynamic Loading Kit Full Guide
    /// </see> 
    /// for more info).
    /// </inspector>
    /// 
    /// <inspector name="Auto Save Data On Game Exit" type="bool">
    /// If enabled, the Component Manager will automatically save persistent data for the Component Manager and all persistent 
    /// Active Grids/Worlds in the scene when the game exits.
    /// <para>
    /// This applies to exiting Play in the editor and exiting the game in a Standalone build, but only when using a 
    /// persistent data controller (rather than a custom save/load solution). This is a nice feature for debugging in the editor, 
    /// but is not really meant to be used in a standalone game.
    /// </para>
    /// </inspector>
    /// 
    /// <inspector name="Component Manager ID" type="int">
    /// The ID that uniquely identifies this Component Manager. Because there should only be one Component Manager per scene, you shouldn't
    /// need to change this value.
    /// </inspector>
    /// 
    /// <inspector name ="Initialize On Awake" type="bool">
    /// If enabled, the Component Manager will automatically initialize during the Awake phase. During initialization, if no persistent 
    /// data has been loaded (when using a custom save/load solution) or found by the Persistent Data Controller (when not using a 
    /// custom save/load solution), the Component Manager, Worlds, and Active Grids in the scene will be configured as if no persistent 
    /// data exist. (see Ch 4, Section 1, "Loading Save Data" of the Dynamic Loading Kit Full Guide for more info).
    /// <para>
    /// If disabled, you will need to call Initialize (should only be used when performance isn't an issue, such as at the start of a game)
    /// or InitializeGradually (better performance).
    /// </para>
    /// </inspector>
    /// 
    /// <inspector name="Persistent Data Controller" type="PersistentDataController" link="PersistentDataController.html">
    /// The Persistent Data Controller that should be used to save the persistent data of this Component Manager and all 
    /// Active Grids in the scene.
    /// </inspector>
    /// 
    /// <inspector name="Use Custom Save/Load Solution" type="bool">
    /// Enable this option if you wish to use a custom save/load solution (rather than a persistent data controller).
    /// <para>
    /// If checked, you should manually call GetSaveData and LoadSaveData when appropriate (see top of page for more info).
    /// </para>
    /// <para>
    /// You can also use this option if you don't plan on saving/loading persistent data.
    /// </para>
    /// </inspector>
    /// 
    /// <inspector name="World Prototypes" type="int">
    /// The number of World Prototypes (see the 
    /// <see href="http://deepspacelabs.net/files/Dynamic%20Loading%20Kit_Full_Guide.pdf">
    /// Dynamic Loading Kit Full Guide
    /// </see> 
    /// for more info).
    /// </inspector>
    [AddComponentMenu("Dynamic Loading Kit/Main Components/Component Manager")]
    public sealed class ComponentManager : MonoBehaviour, IIdentifiable
    {
        #region Fields and Properties
        [SerializeField]
        internal int componentManagerID;

        [SerializeField]
        internal PersistentDataController persistentDataController;

        [SerializeField]
        internal ActiveGrid[] activeGridPrototypes;

        [SerializeField]
        internal World[] worldPrototypes;

        [SerializeField]
        internal bool autoSaveDataOnGameExit, useCustomSaveLoadSolution, initializeOnAwake = true, suppressWarnings;

        bool errorFree = true;

        bool ExistingSaveDataLoaded { get { return activeGridsInScene != null; } }

        internal enum Phase { Asleep, Awake_CompletePhase2, Awake_SkipPhase2, Started }
        internal Phase phase = Phase.Asleep;

        //Will always be used, we'll create these in Awake
        Dictionary<int, ActiveGrid> activeGridsInScene;
        Dictionary<int, World> worldsInScene;

        #region members which may or may not be used: We'll lazily load them

        //Same as above
        HashSet<int> obsoleteActiveGrids, obsoleteWorlds;
        HashSet<int> ObsoleteActiveGrids 
        { 
            get 
            {
                if (obsoleteActiveGrids == null)
                    obsoleteActiveGrids = new HashSet<int>();

                return obsoleteActiveGrids; 
            } 
        }
        HashSet<int> ObsoleteWorlds 
        { 
            get 
            {
                if (obsoleteWorlds == null)
                    obsoleteWorlds = new HashSet<int>();

                return obsoleteWorlds; 
            } 
        }
        #endregion

        int activeGridIDGenerationRange, worldIDGenerationRange;
        string persistentDataSaveKey;
        StringBuilder stringBuilderForSaving;
        TryGet<int, World> TryGetWorldByIDFunction;

        /// <summary>
        /// The ID that uniquely identifies this Component Manager.
        /// </summary>
        /// <type>int</type>
        public int ID { get { return componentManagerID; } }

        /// <summary>
        /// Gets a value indicating whether this Component Manager has been initialized. When using InitializeGradually, 
        /// will return true from the moment the method is first called. Will also return true after Initialize has been called 
        /// or after Awake when the "Initialize on Awake" options is checked.
        /// </summary>
        /// <type>bool</type>
        public bool IsInitialized { get; private set; }

        #endregion

        #region Initialization Methods

        void Awake()
        {
            if (!IsInitialized && phase == Phase.Asleep && initializeOnAwake && errorFree)
            {
                InitializePhase1();
                phase = Phase.Awake_CompletePhase2;
            }
            else if(phase == Phase.Asleep)
                phase = Phase.Awake_SkipPhase2;
        }

        void Start()
        {
            if (phase == Phase.Awake_CompletePhase2)
                InitializePhase2();
            //else if (errorFree && !IsInitialized)
            //{
            //    //Since the component manager is not initialized, the individual worlds and active 
            //    //grids in the scene should also not be initialized. However, in case they are, 
            //    //this code will perform some activation that is necessary.
            //    if (worldsInScene != null)
            //    {
            //        foreach (World world in worldsInScene.Values)
            //        {
            //            if (world.IsInitialized && world.cellController.DoStartingCellsNeedToBeActivated)
            //                world.cellController.ActivateStartingCells();
            //        }
            //    }

            //    if (activeGridsInScene != null)
            //    {
            //        foreach (ActiveGrid activeGrid in activeGridsInScene.Values)
            //        {
            //            if (activeGrid.IsInitialized)
            //            {
            //                if (activeGrid.DoesPlayerYPositionNeedUpdatingToTerrainLocation())
            //                    activeGrid.UpdatePlayerYPositionToTerrainLocation();

            //                activeGrid.StartMonitoringIfNecessary();
            //            }
            //        }
            //    }
            //}
            
            phase = Phase.Started; 
        }


        /// <summary>
        /// Initializes the Component Manager over two frames. This in turn loads any existing save data (if not already loaded), 
        /// and initializes all uninitialized Active Grids/Worlds in the scene.
        /// <para>This should only be used if "Initialize On Awake" is unchecked in the inspector, and then only at the beginning 
        /// of the game from another scripts Awake method. If the game has started (i.e., the update cycle is running), you should use 
        /// InitializeGradually instead (for performance reasons).</para>
        /// </summary>
        /// <displayName id="Initialize">Initialize()</displayName>
        /// <syntax>public void Initialize()</syntax>
        public void Initialize()
        {
            if (IsInitialized)
                throw new InvalidOperationException("Could not initialze the Component Manager with ID " + ID + "because that Component Manager has already been initialzed. If Initialize On Awake is enabled, you do not need to call Initialize yourself!");

            if (!errorFree)
                return;

            InitializePhase1();

            //If the component manager's start method has already been called, set phase 2 to run next frame,
            //otherwise it will be called from the Start method.
            if (errorFree && phase == Phase.Started)
                StartCoroutine(InitializePhase2NextFrame());
            else
                phase = Phase.Awake_CompletePhase2;
        }

        /// <summary>
        /// Initialzes the Component Manager over a series of frames. This coroutine exits only after all initial cell objects have been 
        /// loaded, which allows you to display a loading screen or use some other device to hide the world until it is fully loaded.
        /// <para>This should only be used if "Initialize On Awake" is unchecked in the inspector.</para>
        /// </summary>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">
        /// An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.
        /// </returns>
        /// <displayName id="InitializeGradually">InitializeGradually()</displayName>
        /// <syntax>public IEnumerator&lt;YieldInstruction&gt; InitializeGradually()</syntax>
        public IEnumerator<YieldInstruction> InitializeGradually()
        {
            if (IsInitialized)
                throw new InvalidOperationException("Could not initialze the Component Manager with ID " + ID + "because that Component Manager has already been initialzed. If Initialize On Awake is enabled, you do not need to call Initialize yourself!");

            if (!errorFree)
            {
                Debug.LogError("The Component Manager could not be initialized due to errors.");
                yield break;
            }

            LoadSaveDataIfNotAlreadyLoaded();

            IsInitialized = true;
            if (phase != Phase.Started)
                phase = Phase.Awake_SkipPhase2;

            foreach (World world in worldsInScene.Values)
            {
                try
                {
                    world.Initialize(this);
                }
                catch (Exception e)
                {
                    errorFree = false;
                    throw e;
                }

                yield return null;
            }

            if (activeGridsInScene.Count == 0)
                yield break;

            List<ActiveGrid> activeGridsNeedingLoading = new List<ActiveGrid>(activeGridsInScene.Count);
            foreach (ActiveGrid activeGrid in activeGridsInScene.Values)
            {
                try
                {
                    activeGrid.Initialize(this);
                }
                catch(Exception e)
                {
                    errorFree = false;
                    throw e;
                }

                if (activeGrid.activeGridState.cellObjectsEnabled && 
                    !activeGrid.activeGridState.cellObjectsLoaded && activeGrid.world != null)
                    activeGridsNeedingLoading.Add(activeGrid);
            }

            if (activeGridsNeedingLoading.Count == 0)
                goto End;
            
            yield return null;
            List<IEnumerator<YieldInstruction>> loadingActiveGrids = new List<IEnumerator<YieldInstruction>>(4);

            while (activeGridsNeedingLoading.Count > 0)
            {
                int i = activeGridsNeedingLoading.Count - 1;
                World syncedToWorld = activeGridsNeedingLoading[i].world;

                while (activeGridsNeedingLoading[i].IsBusy)
                    yield return null;

                IEnumerator<YieldInstruction> e = activeGridsNeedingLoading[i].TryLoadCellObjectsAndWaitForLoadToComplete();
                e.MoveNext();
                loadingActiveGrids.Add(e);
                activeGridsNeedingLoading.RemoveAt(i);

                yield return null;
                if(activeGridsNeedingLoading.Count > 0)
                {
                    i--;
                    for(; i >= 0; i--)
                    {
                        if (activeGridsNeedingLoading[i].world == syncedToWorld)
                        {
                            while (activeGridsNeedingLoading[i].IsBusy)
                                yield return null;

                            e = activeGridsNeedingLoading[i].TryLoadCellObjectsAndWaitForLoadToComplete();
                            e.MoveNext();
                            loadingActiveGrids.Add(e);
                            loadingActiveGrids.RemoveAt(i);
                            yield return null;
                        }
                    }
                    yield return null;
                }

                if (loadingActiveGrids.Count == 1)
                {
                    while (loadingActiveGrids[0].MoveNext())
                        yield return loadingActiveGrids[0].Current;
                }
                else
                {
                    do
                    {
                        YieldInstruction yieldInstruction = null;
                        for(int j = loadingActiveGrids.Count - 1; j >= 0; j--)
                        {
                            if (loadingActiveGrids[j].MoveNext())
                                yieldInstruction = loadingActiveGrids[j].Current;
                            else
                                loadingActiveGrids.RemoveAt(j);
                        }
                    }
                    while (loadingActiveGrids.Count > 0);
                }
            }


        End:
            foreach (ActiveGrid activeGrid in activeGridsInScene.Values)
            {
                activeGrid.StartMonitoringIfNecessary();
                yield return null;
            }

            yield break;
        }

        IEnumerator<YieldInstruction> InitializePhase2NextFrame()
        {
            yield return null;
            InitializePhase2();
        }

        void InitializePhase1()
        {
            IsInitialized = true;
            try
            {
                LoadSaveDataIfNotAlreadyLoaded();

                foreach (World world in worldsInScene.Values)
                    world.Initialize(this);
            
                foreach (ActiveGrid activeGrid in activeGridsInScene.Values)
                {
                    activeGrid.Initialize(this);
                    if (activeGrid.activeGridState.cellObjectsEnabled)
                        activeGrid.TryLoadCellObjectsASAP();
                }
            }
            catch(Exception e)
            {
                errorFree = false;
                throw e;
            }
        }

        void InitializePhase2()
        {
            if (!errorFree)
                return;
            try
            {
                foreach (World world in worldsInScene.Values)
                {
                    if (world.cellController.DoStartingCellsNeedToBeActivated)
                    {
                        world.cellController.ActivateStartingCells();
                        world.AwakeFromIdle();
                    }
                }

                foreach (ActiveGrid activeGrid in activeGridsInScene.Values)
                {
                    if (activeGrid.DoesPlayerYPositionNeedUpdatingToTerrainLocation())
                        activeGrid.UpdatePlayerYPositionToTerrainLocation();

                    activeGrid.StartMonitoringIfNecessary();
                }
            }
            catch(Exception e)
            {
                errorFree = false;
                throw e;
            }
        }

        #endregion

        #region State Loading

        /// <summary>
        /// Loads save data that was retrieved via GetSaveData. This should only be called when using a custom save/load solution.
        /// <para>
        /// VERY IMPORTANT: There is a limited window in which persistent data can be loaded via this method. This window 
        /// will close immediately when CreatePersistentActiveGrid, CreateNonPersistentActiveGrid, CreatePersistentWorld, 
        /// or CreateNonPersistentWorld are called for the first time. It will also close once 
        /// the Component Manager has been initialized. You can delay initialization by unchecking "Initialize On Awake," but you 
        /// will have to manually call Initialize or InitializeGradually. This technique should only be used if 
        /// </para>
        /// <para>
        /// A) You are instantiating or loading the Dynamic Loading Manager via Application.LoadLevel or Application.LoadLevelAsync, 
        /// and Awake is called on the Component Manager before you have a chance to pass in load data, or 
        /// </para>
        /// <para>
        /// B) You need to make sure that the initialization occurs over a series of frames for performance reasons. 
        /// In this case use InitializeGradually.
        /// </para>
        /// </summary>
        /// <param name="saveData" type ="string">
        /// The save data for the Component Manager to use to setup the state of this Component Manager and all persistent Worlds 
        /// and Active Grids.
        /// </param>
        /// <displayName id="LoadSaveData">
        /// LoadSaveData(string)
        /// </displayName>
        /// <syntax>
        /// public void LoadSaveData(string saveData)
        /// </syntax>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called and Use Custom Save/Load Solution is not checked in the inspector, or if the 
        /// Component Manager passed the phase where persistent save data can be loaded.
        /// </exception>
        public void LoadSaveData(string saveData)
        {
            if (!useCustomSaveLoadSolution)
                throw new InvalidOperationException("LoadSaveData() call on Component Manager with ID " + ID + " failed. LoadSaveData can only be used when 'Use Custom Save/Load Solution' is enabled. Data from the Persistent Data Controller will be used instead.");

            if (ExistingSaveDataLoaded)
                throw new InvalidOperationException("LoadSaveData() call on Component Manager with ID " + ID + " failed. LoadSaveData has either already been called, or the phase where persistent save data can been loaded has passed.");

            if (saveData == null)
                throw new InvalidSaveDataException(string.Format("Data passed into the Component Manager with ID {0}" +
                    " via the LoadSaveData method is invalid. It is null!", ID));

            string[] dataBlocks = saveData.Split('?');
            int saveDataID = int.Parse(dataBlocks[0], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            if (saveDataID != ID)
                throw new InvalidSaveDataException(string.Format("Data passed into the Component Manager with ID {0}" +
                    " via the LoadSaveData method is invalid. The ID of the save data ({1}) does not match the ID of" +
                    " Component Manager ({0})", ID, saveDataID));

            if (dataBlocks.Length != 4)
                throw new InvalidSaveDataException("Data passed into the Component Manager with ID " + ID +
                    " via the LoadSaveData method is invalid. Incorrect Format. Ensure you are using data generated via the GetSaveData method.");

            LoadSaveDataInternal(dataBlocks);
        }

        void LoadSaveDataIfNotAlreadyLoaded()
        {
            if (ExistingSaveDataLoaded)
                return;

            if (useCustomSaveLoadSolution)
                LoadSaveDataInternal(null);
            else
                TryGetSaveDataFromPersistentDataController();
        }

        void TryGetSaveDataFromPersistentDataController()
        {
            try
            {
                PreLoadConfiguration();

                persistentDataSaveKey = persistentDataController.SceneID + "_CM_" + componentManagerID;

                string componentManagerData;
                if (persistentDataController.TryGetData(persistentDataSaveKey, out componentManagerData))
                    IncorporateComponentManagerData(componentManagerData);

                TrySetPersistentDataUsingPersistentDataController();

                PostLoadConfiguration();
            }
            catch(Exception e)
            {
                errorFree = false;
                throw e;
            }
        }

        void LoadSaveDataInternal(string[] saveData)
        {
            try
            {
                PreLoadConfiguration();

                if (saveData != null)
                {
                    IncorporateComponentManagerData(saveData[1]);

                    if (saveData[3] != "X")
                        SetupWorlds(saveData[3].Split('$'));

                    if (saveData[2] != "X")
                        SetupActiveGrids(saveData[2].Split('$'));
                }

                PostLoadConfiguration();
            }
            catch (Exception e)
            {
                errorFree = false;
                throw e;
            }
        }

        void PreLoadConfiguration()
        {
            EnsurePrototypesHaveRequiredComponents();

            if (!useCustomSaveLoadSolution && persistentDataController == null)
                throw new RequiredComponentNotFoundException(string.Format("No Persistent Data Controller could be found for the Component Manager with ID {0}. Drag one to the appropriate field, or check the " +
                    "option to use a custom save/load solution.", componentManagerID));

            InitializeRequiredFields();
            FindComponentsInScene();
        }

        void PostLoadConfiguration()
        {
            activeGridIDGenerationRange = activeGridsInScene.Count * 2;
            worldIDGenerationRange = worldsInScene.Count * 2;
            errorFree = true;
        }




        void EnsurePrototypesHaveRequiredComponents()
        {
            for (int i = worldPrototypes.Length - 1; i >= 0; i--)
            {
                if (!DoesWorldHaveAllRequiredComponents(worldPrototypes[i]))
                    throw new RequiredComponentNotFoundException(string.Format("World Prototype {0} is missing a PrimaryCellObjectSubController Component and/or " +
                        "a WorldGrid! Add the missing components/scriptable object or remove the prototype.", i + 1));
            }
        }

        void InitializeRequiredFields()
        {
            activeGridsInScene = new Dictionary<int, ActiveGrid>();
            worldsInScene = new Dictionary<int, World>();
            stringBuilderForSaving = new StringBuilder();
            TryGetWorldByIDFunction = TryGetWorldByID;
        }

        void FindComponentsInScene()
        {
            FindAndStoreAllActiveGridsInScene();
            FindAndStoreAllWorldsInScene();
        }

        void FindAndStoreAllActiveGridsInScene()
        {
            ActiveGrid[] activeGrids = Object.FindObjectsOfType(typeof(ActiveGrid)) as ActiveGrid[];

            foreach (ActiveGrid grid in activeGrids)
            {
                if (activeGridsInScene.ContainsKey(grid.ID))
                    throw new DuplicateIDException("Active Grid ID # " + grid.ID + " is being used by multiple Active Grids, which is not allowed. Please Fix!");
                else
                    activeGridsInScene.Add(grid.ID, grid);
            }
        }

        void FindAndStoreAllWorldsInScene()
        {
            World[] worlds = Object.FindObjectsOfType(typeof(World)) as World[];

            foreach (World world in worlds)
            {
                if (worldsInScene.ContainsKey(world.ID))
                    throw new DuplicateIDException("World ID # " + world.ID + " is being used by multiple Worlds, which is not allowed. Please Fix!");
                else
                    worldsInScene.Add(world.ID, world);
            }
        }

        void IncorporateComponentManagerData(string componentManagerData)
        {
            string[] allComponentManagerData = componentManagerData.Split(';');

            if (allComponentManagerData.Length != 4)
                throw new InvalidSaveDataException("Component Manager data is invalid. If using a custom save/load solution, make sure your data was generated via the GetSaveData method. If not using a custom solution, the data may have been corrupted somehow.");

            RemoveObsoleteActiveGrids(allComponentManagerData[0]);
            RemoveObsoleteWorlds(allComponentManagerData[1]);
            CreateActiveGridsCreatedDuringPreviousSession(allComponentManagerData[2]);
            CreateWorldsCreatedDuringPreviousSession(allComponentManagerData[3]);
        }

        void TrySetPersistentDataUsingPersistentDataController()
        {
            foreach (World world in worldsInScene.Values)
            {
                world.PersistentDataSaveKey = persistentDataController.SceneID + "_W_" + world.ID;
                string worldData = null;
                if (persistentDataController.TryGetData(world.PersistentDataSaveKey, out worldData))
                    world.SetStateFromSaveData(worldData);
            }

            foreach (ActiveGrid activeGrid in activeGridsInScene.Values)
            {
                activeGrid.PersistentDataSaveKey = persistentDataController.SceneID + "_AG_" + activeGrid.ID;
                string activeGridData = null;
                if (persistentDataController.TryGetData(activeGrid.PersistentDataSaveKey, out activeGridData))
                    activeGrid.SetStateFromSaveData(activeGridData, TryGetWorldByIDFunction);
            }
        }

        void SetupWorlds(string[] dataForAllPersistentWorlds)
        {
            foreach (string data in dataForAllPersistentWorlds)
            {
                string[] split = data.Split(':');
                int worldID = int.Parse(split[0], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                World world;
                if (worldsInScene.TryGetValue(worldID, out world))
                    world.SetStateFromSaveData(split[1]);
            }
        }

        void SetupActiveGrids(string[] dataForAllPersistentActiveGrids)
        {
            foreach(string data in dataForAllPersistentActiveGrids)
            {
                string[] split = data.Split(':');
                int activeGridID = int.Parse(split[0], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                ActiveGrid activeGrid;
                if (activeGridsInScene.TryGetValue(activeGridID, out activeGrid))
                    activeGrid.SetStateFromSaveData(split[1], TryGetWorldByIDFunction);
            }
        }
        

        bool DoesWorldHaveAllRequiredComponents(World world)
        {
            return world.primaryCellObjectSubController != null && world.WorldGrid != null;
        }


        void RemoveObsoleteActiveGrids(string obsoleteGridData)
        {
            if (obsoleteGridData == "X")
                return;

            obsoleteActiveGrids = new HashSet<int>();
            string[] individualData = obsoleteGridData.Split('|');
            for (int i = 0; i < individualData.Length; i++)
                obsoleteActiveGrids.Add(int.Parse(individualData[i], System.Globalization.CultureInfo.InvariantCulture.NumberFormat));

            HashSet<int> obsoleteGridsNoLongerInScene = new HashSet<int>();
            foreach (int ID in obsoleteActiveGrids)
            {
                ActiveGrid activeGrid;
                if (activeGridsInScene.TryGetValue(ID, out activeGrid))
                {
                    activeGridsInScene.Remove(ID);
                    Destroy(activeGrid);
                }
                else
                    obsoleteGridsNoLongerInScene.Add(ID);
            }

            //Remove the obsolete grids that were not in the scene.
            obsoleteActiveGrids.ExceptWith(obsoleteGridsNoLongerInScene);
        }

        void RemoveObsoleteWorlds(string obsoleteWorldData)
        {
            if (obsoleteWorldData == "X")
                return;

            obsoleteWorlds = new HashSet<int>();

            string[] individualData = obsoleteWorldData.Split('|');
            for (int i = 0; i < individualData.Length; i++)
                obsoleteWorlds.Add(int.Parse(individualData[i], System.Globalization.CultureInfo.InvariantCulture.NumberFormat));

            HashSet<int> obsoleteWorldsNoLongerInScene = new HashSet<int>();
            foreach (int ID in obsoleteWorlds)
            {
                World world;
                if (worldsInScene.TryGetValue(ID, out world))
                {
                    worldsInScene.Remove(ID);
                    world.RemovePreviewObjects();
                    Destroy(world);
                }
                else
                    obsoleteWorldsNoLongerInScene.Add(ID);
            }

            obsoleteWorlds.ExceptWith(obsoleteWorldsNoLongerInScene);
        }

        void CreateActiveGridsCreatedDuringPreviousSession(string activeGridData)
        {
            if (activeGridData == "X")
                return;

            string[] activeGridDataArray = activeGridData.Split('/');
            foreach (string individualGridData in activeGridDataArray)
            {
                string[] actualData = individualGridData.Split('|');
                int gridID = int.Parse(actualData[0], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                RemoveDuplicateGridIfOneExist(gridID);
                int prototypeIndex = int.Parse(actualData[1], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);

                ActiveGrid prototypeToConstructActiveGridFrom = activeGridPrototypes[prototypeIndex - 1];
                CreateActiveGrid_Internal(gridID, prototypeToConstructActiveGridFrom, prototypeIndex, new ActiveGridState(prototypeToConstructActiveGridFrom.activeGridState), true);
            }
        }

        void RemoveDuplicateGridIfOneExist(int gridID)
        {
            ActiveGrid activeGrid;

            if (activeGridsInScene.TryGetValue(gridID, out activeGrid))
            {
                Debug.LogWarning("You have added an Active Grid component with ID " + gridID + ", which is the same ID used by an Active Grid created " +
                    "during runtime in a previous session. The newly created Active Grid component will be destroyed. It is suggested that you change this grids ID to one not being used, " +
                    "or remove the Runtime Active Grid Persistent Data via the appropriate button on the Component Manager Inspector.");
                activeGridsInScene.Remove(gridID);
                Destroy(activeGrid);
            }

        }

        void CreateWorldsCreatedDuringPreviousSession(string worldData)
        {
            if (worldData == "X")
                return;

            string[] worldDataArray = worldData.Split('/');
            foreach (string individualWorldData in worldDataArray)
            {
                string[] actualData = individualWorldData.Split('|');
                int worldID = int.Parse(actualData[0], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                int prototypeIndex = int.Parse(actualData[1], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);



                World worldPrototypeToConstructWorldFrom = worldPrototypes[prototypeIndex - 1];
                World world = CreateWorld_Internal(worldID, worldPrototypeToConstructWorldFrom, prototypeIndex, true);

                if (actualData.Length == 5)
                {
                    float xOrigin = float.Parse(actualData[2], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                    float yOrigin = float.Parse(actualData[3], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                    float zOrigin = float.Parse(actualData[4], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                    world.worldOrigin = new Vector3(xOrigin, yOrigin, zOrigin);
                    world.useThisGameObjectsPositionAsWorldOrigin = false;
                }
            }
        }

        void RemoveDuplicateWorldIfOneExist(int worldID)
        {
            World world;

            if (worldsInScene.TryGetValue(worldID, out world))
            {
                Debug.LogWarning("You have added a World component with ID " + worldID + ", which is the same ID used by a World created " +
                    "during runtime in a previous session. The newly created World component will be destroyed. It is suggested that you change this worlds ID to one not being used, " +
                    "or remove the Runtime World Persistent Data via the appropriate button on the Persistent Data Controller.");
                worldsInScene.Remove(worldID);
                Destroy(world);
            }

        }

        #endregion

        #region Active Grid related methods

        /// <summary>
        /// Creates and initializes a persistent Active Grid based on the prototype 
        /// and the specified optional parameters.
        /// The persistent grid data will not be saved with the component manager's save data.
        /// <para>
        /// Also keep in mind that when the Active Grid is initialized, the World the grid is 
        /// synced to will also be initialized, as well as this Component Manager if it has not 
        /// already been initialized.
        /// </para>
        /// <para>
        /// Note, you will need to manually load the grid's cell users in order for the 
        /// World the grid is synced to to load its objects. You can do this by calling 
        /// <see cref="ActiveGrid.TryLoadCellObjects" href="ActiveGrid.html#TryLoadCellObjects">
        /// TryLoadCellObjects
        /// </see> 
        /// or 
        /// <see cref="ActiveGrid.TryLoadCellObjectsAndWaitForLoadToComplete" href="ActiveGrid.html#TryLoadCellObjectsAndWaitForLoadToComplete">
        /// TryLoadCellObjectsAndWaitForLoadToComplete
        /// </see>.
        /// </para>
        /// </summary>
        /// <param name="prototypeToConstructGridFrom" type="int">
        /// The prototype to construct the grid from.
        /// </param>
        /// <param name="persistentDataToSetStateFrom" type="string">
        /// Optional persistent data retrieved from another Active Grid's 
        /// <see cref="ActiveGrid.GetPersistentStringSaveData" href="ActiveGrid.html#GetPersistentStringSaveData">
        /// GetPersistentStringSaveData
        /// </see> method, that can be used to set the initial state of the created Active Grid.
        /// <para>
        /// If this is not null but the 
        /// persistent data does not contain World information, the default World from the Active Grid Prototype will not be used. Instead, 
        /// the grid will act as if it has no world and sit idle, unless you pass in an alternateWorldToSyncTo. You can also sync the grid 
        /// to a world after creation using one of the grids sync methods (do not use 
        /// <see cref="ActiveGrid.PreInitialize_SetWorld" href="ActiveGrid.html#PreInitialize_SetWorld">PreInitialize_SetWorld</see>, 
        /// as the grid is automatically initialized before being returned to you).
        /// </para>
        /// </param>
        /// <param name="alternateWorldToSyncTo" type="World" link="World.html">
        /// An alternate world for the grid to start synced to. This world can be either persistent or non persistent.
        /// </param>
        /// <param name="allowAlternateWorldToOverwriteWorldFromPersistentData" type="bool">
        /// When persistentDataToSetStateFrom is not null and contains valid world information, and alternateWorldToSyncTo is not null, 
        /// allowAlternateWorldToOverwriteWorldFromPersistentData will control which world is used. 
        /// </param>
        /// <param name="alternatePlayerToAssociateWithGrid" type="Transform">
        /// If provided, the grid will be associated with this transform upon initialization, otherwise the grid will be associated with 
        /// the default Player Transform of the prototype (note, if both values are null, the grid will throw an exception if it 
        /// is expecting a player to be present).
        /// </param>
        /// <param name="playerMoverToAssociateWithGrid" type="PlayerMover" link="PlayerMover.html">
        /// If provided, the grid will use this PlayerMover when moving the Player Transform. If alternatePlayerToAssociateWithGrid is 
        /// set and playerMoverToAssociateWithGrid is null, the Active Grid will not use the default PlayerMover of the prototype. 
        /// Instead, the player mover will be set to null and the player will be moved via its Transform. If you don't want this to 
        /// happen, be sure to provide a player mover if you provide an alternate player.
        /// </param>
        /// <returns type="ActiveGrid" link="ActiveGrid.html">
        /// The created and initialized non persistent Active Grid.
        /// </returns>
        /// <exception name="InvalidPrototypeException" link ="InvalidPrototypeException.html">
        /// Thrown when prototypeToConstructGridFrom 
        /// is invalid. Valid values range from 1 to [number of prototypes].
        /// </exception>
        /// <exception name="MissingComponentException">
        /// Thrown when persistentDataToSetStateFrom is not null and contains a World that should exist but does not anymore.
        /// </exception>
        /// <displayName id="CreateNonPersistentActiveGrid">
        /// CreateNonPersistentActiveGrid(int, [string], [World], [bool], [Transform], [PlayerMover]])
        /// </displayName>
        /// <syntax>
        /// public ActiveGrid CreateNonPersistentActiveGrid(int prototypeToConstructGridFrom, string persistentDataToSetStateFrom = null, World alternateWorldToSyncTo = null, bool allowAlternateWorldToOverwriteWorldFromPersistentData = true, Transform alternatePlayerToAssociateWithGrid = null, PlayerMover playerMoverToAssociateWithGrid = null)
        /// </syntax>
        public ActiveGrid CreateNonPersistentActiveGrid(int prototypeToConstructGridFrom, 
            string persistentDataToSetStateFrom = null, World alternateWorldToSyncTo = null, 
            bool allowAlternateWorldToOverwriteWorldFromPersistentData = true, Transform alternatePlayerToAssociateWithGrid = null, 
            PlayerMover playerMoverToAssociateWithGrid = null)
        {
            if (prototypeToConstructGridFrom < 1 || prototypeToConstructGridFrom > activeGridPrototypes.Length || activeGridPrototypes[prototypeToConstructGridFrom - 1] == null)
                throw new InvalidPrototypeException(string.Format("CreateNonPersistentActiveGrid failed because the value passed in for prototypeToConstructGridFrom ({0}) is not associated with a valid prototype. Prototype must be in the range of 1 to [Number of Prototypes]. Did you remove the prototype in the inspector? Also make sure that prototype field has been set in the inspector.", prototypeToConstructGridFrom));

            return CreateActiveGrid(prototypeToConstructGridFrom, persistentDataToSetStateFrom, alternateWorldToSyncTo, allowAlternateWorldToOverwriteWorldFromPersistentData, alternatePlayerToAssociateWithGrid, playerMoverToAssociateWithGrid);
        }


        /// <summary>
        /// Creates and initializes a persistent Active Grid based on the prototype 
        /// and the specified optional parameters.
        /// The persistent grid will be saved with the component manager's save data, and 
        /// can only be synced with persistenet worlds.
        /// <para>
        /// Also keep in mind that when the Active Grid is initialized, the World the grid is 
        /// synced to will also be initialized, as well as this Component Manager if it has not 
        /// already been initialized.
        /// </para>
        /// <para>
        /// Note, you will need to manually load the grid's cell users in order for the 
        /// World the grid is synced to to load its objects. You can do this by calling 
        /// <see cref="ActiveGrid.TryLoadCellObjects" href="ActiveGrid.html#TryLoadCellObjects">
        /// TryLoadCellObjects
        /// </see> 
        /// or 
        /// <see cref="ActiveGrid.TryLoadCellObjectsAndWaitForLoadToComplete" href="ActiveGrid.html#TryLoadCellObjectsAndWaitForLoadToComplete">
        /// TryLoadCellObjectsAndWaitForLoadToComplete
        /// </see>.
        /// </para>
        /// </summary>
        /// <param name="prototypeToConstructGridFrom" type="int">
        /// The prototype to construct the grid from.
        /// </param>
        /// <param name="persistentDataToSetStateFrom" type="string">
        /// Optional persistent data retrieved from another Active Grid's 
        /// <see cref="ActiveGrid.GetPersistentStringSaveData" href="ActiveGrid.html#GetPersistentStringSaveData">
        /// GetPersistentStringSaveData
        /// </see> method, that can be used to set the initial state of the created Active Grid.
        /// <para>
        /// If this is not null but the 
        /// persistent data does not contain World information, the default World from the Active Grid Prototype will not be used. Instead, 
        /// the grid will act as if it has no world and sit idle, unless you pass in an alternateWorldToSyncTo. You can also sync the grid 
        /// to a world after creation using one of the grids sync methods (do not use 
        /// <see cref="ActiveGrid.PreInitialize_SetWorld" href="ActiveGrid.html#PreInit_SetWorld">PreInitialize_SetWorld</see>, 
        /// as the grid is automatically initialized before being returned to you).
        /// </para>
        /// </param>
        /// <param name="alternatePersistentWorldToSyncTo" type="World" link="World.html">
        /// An alternate world for the grid to start synced to. This must be a persistent world.
        /// </param>
        /// <param name="allowAlternateWorldToOverwriteWorldFromPersistentData" type="bool">
        /// When persistentDataToSetStateFrom is not null and contains valid world information, and alternateWorldToSyncTo is not null, 
        /// allowAlternateWorldToOverwriteWorldFromPersistentData will control which world is used. 
        /// </param>
        /// <returns type="ActiveGrid" link="ActiveGrid.html">
        /// The created and initialized non persistent Active Grid.
        /// </returns>
        /// <exception name="InvalidPrototypeException" link ="InvalidPrototypeException.html">
        /// Thrown when prototypeToConstructGridFrom 
        /// is invalid. Valid values range from 1 to [number of prototypes].
        /// </exception>
        /// <exception name="MissingComponentException">
        /// Thrown when persistentDataToSetStateFrom is not null and contains a World that should exist but does not anymore.
        /// </exception>
        /// <exception name="InvalidPersistenceException" link="InvalidPersistenceException.html">
        /// Thrown when alternatePersistentWorldToSyncTo not null and is not a persistent World.
        /// </exception>
        /// <displayName id="CreatePersistentActiveGrid">
        /// CreatePersistentActiveGrid(int, [string], [World], [bool])
        /// </displayName>
        /// <syntax>
        /// ActiveGrid CreatePersistentActiveGrid(int prototypeToConstructGridFrom, string persistentDataToSetStateFrom = null, World alternatePersistentWorldToSyncTo = null, bool allowAlternateWorldToOverwriteWorldFromPersistentData = true)
        /// </syntax>
        public ActiveGrid CreatePersistentActiveGrid(int prototypeToConstructGridFrom,
            string persistentDataToSetStateFrom = null, World alternatePersistentWorldToSyncTo = null,
            bool allowAlternateWorldToOverwriteWorldFromPersistentData = true)
        {
            if (prototypeToConstructGridFrom < 1 || prototypeToConstructGridFrom > activeGridPrototypes.Length || activeGridPrototypes[prototypeToConstructGridFrom - 1] == null)
                throw new InvalidPrototypeException(string.Format("CreatePersistentActiveGrid failed because the value passed in for prototypeToConstructGridFrom ({0}) is not associated with a valid prototype. Prototype must be in the range of 1 to [Number of Prototypes]. Did you remove the prototype in the inspector? Also make sure that prototype field has been set in the inspector.", prototypeToConstructGridFrom));

            if (alternatePersistentWorldToSyncTo != null && !alternatePersistentWorldToSyncTo.IsWorldPersistent)
                throw new InvalidPersistenceException("CreatePersistentActiveGrid call failed. The alternatePersistentWorldToSyncTo is not a persistent world.");

            return CreateActiveGrid(prototypeToConstructGridFrom, persistentDataToSetStateFrom, alternatePersistentWorldToSyncTo, allowAlternateWorldToOverwriteWorldFromPersistentData, null, null);
        }

        ActiveGrid CreateActiveGrid(int prototypeToConstructGridFrom, 
            string persistentDataToSetStateFrom = null, World alternateWorldToSyncTo = null, 
            bool allowAlternateWorldToOverwriteWorldFromPersistentData = true, Transform alternatePlayerToAssociateWithGrid = null, 
            PlayerMover playerMoverToAssociateWithGrid = null)
        {
            if (!IsInitialized)
                Initialize();

            int ID = CreateUniqueID<ActiveGrid>(activeGridsInScene, obsoleteActiveGrids, ref activeGridIDGenerationRange);
            ActiveGrid prototype = activeGridPrototypes[prototypeToConstructGridFrom - 1];
            ActiveGridState activeGridStateToStartIn = new ActiveGridState(prototype.activeGridState);

            ActiveGrid activeGrid = CreateActiveGrid_Internal(ID, prototype, prototypeToConstructGridFrom, activeGridStateToStartIn, false);

            if (alternatePlayerToAssociateWithGrid != null)
                activeGrid.PreInitialize_SetPlayer(alternatePlayerToAssociateWithGrid, playerMoverToAssociateWithGrid);

            if (persistentDataToSetStateFrom != null)
                activeGrid.SetStateFromSaveData(persistentDataToSetStateFrom, TryGetWorldByIDFunction);

            if (alternateWorldToSyncTo != null)
                activeGrid.PreInitialize_SetWorld(alternateWorldToSyncTo, allowAlternateWorldToOverwriteWorldFromPersistentData);

            if (!useCustomSaveLoadSolution)
                activeGrid.PersistentDataSaveKey = persistentDataController.SceneID + "_AG_" + activeGrid.ID;
            
            activeGrid.activeGridState.cellObjectsEnabled = false;

            activeGrid.Initialize(this);

            if (phase == Phase.Started)
                activeGrid.StartMonitoringIfNecessary();

            return activeGrid;
        }

        ActiveGrid CreateActiveGrid_Internal(int IDToAssignToActiveGrid, ActiveGrid prototypeToConstructActiveGridFrom,
            int prototypeIndex, ActiveGridState activeGridStateToStartIn, bool isGridPersistent)
        {
            ActiveGrid activeGrid = gameObject.AddComponent<ActiveGrid>();
            
            activeGrid.activeGridID = IDToAssignToActiveGrid;
            activeGrid.ChangeActiveGridState(activeGridStateToStartIn);
            CopyPrototypeSettingsToNewActiveGrid(prototypeToConstructActiveGridFrom, activeGrid);

            activeGridsInScene.Add(IDToAssignToActiveGrid, activeGrid);

            activeGrid.runtimeCreated = true;
            activeGrid.persistent = isGridPersistent;
            activeGrid.prototypeCreatedFrom = prototypeIndex;
            
            return activeGrid;
        }

        void CopyPrototypeSettingsToNewActiveGrid(ActiveGrid prototype, ActiveGrid newActiveGrid)
        {
            newActiveGrid.player = prototype.player;
            newActiveGrid.playerMover = prototype.playerMover;
            newActiveGrid.boundaryMonitor = prototype.boundaryMonitor;
            newActiveGrid.world = prototype.world;
            newActiveGrid.activeGridType = prototype.activeGridType;
        }




        /// <summary>
        /// Tries to get the <see href = "ActiveGrid.html">Active Grid</see> specified by ID. 
        /// </summary>
        /// <param name="ID" type="int">The ID of the Active Grid to get.</param>
        /// <param name="activeGrid" type="out ActiveGrid" link="ActiveGrid.html">When this method returns, contains the
        /// value associated with the specified ID if the ID is found; otherwise, null.</param>
        /// <returns type = "bool">A bool indicating whether the ActiveGrid was found.</returns>
        /// <displayName id="TryGetActiveGridByID">TryGetActiveGridByID(int, out ActiveGrid)</displayName>
        /// <syntax>public bool TryGetActiveGridByID(int ID, out ActiveGrid activeGrid)</syntax>
        public bool TryGetActiveGridByID(int ID, out ActiveGrid activeGrid)
        {
            return activeGridsInScene.TryGetValue(ID, out activeGrid);
        }

        /// <summary>
        /// Destroys the Active Grid with IDOfActiveGridToDestroy. All cell users associated with the Active Grid are removed from cells on the World the Active Grid
        /// is currently synced to. If those cells have no more cell users after this removal, the cell objects are removed from the scene.
        /// <para>This removal is performed over a series of frames for performance reasons, however this method destroys the Active Grid immediately and does not wait
        /// for the cell users (and associated cell objects) to be removed from the world. If you need to wait for this process to complete (perhaps you only want to perform
        /// some action after the cell users/objects have been removed), use <see href = "#DestroyActiveGridAfterRemovingCellUsers">DestroyActiveGridAfterRemovingCellUsers</see> instead.</para>
        /// </summary>
        /// <param name="IDOfActiveGridToDestroy" type = "int">The ID of the Active Grid to destroy</param>
        /// <example>
        /// <code>
        /// class DestroyActiveGridExample
        /// {
        ///     ActiveGrid myActiveGrid;
        ///     
        ///     public void OnDestroyActiveGrid()
        ///     {
        ///         //You should only have one component manager in the scene
        ///         ComponentManager componentManager = GameObject.FindObjectOfType&lt;ComponentManager&gt;();
        ///         
        ///         componentManager.DestroyActiveGrid(myActiveGrid.ID);
        ///     }
        /// }
        /// </code>
        /// </example>
        /// <exception name="InvalidIDException" link="InvalidIDException.html">
        /// Thrown when IDOfActiveGridToDestroy is not the ID of a valid Active Grid in the scene.
        /// </exception>
        /// <displayName id="DestroyActiveGrid">DestroyActiveGrid(int)</displayName>
        /// <syntax>public void DestroyActiveGrid(int IDOfActiveGridToDestroy)</syntax>
        public void DestroyActiveGrid(int IDOfActiveGridToDestroy)
        {
            ActiveGrid activeGrid;
            if (activeGridsInScene.TryGetValue(IDOfActiveGridToDestroy, out activeGrid))
            {
                CleanupActiveGridData(activeGrid);
                activeGrid.DestroyImmediately();
            }
            else
                throw new InvalidIDException("DestroyActiveGridAfterRemovingCellUsers failed. The IDOfActiveGridToDestroy passed in (" +
                IDOfActiveGridToDestroy + ") is not the ID of a valid Active Grid in the scene.");
        }

        /// <summary>
        /// Destroys the <see cref="ActiveGrid" href="ActiveGrid.html">Active Grid</see> with IDOfActiveGridToDestroy. All cell users associated with the Active Grid are removed from the cells on the World the Active Grid
        /// is currently synced to. If those cells have no more cell users after this removal, the cell objects are removed from the scene.
        /// <para>This removal is performed over a series of frames for performance reasons, and the Active Grid will only be destroyed after this removal
        /// process completes. This method should be used if you need to know when the cell users/objects are removed and want to wait for the process to complete.
        /// Use like any other coroutine.</para>
        /// </summary>
        /// <param name="IDOfActiveGridToDestroy" type = "int">The ID of the Active Grid to destroy</param>
        /// <example>Normal StartCoroutine Example
        /// <code>
        /// class DestroyActiveGridExample
        /// {
        ///     ActiveGrid myActiveGrid;
        ///     
        ///     //This method should have been called via StartCoroutine
        ///     public IEnumerator OnDestroyActiveGrid()
        ///     {
        ///         //You should only have one component manager in the scene
        ///         ComponentManager componentManager = GameObject.FindObjectOfType&lt;ComponentManager&gt;();
        ///         
        ///         yield return StartCoroutine(componentManager.DestroyActiveGridAfterRemovingCellUsers(myActiveGrid.ID));
        ///     }
        /// }
        /// </code>
        /// </example>
        /// <example>Coroutine without using StartCoroutine
        /// <code>
        /// class DestroyActiveGridExample
        /// {
        ///     ActiveGrid myActiveGrid;
        ///     
        ///     //This method should be started using StartCoroutine or iterated over manually in another coroutine
        ///     public IEnumerator&lt;YieldInstruction&gt; OnDestroyActiveGrid()
        ///     {
        ///         //You should only have one component manager in the scene
        ///         ComponentManager componentManager = GameObject.FindObjectOfType&lt;ComponentManager&gt;();
        ///         
        ///         IEnumerator&lt;YieldInstruction&gt; e = componentManager.DestroyActiveGridAfterRemovingCellUsers(myActiveGrid.ID);
        ///         while(e.MoveNext())
        ///             yield return e.Current;
        ///     }
        /// }
        /// </code>
        /// </example>
        /// <exception name="InvalidIDException" link="InvalidIDException.html">
        /// Thrown when IDOfActiveGridToDestroy is not the ID of a valid Active Grid in the scene.
        /// </exception>
        /// <displayName id="DestroyActiveGridAfterRemovingCellUsers">DestroyActiveGridAfterRemovingCellUsers(int)</displayName>
        /// <syntax>public IEnumerator&lt;YieldInstruction&gt; DestroyActiveGridAfterRemovingCellUsers(int IDOfActiveGridToDestroy)</syntax>
        public IEnumerator<YieldInstruction> DestroyActiveGridAfterRemovingCellUsers(int IDOfActiveGridToDestroy)
        {
            ActiveGrid activeGrid;
            if (activeGridsInScene.TryGetValue(IDOfActiveGridToDestroy, out activeGrid))
            {
                CleanupActiveGridData(activeGrid);
                IEnumerator<YieldInstruction> destroyEnumerator = activeGrid.DestroyAfterRemovingAllCellUsers();
                while (destroyEnumerator.MoveNext())
                    yield return destroyEnumerator.Current;
            }
            else
                throw new InvalidIDException("DestroyActiveGridAfterRemovingCellUsers failed. The IDOfActiveGridToDestroy passed in (" +
                IDOfActiveGridToDestroy + ") is not the ID of a valid Active Grid in the scene.");
        }

        void CleanupActiveGridData(ActiveGrid activeGridToDestroy)
        {
            int activeGridID = activeGridToDestroy.ID;
            activeGridsInScene.Remove(activeGridID);

            if (!activeGridToDestroy.runtimeCreated)
                ObsoleteActiveGrids.Add(activeGridID);
        }

        #endregion

        #region World related methods

        /// <summary>
        /// Creates and initializes a persistent World using the information from the 
        /// prototype and optional parameters.
        /// The persistent world will be saved with the component manager's save data, 
        /// and both persistent and non persistent Active Grids can sync to it. Calling this method will 
        /// initialize this Component Manager if it has not already been initialized.
        /// </summary>
        /// <param name="prototypeToConstructWorldFrom" type="int">
        /// The index of the prototype to use to construct the World.
        /// <para>
        /// For instance, if the prototype is in the "Prototype 1" field, pass 1 in as the argument.
        /// </para>
        /// </param>
        /// <param name="persistentDataToSetStateFrom" type="string">
        /// Optional persistent data retrieved from another Worlds 
        /// <see cref="World.GetPersistentStringSaveData" href="World.html#GetPersistentStringSaveData1">
        /// GetPersistentStringSaveData
        /// </see> method, that can be used to set the initial state of the created World.
        /// </param>
        /// <param name="alternateGroupNameToUse" type="string">
        /// An alternate group name for the world to start with. The group name controls which objects are loaded by the world. If null,
        /// the group name from the save data will be used. If the save data is null, the default group name from the World Grid on the 
        /// prototype will be used.
        /// </param>
        /// <param name="allowAlternateGroupNameToOverwriteGroupNameFromPersistentData" type="bool">
        /// When persistentDataToSetStateFrom and alternateGroupNameToUse are both not null, 
        /// allowAlternateGroupNameToOverwriteGroupNameFromPersistentData will control which group name is used. 
        /// <para>
        /// A value of true will force alternateGroupNameToUse to be used, while a value of false will force the group name 
        /// from persistentDataToSetStateFrom to be used.
        /// </para>
        /// </param>
        /// <param name="alternateWorldOrigin" type="Vector3">
        /// An alternate world origin for the created World to use. If null, the world origin from the save data will be used. If the 
        /// save data is null, the prototypes world origin will be used.
        /// </param>
        /// <param name="allowAlternateWorldOriginToOverwriteWorldOriginFromPersistetnData" type="bool">
        /// When persistentDataToSetStateFrom and alternateWorldOrigin are both not null, 
        /// allowAlternateWorldOriginToOverwriteWorldOriginFromPersistetnData will control which world origin is used.
        /// <para>
        /// A value of true will force alternateWorldOrigin to be used, while a value of false will force the world origin 
        /// from persistentDataToSetStateFrom to be used.
        /// </para>
        /// </param>
        /// <param name="alternateOriginCell" type="Cell" link="Cell.html">
        /// An alternate origin cell for the created World to use. If null, the origin cell specified in the save data will be used.
        /// If the save data is null, the origin cell from the prototype is used.
        /// <para>
        /// Note, this origin cell is 1 based, i.e., the bottom left most cell of the world has an index of row = 1, column = 1, and 
        /// layer = 1 (for 3D worlds). The origin cell in the save data, on the other hand, is 0 based.
        /// </para>
        /// </param>
        /// <param name="allowAlternateOriginCellToOverwriteOriginCellFromPersistentData" type="bool">
        /// When persistentDataToSetStateFrom and alternateOriginCell are both not null, 
        /// allowAlternateOriginCellToOverwriteOriginCellFromPersistentData will control while origin cell is used.
        /// <para>
        /// A value of true will force alternateOriginCell to be used, while a value of false will force the origin cell 
        /// from persistentDataToSetStateFrom to be used.
        /// </para>
        /// </param>
        /// <returns type="World" link="World.html">
        /// The created and initialized persistent World.
        /// </returns>
        /// <exception name="InvalidPrototypeException" link ="InvalidPrototypeException.html">
        /// Thrown when prototypeToConstructWorldFrom 
        /// is invalid. Valid values range from 1 to [number of prototypes].
        /// </exception>
        /// <displayName id="CreatePersistentWorld">CreatePersistentWorld(int, [string], [string], [bool], [Vector3])</displayName>
        /// <syntax>public World CreatePersistentWorld(int prototypeToConstructWorldFrom, string persistentDataToSetStateFrom = null, string alternateGroupNameToUse = null, bool allowAlternateGroupNameToOverwriteGroupNameFromPersistentData = true, Vector3? alternateWorldOrigin = null)</syntax>
        public World CreatePersistentWorld(int prototypeToConstructWorldFrom, string persistentDataToSetStateFrom = null, string alternateGroupNameToUse = null, bool allowAlternateGroupNameToOverwriteGroupNameFromPersistentData = true, Vector3? alternateWorldOrigin = null, bool allowAlternateWorldOriginToOverwriteWorldOriginFromPersistetnData = true, Cell? alternateOriginCell = null, bool allowAlternateOriginCellToOverwriteOriginCellFromPersistentData = true)
        {
            if (prototypeToConstructWorldFrom > worldPrototypes.Length || prototypeToConstructWorldFrom < 1 || worldPrototypes[prototypeToConstructWorldFrom - 1] == null)
                throw new InvalidPrototypeException(string.Format("CreatePersistentWorld failed because the value passed in for prototypeToConstructWorldFrom ({0}) is not associated with a valid prototype. Prototype must be in the range of 1 to [Number of Prototypes]. Did you remove the prototype in the inspector? Also make sure that prototype field has been set in the inspector.", prototypeToConstructWorldFrom));

            return CreateWorld(prototypeToConstructWorldFrom, true, persistentDataToSetStateFrom, alternateGroupNameToUse, allowAlternateGroupNameToOverwriteGroupNameFromPersistentData, alternateWorldOrigin, allowAlternateWorldOriginToOverwriteWorldOriginFromPersistetnData, alternateOriginCell, allowAlternateOriginCellToOverwriteOriginCellFromPersistentData);
        }

        /// <summary>
        /// Creates and initializes a non persistent World using the information from 
        /// the prototype and optional parameters.
        /// The non persistent world will be saved with the component manager's save data, 
        /// but only non persistent Active Grid's  will be able to sync to it. Calling this method will 
        /// initialize this Component Manager if it has not already been initialized.
        /// </summary>
        /// <param name="prototypeToConstructWorldFrom" type="int">
        /// The index of the prototype to use to construct the World.
        /// <para>
        /// For instance, if the prototype is in the "Prototype 1" field, pass 1 in as the argument.
        /// </para>
        /// </param>
        /// <param name="persistentDataToSetStateFrom" type="string">
        /// Optional persistent data retrieved from another Worlds 
        /// <see cref="World.GetPersistentStringSaveData" href="World.html#GetPersistentStringSaveData">
        /// GetPersistentStringSaveData
        /// </see> method, that can be used to set the initial state of the created World.
        /// </param>
        /// <param name="alternateGroupNameToUse" type="string">
        /// An alternate group name for the world to start with. The group name controls which objects are loaded by the world. If null,
        /// the group name from the save data will be used. If the save data is null, the default group name from the World Grid on the 
        /// prototype will be used.
        /// </param>
        /// <param name="allowAlternateGroupNameToOverwriteGroupNameFromPersistentData" type="bool">
        /// When persistentDataToSetStateFrom and alternateGroupNameToUse are both not null, 
        /// allowAlternateGroupNameToOverwriteGroupNameFromPersistentData will control which group name is used. 
        /// <para>
        /// A value of true will force alternateGroupNameToUse to be used, while a value of false will force the group name 
        /// from persistentDataToSetStateFrom to be used.
        /// </para>
        /// </param>
        /// <param name="alternateWorldOrigin" type="Vector3">
        /// An alternate world origin for the created World to use. If null, the world origin from the save data will be used. If the 
        /// save data is null, the prototypes world origin will be used.
        /// </param>
        /// <param name="allowAlternateWorldOriginToOverwriteWorldOriginFromPersistetnData" type="bool">
        /// When persistentDataToSetStateFrom and alternateWorldOrigin are both not null, 
        /// allowAlternateWorldOriginToOverwriteWorldOriginFromPersistetnData will control which world origin is used.
        /// <para>
        /// A value of true will force alternateWorldOrigin to be used, while a value of false will force the world origin 
        /// from persistentDataToSetStateFrom to be used.
        /// </para>
        /// </param>
        /// <param name="alternateOriginCell" type="Cell" link="Cell.html">
        /// An alternate origin cell for the created World to use. If null, the origin cell specified in the save data will be used.
        /// If the save data is null, the origin cell from the prototype is used.
        /// <para>
        /// Note, this origin cell is 1 based, i.e., the bottom left most cell of the world has an index of row = 1, column = 1, and 
        /// layer = 1 (for 3D worlds). The origin cell in the save data, on the other hand, is 0 based.
        /// </para>
        /// </param>
        /// <param name="allowAlternateOriginCellToOverwriteOriginCellFromPersistentData" type="bool">
        /// When persistentDataToSetStateFrom and alternateOriginCell are both not null, 
        /// allowAlternateOriginCellToOverwriteOriginCellFromPersistentData will control while origin cell is used.
        /// <para>
        /// A value of true will force alternateOriginCell to be used, while a value of false will force the origin cell 
        /// from persistentDataToSetStateFrom to be used.
        /// </para>
        /// </param>
        /// <returns type="World" link="World.html">
        /// The created and initialized non persistent World.
        /// </returns>
        /// <exception name="InvalidPrototypeException" link ="InvalidPrototypeException.html">
        /// Thrown when prototypeToConstructWorldFrom 
        /// is invalid. Valid values range from 1 to [number of prototypes].
        /// </exception>
        /// <displayName id="CreateNonPersistentWorld">
        /// CreateNonPersistentWorld(int, [string], [string], [bool], [Vector3])
        /// </displayName>
        /// <syntax>public World CreateNonPersistentWorld(int prototypeToConstructWorldFrom, string persistentDataToSetStateFrom = null, string alternateGroupNameToUse = null, bool allowAlternateGroupNameToOverwriteGroupNameFromPersistentData = true, Vector3? alternateWorldOrigin = null)</syntax>
        public World CreateNonPersistentWorld(int prototypeToConstructWorldFrom, string persistentDataToSetStateFrom = null, string alternateGroupNameToUse = null, bool allowAlternateGroupNameToOverwriteGroupNameFromPersistentData = true, Vector3? alternateWorldOrigin = null, bool allowAlternateWorldOriginToOverwriteWorldOriginFromPersistetnData = true, Cell? alternateOriginCell = null, bool allowAlternateOriginCellToOverwriteOriginCellFromPersistentData = true)
        {
            if (prototypeToConstructWorldFrom > worldPrototypes.Length || prototypeToConstructWorldFrom < 1 || worldPrototypes[prototypeToConstructWorldFrom - 1] == null)
                throw new InvalidPrototypeException(string.Format("CreateNonPersistentWorld failed because the value passed in for prototypeToConstructWorldFrom ({0}) is not associated with a valid prototype. Prototype must be in the range of 1 to [Number of Prototypes]. Did you remove the prototype in the inspector? Also make sure that prototype field has been set in the inspector.", prototypeToConstructWorldFrom));

            return CreateWorld(prototypeToConstructWorldFrom, false, persistentDataToSetStateFrom, alternateGroupNameToUse, allowAlternateGroupNameToOverwriteGroupNameFromPersistentData, alternateWorldOrigin, allowAlternateWorldOriginToOverwriteWorldOriginFromPersistetnData, alternateOriginCell, allowAlternateOriginCellToOverwriteOriginCellFromPersistentData);
        }

        World CreateWorld(int prototypeToConstructWorldFrom, bool isWorldPersistent, string persistentDataToSetStateFrom = null, string alternateGroupNameToUse = null, bool allowAlternateGroupNameToOverwriteGroupNameFromPersistentData = true, Vector3? alternateWorldOrigin = null, bool allowAlternateWorldOriginToOverwriteWorldOriginFromPersistetnData = true, Cell? alternateOriginCell = null, bool allowAlternateOriginCellToOverwriteOriginCellFromPersistentData = true)
        {
            if (!IsInitialized)
                Initialize();

            int ID = CreateUniqueID<World>(worldsInScene, obsoleteWorlds, ref worldIDGenerationRange);
            World prototype = worldPrototypes[prototypeToConstructWorldFrom - 1];
            
            World world = CreateWorld_Internal(ID, prototype, prototypeToConstructWorldFrom, isWorldPersistent);

            if (alternateWorldOrigin != null)
            {
                world.PreInitialize_SetWorldOrigin((Vector3)alternateWorldOrigin, allowAlternateWorldOriginToOverwriteWorldOriginFromPersistetnData);
            }
            else
            {
                if (prototype.useThisGameObjectsPositionAsWorldOrigin)
                    world.worldOrigin = prototype.gameObject.transform.position;
                else
                {
                    world.useThisGameObjectsPositionAsWorldOrigin = false;
                    world.worldOrigin = prototype.worldOrigin;
                }
            }

            if (alternateGroupNameToUse != null)
                world.PreInitialize_SetGroupName(alternateGroupNameToUse, allowAlternateGroupNameToOverwriteGroupNameFromPersistentData);

            if (alternateOriginCell != null)
                world.PreInitialize_SetOriginCell((Cell)alternateOriginCell, allowAlternateOriginCellToOverwriteOriginCellFromPersistentData);

            if (persistentDataToSetStateFrom != null)
                world.SetStateFromSaveData(persistentDataToSetStateFrom);

            if (!useCustomSaveLoadSolution)
                world.PersistentDataSaveKey = persistentDataController.SceneID + "_W_" + world.ID;

            world.Initialize(this);

            return world;
        }

        World CreateWorld_Internal(int IDToAssignToWorld, World prototypeToConstructWorldFrom, int prototypeIndex, bool isWorldPersistent)
        {
            World world = gameObject.AddComponent<World>();

            world.worldID = IDToAssignToWorld;
            
            CopyPrototypeSettingsToNewWorld(world, prototypeToConstructWorldFrom);

            world.runtimeCreated = true;
            world.persistent = isWorldPersistent;
            world.PrototypeConstructedFrom = prototypeIndex;

            worldsInScene.Add(IDToAssignToWorld, world);

            return world;
        }

        void CopyPrototypeSettingsToNewWorld(World newWorld, World prototype)
        {
            newWorld.areLayersEndless = prototype.areLayersEndless;
            newWorld.areRowsEndless = prototype.areRowsEndless;
            newWorld.areColumnsEndless = prototype.areColumnsEndless;
            newWorld.worldGrid = prototype.worldGrid;
            newWorld.primaryCellObjectSubController = prototype.primaryCellObjectSubController;
            newWorld.keepWorldCenteredAroundOrigin = prototype.keepWorldCenteredAroundOrigin;
            newWorld.distanceOfEastAndWestShiftBoundaryFromOrigin = prototype.distanceOfEastAndWestShiftBoundaryFromOrigin;
            newWorld.distanceOfNorthAndSouthShiftBoundaryFromOrigin = prototype.distanceOfNorthAndSouthShiftBoundaryFromOrigin;
            newWorld.distanceOfTopAndBottomShiftBoundaryFromOrigin = prototype.distanceOfTopAndBottomShiftBoundaryFromOrigin;
        }


        /// <summary>
        /// Tries to get the <see cref = "World" href = "World.html">World</see> specified by worldID. 
        /// </summary>
        /// <param name="worldID" type ="int">The ID of the World to get.</param>
        /// <param name="world" type = "out World" link = "World.html">When this method returns, contains the
        /// value associated with the specified worldID if the worldID is found; otherwise, null.</param>
        /// <returns type = "bool">A bool indicating whether the World was found.</returns>
        /// <displayName id="TryGetWorldByID">TryGetWorldByID(int, World)</displayName>
        /// <syntax>public bool TryGetWorldByID(int worldID, out World world)</syntax>
        public bool TryGetWorldByID(int worldID, out World world)
        {
            return worldsInScene.TryGetValue(worldID, out world);
        }

        
        /// <summary>
        /// Destroys the World with IDofWorldToDestroy. All cell objects associated with the World are removed from the scene.
        /// This removal is performed over a series of frames for performance reasons, though the world's destruction will be reflected 
        /// in the persistent data if you save during the process. 
        /// If you care about when the removal process completes (and thus when the
        /// World is actually destroyed) use DestroyWorldAndWaitForCellObjectsToBeRemoved instead 
        /// (use it like you'd use any other coroutine).
        /// </summary>
        /// <param name="IDOfWorldToDestroy" type="int">The ID of the World to destroy</param>
        /// <example>
        /// <code>
        /// class DestroyWorldExample
        /// {
        ///     World myWorld;
        ///     
        ///     public void OnDestroyWorld()
        ///     {
        ///         //You should only have one component manager in the scene
        ///         ComponentManager componentManager = GameObject.FindObjectOfType&lt;ComponentManager&gt;();
        ///         
        ///         componentManager.DestroyWorld(myWorld.ID);
        ///     }
        /// }
        /// </code>
        /// </example>
        /// <exception name="InvalidIDException" link="InvalidIDException.html">
        /// Thrown when IDOfWorldToDestroy is not the ID of a valid World in the scene.
        /// </exception>
        /// <displayName id="DestroyWorld">DestroyWorld(int)</displayName>
        /// <sytax>public void DestroyWorld(int IDOfWorldToDestroy)</sytax>
        public void DestroyWorld(int IDOfWorldToDestroy)
        {
            World world;
            if (worldsInScene.TryGetValue(IDOfWorldToDestroy, out world))
            {
                CleanupWorldData(world);
                StartCoroutine(world.Destroy());
            }
            else
                throw new InvalidIDException("DestroyWorld failed. The IDOfWorldToDestroy passed in (" +
                IDOfWorldToDestroy + ") is not the ID of a valid World in the scene.");
        }

        /// <summary>
        /// Same as <see cref="DestroyWorld" href="#DestroyWorld">DestroyWorld</see>, except with this method you can wait for the World to complete its cell object removal and be destroyed.
        /// Use like you'd use any other coroutine.
        /// </summary>
        /// <param name="IDOfWorldToDestroy" type="int">The ID of the World to destroy</param>
        /// <returns type = "IEnumerator&lt;YieldInstruction&gt;">An IEnumerator&lt;YieldInstruction&gt; that can be iterated over or used as a coroutine.</returns>
        /// <example>Normal StartCoroutine Example
        /// <code>
        /// class DestroyWorldExample
        /// {
        ///     World myWorld;
        ///     
        ///     //This method should have been called via StartCoroutine
        ///     public IEnumerator OnDestroyWorld()
        ///     {
        ///         //You should only have one component manager in the scene
        ///         ComponentManager componentManager = GameObject.FindObjectOfType&lt;ComponentManager&gt;();
        ///         
        ///         yield return StartCoroutine(componentManager.DestroyWorldAndWaitForCellObjectsToBeRemoved(myWorld.ID));
        ///     }
        /// }
        /// </code>
        /// </example>
        /// <example>Coroutine without using StartCoroutine
        /// <code>
        /// class DestroyWorldExample
        /// {
        ///     World myWorld;
        ///     
        ///     //This method should be started using StartCoroutine or iterated over manually in another coroutine
        ///     public IEnumerator&lt;YieldInstruction&gt; OnDestroyWorld()
        ///     {
        ///         //You should only have one component manager in the scene
        ///         ComponentManager componentManager = GameObject.FindObjectOfType&lt;ComponentManager&gt;();
        ///         
        ///         IEnumerator&lt;YieldInstruction&gt; e = componentManager.DestroyWorldAndWaitForCellObjectsToBeRemoved(myWorld.ID);
        ///         while(e.MoveNext())
        ///             yield return e.Current;
        ///     }
        /// }
        /// </code>
        /// </example>
        /// <exception name="InvalidIDException" link="InvalidIDException.html">
        /// Thrown when IDOfWorldToDestroy is not the ID of a valid World in the scene.
        /// </exception>
        /// <displayName id="DestroyWorldAndWaitForCellObjectsToBeRemoved">DestroyWorldAndWaitForCellObjectsToBeRemoved(int)</displayName>
        /// <syntax>public IEnumerator&lt;YieldInstruction&gt; DestroyWorldAndWaitForCellObjectsToBeRemoved(int IDOfWorldToDestroy)</syntax>
        public IEnumerator<YieldInstruction> DestroyWorldAndWaitForCellObjectsToBeRemoved(int IDOfWorldToDestroy)
        {
            World world;
            if (worldsInScene.TryGetValue(IDOfWorldToDestroy, out world))
            {
                CleanupWorldData(world);
                IEnumerator<YieldInstruction> RemoveCellUsers_ZeroBasedEnumerator = world.Destroy();
                while (RemoveCellUsers_ZeroBasedEnumerator.MoveNext())
                    yield return RemoveCellUsers_ZeroBasedEnumerator.Current;
            }
            else
                throw new InvalidIDException("DestroyWorldAndWaitForCellObjectsToBeRemoved failed. The IDOfWorldToDestroy passed in (" +
                IDOfWorldToDestroy + ") is not the ID of a valid World in the scene.");
        }

        void CleanupWorldData(World world)
        {
            int worldID = world.ID;
            worldsInScene.Remove(worldID);

            if(!world.runtimeCreated)
                ObsoleteWorlds.Add(worldID);//Make sure world is destroyed on next load
        }

        #endregion

        int CreateUniqueID<T>(Dictionary<int, T> objectsInScene, HashSet<int> obsoleteObjects, ref int IDGenerationRange)
        {
            int ID = Random.Range(0, IDGenerationRange);

            int attempts = 0;

            if (obsoleteObjects == null)
            {
                while (objectsInScene.ContainsKey(ID))
                {
                    ID = Random.Range(0, IDGenerationRange);
                    attempts++;

                    if (attempts == IDGenerationRange)
                        IDGenerationRange *= 2;
                }
            }
            else
            {
                while (objectsInScene.ContainsKey(ID) || obsoleteObjects.Contains(ID))
                {
                    ID = Random.Range(0, IDGenerationRange);
                    attempts++;

                    if (attempts == IDGenerationRange)
                        IDGenerationRange *= 2;
                }
            }

            return ID;
        }

        #region State Saving
        void OnApplicationQuit()
        {
            if (!useCustomSaveLoadSolution && persistentDataController != null && autoSaveDataOnGameExit)
            {
                if (errorFree)
                    Save();
                else if (!suppressWarnings)
                    Debug.LogError("The Component Manager with ID " + ID + "was not setup correctly, and so its persistent data will not be automatically saved.");
            }
        }

        /// <summary>
        /// Saves this component manager data, including the data of all persistent Active Grids and Worlds in the scene in a single frame.
        /// <para>
        /// If you check "Use Custom Save/Load Solution," use GetSaveData and LoadSaveData instead.
        /// </para>
        /// </summary>
        /// <displayName id="Save">Save()</displayName>
        /// <syntax>public void Save()</syntax>
        /// <exception name="InvalidOperationException">Thrown when this method is called and Use Custom Save/Load Solution is 
        /// checked in the inspector, or 
        /// when the Component Manager was not initialized correctly due to errors</exception>
        public void Save()
        {
            if (errorFree)
            {
                if (useCustomSaveLoadSolution)
                    throw new InvalidOperationException("Save call on Component Manager with ID " + ID + " failed. Save can only be used when 'Use Custom Save/Load Solution' is disabled.");
                SaveComponentManagerData();
                stringBuilderForSaving.Length = 0;
                SaveWorldData();
                SaveActiveGridData();
            }
            else
                throw new InvalidOperationException("Save call on Component Manager with ID " + ID + " failed. One or more errors exist and the Component Manager was not initialized correctly.");
        }

        void SaveComponentManagerData()
        {
            stringBuilderForSaving.Length = 0;
            AppendComponentManagerSaveDataToStringBuilder();
            string saveData = stringBuilderForSaving.ToString();

            if (saveData == "X;X;X;X")
                persistentDataController.TryDeleteData(persistentDataSaveKey);
            else
                persistentDataController.SaveData(persistentDataSaveKey, saveData);
        }

        void SaveActiveGridData()
        {
            foreach (ActiveGrid grid in activeGridsInScene.Values)
            {
                if(grid.IsActiveGridPersistent)
                    persistentDataController.SaveData(grid.PersistentDataSaveKey, grid.GetPersistentStringSaveData(stringBuilderForSaving));
            }
        }

        void SaveWorldData()
        {
            foreach (World world in worldsInScene.Values)
            {
                if(world.IsWorldPersistent)
                    persistentDataController.SaveData(world.PersistentDataSaveKey, world.GetPersistentStringSaveData(stringBuilderForSaving));
            }
        }
       

        void AppendComponentManagerSaveDataToStringBuilder()
        {
            AppendObsoleteDataToStringBuilder(obsoleteActiveGrids);
            stringBuilderForSaving.Append(';');
            AppendObsoleteDataToStringBuilder(obsoleteWorlds);
            stringBuilderForSaving.Append(';');
            AppendRunTimeCreatedActiveGridDataToStringBuilder();
            stringBuilderForSaving.Append(';');
            AppendRunTimeCreatedWorldDataToStringBuilder();
        }

        void AppendObsoleteDataToStringBuilder(HashSet<int> obsoleteData)
        {
            if (obsoleteData == null || obsoleteData.Count == 0)
                stringBuilderForSaving.Append("X");
            else
            {
                foreach (int ID in obsoleteData)
                {
                    stringBuilderForSaving.Append(ID);
                    stringBuilderForSaving.Append('|');
                }
                stringBuilderForSaving.Length = stringBuilderForSaving.Length - 1;
            }
        }

        void AppendRunTimeCreatedActiveGridDataToStringBuilder()
        {
            int count = 0;
            foreach (ActiveGrid grid in activeGridsInScene.Values)
            {
                if (grid.runtimeCreated && grid.IsActiveGridPersistent)
                {
                    count++;
                    stringBuilderForSaving.Append(grid.ID);
                    stringBuilderForSaving.Append('|');
                    stringBuilderForSaving.Append(grid.prototypeCreatedFrom);
                    stringBuilderForSaving.Append('/');
                }
            }

            if (count == 0)
                stringBuilderForSaving.Append("X");//No runtime created persistent active grids exist
            else
                stringBuilderForSaving.Length = stringBuilderForSaving.Length - 1;
        }

        void AppendRunTimeCreatedWorldDataToStringBuilder()
        {
            int count = 0;
            foreach (World world in worldsInScene.Values)
            {
                if(world.runtimeCreated && world.IsWorldPersistent)
                {
                    count++;
                    stringBuilderForSaving.Append(world.ID);
                    stringBuilderForSaving.Append('|');
                    stringBuilderForSaving.Append(world.PrototypeConstructedFrom);
                    stringBuilderForSaving.Append('/');
                }
            }

            if (count == 0)
                stringBuilderForSaving.Append("X");//No runtime created persistent active grids exist
            else
                stringBuilderForSaving.Length = stringBuilderForSaving.Length - 1;
        }

        /// <summary>
        /// Gets data that can be used to save/load the state of the Component Manager and all persistent Worlds and 
        /// Active Grids in the current scene.
        /// <para>
        /// This method should only be used when "Use Custom Save/Load Solution" is checked in the inspector.
        /// </para>
        /// </summary>
        /// <displayName id="GetSaveData">GetSaveData()</displayName>
        /// <syntax>public string GetSaveData()</syntax>
        /// <returns type="string">
        /// A string storing the data needed to save/load the Dynamic Loading Kits state.
        /// </returns>
        /// <exception name="InvalidOperationException">
        /// Thrown when this method is called and Use Custom Save/Load Solution is not checked in the inspector, or 
        /// when the Component Manager was not initialized correctly due to errors.
        /// </exception>
        public string GetSaveData()
        {
            if(!useCustomSaveLoadSolution)
                throw new InvalidOperationException("GetSaveData call on Component Manager with ID " + ID + " failed. GetSaveData can only be used when 'Use Custom Save/Load Solution' is enabled.");

            if (!errorFree)
                throw new InvalidOperationException("GetSaveData call on Component Manager with ID " + ID + " failed. The component manager had errors and was not initialized correctly. All errors must be corrected before GetSaveData can be used.");

            stringBuilderForSaving.Length = 0;
            stringBuilderForSaving.Append(ID);
            stringBuilderForSaving.Append('?');

            AppendComponentManagerSaveDataToStringBuilder();
            stringBuilderForSaving.Append('?');

            AppendDataForAllPersistentActiveGrids();
            stringBuilderForSaving.Append('?');

            AppendDataForAllPersistentWorlds();

            return stringBuilderForSaving.ToString();
        }

        void AppendDataForAllPersistentActiveGrids()
        {
            int count = 0;
            foreach (ActiveGrid grid in activeGridsInScene.Values)
            {
                if (grid.IsActiveGridPersistent)
                {
                    count++;
                    stringBuilderForSaving.Append(grid.ID);
                    stringBuilderForSaving.Append(':');
                    grid.AppendPersistentDataToStringBuilder(stringBuilderForSaving);
                    stringBuilderForSaving.Append('$');//Get rid of last $ symbol
                }
            }

            if (count == 0)
                stringBuilderForSaving.Append("X");//No persistent active grids exist
            else
                stringBuilderForSaving.Length = stringBuilderForSaving.Length - 1;
        }

        void AppendDataForAllPersistentWorlds()
        {
            int count = 0;
            foreach (World world in worldsInScene.Values)
            {
                if (world.IsWorldPersistent)
                {
                    count++;
                    stringBuilderForSaving.Append(world.ID);
                    stringBuilderForSaving.Append(':');
                    world.AppendPersistentDataToStringBuilder(stringBuilderForSaving);
                    stringBuilderForSaving.Append('$');
                }
            }

            if (count == 0)
                stringBuilderForSaving.Append("X");//No persistent active grids exist
            else
                stringBuilderForSaving.Length = stringBuilderForSaving.Length - 1;//Get rid of last $ symbol
        }
        #endregion
    }
}