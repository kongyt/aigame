﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System.Collections;
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// A Cell Object Loader component which loads objects via Asset Bundles.
    /// <para>
    /// This loader is only available to Unity 5 users and requires that you download the Asset Bundle Manager package from the Unity 
    /// Asset Store, which can be found <see href="https://www.assetstore.unity3d.com/en/#!/content/45836">here</see>. It's also a good 
    /// idea to read the article found <see href="https://unity3d.com/learn/tutorials/topics/scripting/assetbundles-and-assetbundle-manager">here</see> 
    /// if you are not familiar with the Asset Bundle Manager.
    /// </para>
    /// <para>
    /// Also note that inspector settings found on the BaseSceneLoader class are not listed here, instead you should look at the page for 
    /// the BaseSceneLoader.
    /// </para>
    /// <para>
    /// For detailed information about Asset Bundle integration with this package, please read the
    /// <see href="http://deepspacelabs.net/files/Asset%20Bundle%20Loader_QuickGuide.pdf">Asset Bundle Loader Quick Guide</see>.
    /// </para>
    /// </summary>
    /// <title>AssetBundleLoader Class</title>
    /// <category>Cell Object Loaders</category>
    /// <navigationName>AssetBundleLoader</navigationName>
    /// <fileName>AssetBundleLoader.html</fileName>
    /// <syntax>public class AssetBundleLoader : <see cref = "BaseSceneLoader" href = "BaseSceneLoader.html">BaseSceneLoader</see></syntax>
    /// <inspector name = "Log Mode" type = "AssetBundleManagerLogMode">
    /// Determines whether all messages are logged to the console or only errors.
    /// </inspector>
    /// <inspector name = "Streaming Type" type = "StreamingType">
    /// Determines the way the asset bundles will be streamed in.
    /// </inspector>
    /// <inspector name = "Server URL" type = "string">
    /// If Streaming Type is set to 'Remote Server', you must specify a string that identifies your server URL.
    /// </inspector>
    /// <inspector name = "Variant Possibilities" type = "string[]">
    /// Variants can be used to load different variations of your cell objects. You can read more about variant possibilities in the article linked 
    /// to at the top of this page. Set to 0 to not use variants.
    /// </inspector>
    /// <inspector name = "Active Variant" type = "string">
    /// When one or more variant possibilities are specified, you must set which one is the starting active variant in this field.
    /// </inspector>
    class AssetBundleLoader
    {        

        /// <summary>
        /// Single frame loading is not possible with asset bundles, so this just returns false.
        /// </summary>
        /// <type>bool</type>
        bool IsSingleFrameAttachmentPreloadRequired
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Loads the object specified by objectName via the Asset Bundle Streaming Type specified. This name is converted to 
        /// lowercase first.
        /// </summary>
        /// <param name="objectName" type = "string">The name of the object/scene to load.</param>
        /// <displayName id = "LoadCellObjectIntoLevel">LoadCellObjectIntoLevel(string)</displayName>
        /// <syntax>protected sealed override YieldInstruction LoadCellObjectIntoLevel(string objectName)</syntax>
        /// <returns type = "YieldInstruction" link = "http://docs.unity3d.com/ScriptReference/YieldInstruction.html">An object which
        /// inherits from YieldInstruction. Can also be null.</returns>
        YieldInstruction LoadCellObjectIntoLevel(string objectName) { return null; }

        /// <summary>
        /// Single frame attachment is not possible with Asset Bundles, as they need to be downloaded, which
        /// takes time. Therefore, we will leave this method as not implemented, so that it throws
        /// an exception if called (which is possible under certain circumstances).
        /// <para>
        /// You shouldn't ever manually call this method.
        /// </para>
        /// </summary>
        /// <typeparam name="T">The type of cells.</typeparam>
        /// <param name="cells" type = "List&lt;T&gt;">The cells whose objects need to be pre loaded.</param>
        /// <param name="loaderID" type = "int">The ID of the user requesting the pre load.</param>
        /// <displayName id = "AttachCellObjectsToCellsInSingleFrame">AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt;, int)</displayName>
        /// <syntax>public override void AttachCellObjectsToCellsInSingleFrame&lt;T&gt;(List&lt;T&gt; cells, int loaderID)</syntax>
        void AttachCellObjectsToCellsInSingleFrame<T>(List<T> cells, int loaderID)
        {
        }

        /// <summary>
        /// Changes the active variant.
        /// </summary>
        /// <param name="variantName" type = "string">The name of the variant to set as the active variant.</param>
        /// <displayName id = "SetVariant1">SetVariant(string)</displayName>
        /// <syntax>public void SetVariant(string variantName)</syntax>
        void SetVariant(string variantName)
        {
        }

        /// <summary>
        /// Changes the active variant.
        /// </summary>
        /// <param name="index" type = "int">The index of the variant (as listed in the variant possibilities array) to set as the active variant.</param>
        /// <displayName id = "SetVariant2">SetVariant(int)</displayName>
        /// <syntax>public void SetVariant(int index)</syntax>
        void SetVariant(int index)
        {
        }
    }
}