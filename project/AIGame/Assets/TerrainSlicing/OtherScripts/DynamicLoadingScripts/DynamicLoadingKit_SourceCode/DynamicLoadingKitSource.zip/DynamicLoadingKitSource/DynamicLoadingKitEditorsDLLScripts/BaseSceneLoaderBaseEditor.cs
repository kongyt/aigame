﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using UnityEditor;
    using UnityEngine;

    public class BaseSceneLoaderBaseEditor : BaseEditor
    {
        public BaseSceneLoaderBaseEditor(SerializedObject serializedObject) : base(serializedObject) { }

        protected override void DrawInspector()
        {
            EditorGUILayout.HelpBox("Note: This component makes use of scenes. If you have not created scenes yet, you can do so via the button below.", MessageType.Info);
            if(GUILayout.Button("Generate Scenes"))
                SceneGenerationTool.ShowWindow();
            
            EditorGUILayout.Space();

            helper.DrawSerializedPropertyTagField("unboundObjectTag", unboundObjectTagLabel);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Note: The Bound Object Tag is no longer used.");
            EditorGUILayout.Space();

            SerializedProperty areScenesFixedProperty = helper.GetPropertyByName("areScenesFixed");
            helper.DrawSerializedPropertyField(areScenesFixedProperty, areScenesFixedLabel);

            if(!areScenesFixedProperty.boolValue)
            {
                EditorGUILayout.Space();
                EditorGUILayout.LabelField(useLayerHidingLabel1);
                SerializedProperty useLayerHidingProperty = helper.GetPropertyByName("useLayerHiding");
                helper.DrawSerializedPropertyField(useLayerHidingProperty, useLayerHidingLabel2);

                if(useLayerHidingProperty.boolValue)
                {
                    helper.DrawSerializedPropertyLayerField("visibleLayer", visibleLayerLabel);

                    EditorGUILayout.HelpBox("Use of Layer Hiding is no longer recommended. Instead, simply use an empty game object as your root object (and mark it with the appropriate unbound object tag), parent your terrain or main mesh object to the root object (do NOT mark the terrain/mesh object with the unbound object tag, or assign it to the 'Hidden' Layer), deactivate this terrain/mesh object (so it becomes the deactivated node), and then parent all other objects to it.", MessageType.Info);
                }
            }            
        }

        GUIContent areScenesFixedLabel = new GUIContent("Are Scenes Fixed", "If enabled, the scene loader component will load your scenes at their default locations, and they will remain there until they are unloaded. The component will not search for a deactivate node to activate, or check/adjust the layers of any objects in the scenes.\n\nOnly enable this option if you know the scenes will not need to be moved. You can make your terrain/main mesh object the root object in the scene if this option is enabled.");

        GUIContent unboundObjectTagLabel = new GUIContent("Unbound Object Tag*", "The name of the tag you should have created in the Tag Manager to denote newly loaded objects that have not been bound to a cell.\n\nIt's important that the objects in your scenes use this tag, as it allows the program to find the newly loaded objects quickly and efficiently.");

        GUIContent useLayerHidingLabel1 = new GUIContent("Use Layer", "Have you set up your scenes to use layer hiding?\n\nLayer Hiding is no longer recommended.\n\n");

        GUIContent useLayerHidingLabel2 = new GUIContent("Hiding (Legacy)", "Have you set up your scenes to use layer hiding?\n\nLayer Hiding is no longer recommended.\n\n");

        GUIContent visibleLayerLabel = new GUIContent("Visible Layer*", "Once the root object of a newly loaded scene has been found, it is deactivated and moved to this layer.\n\nAny children not parented to a deactivated node (which should itself be parented to the root object) will also be set to this visible layer.\n\nIt will most likely be the Default Layer.");


    }
}
