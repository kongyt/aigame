//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;

	internal static class ArrayExtensions
	{
		//Finds the average of a set of values
		internal static float ComputeAverage(this float[] values)
		{
			if(values == null)
				return 0f;
		
			float totalLength = 0f;
			for(int i = 0; i < values.Length; i++)
				totalLength += values[i];
		
			return totalLength / values.Length;
		}
		
		//starting with an initial point, calculates a set of starting points based on a set of values
		internal static float[] ComputePositions(this float[] dimensions, float startingPosition, int valuesExpected)
		{
			float[] positions = null;
			
			if(dimensions != null)
			{
				positions = new float[valuesExpected];
				positions[0] = startingPosition;

                if (dimensions.Length == 1)
                {
                    for (int i = 1; i < positions.Length; i++)
                        positions[i] = positions[i - 1] + dimensions[0];
                }
                else
                {
                    for (int i = 1; i < positions.Length; i++)
                        positions[i] = positions[i - 1] + dimensions[i - 1];
                }
			}
			return positions;
		}
		
		//Sums up a set of values
        internal static float ComputeSum(this float[] values)
		{
			float sum = 0;
			for(int i = 0; i < values.Length; i++)
				sum += values[i];
				
			return sum;
		}

        internal static bool AreAllValuesTheSame(this float[] values)
        {
            float firstValue = values[0];
            for (int i = 1; i < values.Length; i++)
            { 
                if(!Mathf.Approximately(values[i], firstValue))
                    return false;
            }
            return true;
        }

        internal static bool DoAllValuesMatchInputVaue(this bool[] values, bool inputValue)
        {
            for(int i = 0; i < values.Length; i++)
            {
                if (values[i] != inputValue)
                    return false;
            }
            return true;
        }
	}

    internal static class FloatExtensions
    {
        internal static bool LessThanOrEqualToZero(this float value)
        {
            return value < 0f || Mathf.Approximately(value, 0f);
        }
    }

    internal static class CellExtensions
    {
        internal static Cell ConvertTo0Based(this Cell oneBasedCell, bool isWorld3D)
        {
            return new Cell(oneBasedCell.row - 1, oneBasedCell.column - 1, isWorld3D ? oneBasedCell.layer - 1 : 0);
        }

        internal static Cell ConvertTo1Based(this Cell zeroBasedCell, bool isWorld3D)
        {
            return new Cell(zeroBasedCell.row + 1, zeroBasedCell.column + 1, isWorld3D ? zeroBasedCell.layer + 1 : 1);
        }
    }

    internal static class NamingConventionExtensions
    {
        internal static INamingConvention GetCorrectNamingConvention(this INamingConvention inputNamingConvention, bool isWorld3D)
        {
            if (inputNamingConvention != null)
            {
                if (!inputNamingConvention.ValidateNamingConvention(isWorld3D)) 
                    return GetDefaultNamingConvention(isWorld3D);
                else
                    return inputNamingConvention;
            }
            else
                return GetDefaultNamingConvention(isWorld3D);
        }

        internal static bool ValidateNamingConvention(this INamingConvention namingConvention, bool isWorld3D)
        {
            if (!namingConvention.Format.Contains("%g"))
            {
                Debug.Log("The Naming Convention provided is not valid (it does not contain a '%g' string in the Format Field).");
                return false;
            }
            else if (!namingConvention.Format.Contains("%x"))
            {
                Debug.Log("The Naming Convention provided is not valid (it does not contain a '%x' string in the Format Field).");
                return false;
            }
            else if (!namingConvention.Format.Contains("%y"))
            {
                Debug.Log("The Naming Convention provided is not valid (it does not contain a '%y' string in the Format Field).");
                return false;
            }  
            else if (isWorld3D && !namingConvention.Format.Contains("%z"))
            {
                Debug.Log("The Naming Convention provided is not valid (it does not contain a '%z' string in the Format Field).");
                return false;
            }
            else
                return true;
        }

        static INamingConvention GetDefaultNamingConvention(bool use3DNamingConvention)
        {
            if (use3DNamingConvention)
                return new Default3DNamingConvention();
            else
                return new Default2DNamingConvention();
        }

        //Returns a string ready to be used in a string.Format method. %x is the first paramater, %y the second, and %z the third.
        internal static string GetStringFormatVersion(this INamingConvention namingConvention, bool use3DNamingConvention, string baseName)
        {
            string stringFormat = namingConvention.Format;
            stringFormat = stringFormat.Replace("%g", baseName);
            stringFormat = stringFormat.Replace("%x", "{0}");
            stringFormat = stringFormat.Replace("%y", "{1}");

            if (use3DNamingConvention)
                stringFormat = stringFormat.Replace("%z", "{2}");

            return stringFormat;
        }

        internal static string GetStringFormatVersion2DWithoutGroupName(this INamingConvention namingConvention)
        {
            string stringFormat = namingConvention.Format;
            
            stringFormat = stringFormat.Replace("%x", "{0}");
            stringFormat = stringFormat.Replace("%y", "{1}");
            stringFormat = stringFormat.Replace("%g", "{2}");
            return stringFormat;
        }
    }
}