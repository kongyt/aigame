﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using UnityEngine;
    using UnityEditor;

    [CustomEditor(typeof(SetNeighbors))]
    public class SetNeighborsEditor : Editor
    {
        SerializedProperty terrainsProp, rowsProp, columnsProp, showFoldoutProp, emptyLocationsProp, transformProp;

        void OnEnable()
        {
            serializedObject.Update();

            GameObject gO = (GameObject)serializedObject.FindProperty("gameObject").objectReferenceValue;
            Terrain baseTerrain = gO.GetComponent<Terrain>();
            if (baseTerrain == null)
            {
                EditorUtility.DisplayDialog("Error", "This script only works with terrains!", "OK");
                DestroyImmediate(target);
            }

            terrainsProp = serializedObject.FindProperty("terrains");
            rowsProp = serializedObject.FindProperty("rows");
            columnsProp = serializedObject.FindProperty("columns");
            showFoldoutProp = serializedObject.FindProperty("showFoldout");
            emptyLocationsProp = serializedObject.FindProperty("emptyLocations");
            transformProp = serializedObject.FindProperty("transform");

            if (terrainsProp.arraySize == 0)
            {
                terrainsProp.arraySize = rowsProp.intValue * columnsProp.intValue;
                terrainsProp.GetArrayElementAtIndex(0).objectReferenceValue = baseTerrain;
            }

            serializedObject.ApplyModifiedProperties();
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            EditorGUILayout.PropertyField(rowsProp, columnsLabel);
            EditorGUILayout.PropertyField(columnsProp, rowsLabel);

            showFoldoutProp.boolValue = EditorGUILayout.Foldout(showFoldoutProp.boolValue, autoFillLabel);

            if (showFoldoutProp.boolValue)
            {
                EditorGUILayout.PropertyField(emptyLocationsProp, emptyLocationsLabel);
                if (GUILayout.Button("Auto Fill Terrains"))
                    FillSelections(emptyLocationsProp.boolValue);

                if (rowsProp.intValue * columnsProp.intValue != terrainsProp.arraySize)
                    terrainsProp.arraySize = rowsProp.intValue * columnsProp.intValue;

                EditorGUILayout.PropertyField(terrainsProp, true);
            }

            serializedObject.ApplyModifiedProperties();
        }

        void FillSelections(bool emptyLocationsExist)
        {
            SelectionFiller selectionFiller = new SelectionFiller();
            Terrain[,] terrains;

            if (emptyLocationsExist)
                terrains = selectionFiller.FillSelections_EmptyVersion((Transform)transformProp.objectReferenceValue, rowsProp.intValue, columnsProp.intValue);
            else
                terrains = selectionFiller.FillSelections_NormalVersion((Transform)transformProp.objectReferenceValue, rowsProp.intValue, columnsProp.intValue);

            if (terrains != null)
            {
                var terrains1DArray = terrains.Convert2DArrayTo1DArray();
                terrainsProp.arraySize = terrains1DArray.Length;
                for (int i = 0; i < terrains1DArray.Length; i++)
                    terrainsProp.GetArrayElementAtIndex(i).objectReferenceValue = terrains1DArray[i];
            }
            else
                EditorUtility.DisplayDialog("Error", "No terrains were found.", "OK");
        }

        GUIContent autoFillLabel = new GUIContent("Terrains in Group", "Fill the fields below with all the " +
            "terrains in your terrain group, starting with the first terrain, and preceding in order from left to right, " +
            "then bottom to top.\n\nPress the 'Auto Fill From Scene' button to have the script try and automatically " +
            "fill these fields in for you.");

        GUIContent columnsLabel = new GUIContent("Columns", "This value represents the number of terrains " +
            "that exist in a single row (along x axis) of your terrain group.");

        GUIContent emptyLocationsLabel = new GUIContent("Empty Locations Exist", "Are there any empty " +
            "locations in your terrain group?\n\nExample: you have 2 rows and 2 columns, but terrain_1_2 does not " +
            "exist. If there are empty locations, in order to use this tool you will need to make sure all of your " +
            "terrains share a common base name and follow the naming convention 'name_row_column'. \n\nAlso be " +
            "aware that you cannot tile the inner edges of your terrain group if you have any empty locations.\n\n" +
            "You can still tile the outer edges (to make the world repeatable), but only if there are no empty locations " +
            "on the outer edge of your terrain group.");

        GUIContent rowsLabel = new GUIContent("Rows", "This value represents the number of terrains " +
            "that exist in a single column (along z axis) of your terrain group.");
    }
}