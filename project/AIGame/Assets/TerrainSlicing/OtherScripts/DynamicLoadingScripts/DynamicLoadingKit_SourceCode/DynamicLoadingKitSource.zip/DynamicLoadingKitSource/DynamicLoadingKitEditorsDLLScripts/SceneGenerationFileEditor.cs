﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using System.IO;
    using UnityEditor;
    using UnityEngine;
    using DynamicLoadingKit;
    using System.Collections.Generic;
#if !UNITY_4
    using UnityEditor.SceneManagement;
#endif

    [CustomEditor(typeof(SceneGenerationFile))]
    public class SceneGenerationFileEditor : Editor
    {
        SceneGenerationFileBaseEditor baseEditor;

        public override void OnInspectorGUI()
        {
            if (baseEditor == null)
                baseEditor = new SceneGenerationFileBaseEditor(serializedObject);

            baseEditor.OnInspectorGUI();
        }

        [MenuItem("Assets/Dynamic Loading Kit/Create Scene Generation File")]
        public static void CreateSceneGenerationFile()
        {
            ScriptableObjectAssetCreator.GenerateScriptableObjectAssetAtSelectedFolder<SceneGenerationFile>("SceneGenerationFile");
        }
    }

    internal class SceneGenerationFileBaseEditor : BaseEditor
    {
        public SceneGenerationFileBaseEditor(SerializedObject serializedObject) : base(serializedObject) { }

        protected sealed override void DrawInspector()
        {
            GUILayout.Label("Configuration", EditorStyles.boldLabel);
            DrawInstructionalInformation();
            EditorGUILayout.Space();

            DrawToolOptions();
            EditorGUILayout.Space();

            if (GUILayout.Button("Generate Scenes"))
            {
                if (!TryToGenerateScenes())
                    Debug.Log("Error Generating Scenes");
            }
        }

        void DrawInstructionalInformation()
        {
            EditorGUILayout.LabelField("Hover over the field labels (left of each field) or buttons to view more detailed information about each field.");
            EditorGUILayout.Space();
        }

        void DrawToolOptions()
        {
            DrawNameOptions();
            EditorGUILayout.Space();

            DrawMiscellaneousOptions();
            EditorGUILayout.Space();

            DrawRangeOptions();
            EditorGUILayout.Space();

#if !UNITY_4
            DrawAssetBundleOptions();
#endif
        }

        void DrawNameOptions()
        {
            if (!helper.DrawSerializedPropertyFoldoutField("showNameSettings", "Name Settings", boldFoldout))
                return;

            helper.DrawSerializedPropertyField("sharedNameInput", sharedNameInputLabel);

            DrawNamingConventionOption(helper.GetPropertyByName("inputNamingConvention"), "Input Naming Convention");

            helper.DrawSerializedPropertyField("sharedNameOutput", sharedNameOutputLabel);

            DrawNamingConventionOption(helper.GetPropertyByName("outputNamingConvention"), "Output Naming Convention");

            EditorGUILayout.HelpBox("Note, the 'Numbering Starts At 0' option on the Input and Output Naming Convention asset is not used by this tool. The row/column/layer number is controlled entirely by the First/Last Row/Column/Layer values.", MessageType.Info);
        }

        void DrawNamingConventionOption(SerializedProperty namingConventionProperty, string label)
        {
            NamingConvention namingConventionTemp = (NamingConvention)EditorGUILayout.ObjectField(label, namingConventionProperty.objectReferenceValue, typeof(NamingConvention), false);

            if (namingConventionTemp != namingConventionProperty.objectReferenceValue as NamingConvention)
            {
                if (namingConventionTemp != null && namingConventionTemp.ValidateNamingConvention(helper.GetPropertyByName("groupIs3D").boolValue))
                    namingConventionProperty.objectReferenceValue = namingConventionTemp;
                else
                    namingConventionProperty.objectReferenceValue = null;
            }
        }

        void DrawMiscellaneousOptions()
        {
            if (!helper.DrawSerializedPropertyFoldoutField("showMiscOptions", "Miscellaneous Settings", boldFoldout))
                return;

            DrawIsGroup3DOption();
            helper.DrawSerializedPropertyTagField("unboundTagName", unboundTagNameLabel);
            helper.DrawSerializedPropertyField("areScenesFixed", areScenesFixedLabel);
            DrawSaveAndLoadOptions();
        }

        void DrawIsGroup3DOption()
        {
            bool groupIs3DChanged;
            helper.DrawSerializedPropertyField("groupIs3D", "Group is 3D", out groupIs3DChanged);

            if (groupIs3DChanged)
            {
                SerializedProperty inputNamingConventionProperty = helper.GetPropertyByName("inputNamingConvention");

                if (inputNamingConventionProperty.objectReferenceValue != null && !((INamingConvention)inputNamingConventionProperty.objectReferenceValue).ValidateNamingConvention(helper.GetPropertyByName("groupIs3D").boolValue))
                    inputNamingConventionProperty.objectReferenceValue = null;

                SerializedProperty outputNamingConventionProperty = helper.GetPropertyByName("outputNamingConvention");

                if (outputNamingConventionProperty.objectReferenceValue != null && !((INamingConvention)outputNamingConventionProperty.objectReferenceValue).ValidateNamingConvention(helper.GetPropertyByName("groupIs3D").boolValue))
                    outputNamingConventionProperty.objectReferenceValue = null;
            }
        }

        void DrawSaveAndLoadOptions()
        {
            helper.DrawSerializedPropertyField("loadPath", prefabLoadPathLabel);
            helper.DrawSerializedPropertyField("savePath", saveScenesLabel);
        }

        void DrawRangeOptions()
        {
            if (!helper.DrawSerializedPropertyFoldoutField("showRangeSettings", "Range To Generate Settings", boldFoldout))
                return;

            if (helper.GetPropertyByName("groupIs3D").boolValue)
            {
                DrawRowOrColumnRangefield("First Layer", "Last Layer", helper.GetPropertyByName("firstLayer"), helper.GetPropertyByName("lastLayer"));
            }

            DrawRowOrColumnRangefield("First Row", "Last Row", helper.GetPropertyByName("firstRow"), helper.GetPropertyByName("lastRow"));

            DrawRowOrColumnRangefield("First Column", "Last Column", helper.GetPropertyByName("firstColumn"), helper.GetPropertyByName("lastColumn"));
        }

        void DrawRowOrColumnRangefield(string rangeBeginLabel, string rangeEndLabel, SerializedProperty rangeBeginValue, SerializedProperty rangeEndValue)
        {
            EditorGUILayout.BeginHorizontal();
            int rangeBeginNewValue = EditorGUILayout.IntField(rangeBeginLabel, rangeBeginValue.intValue);

            if (rangeBeginNewValue != rangeBeginValue.intValue)
            {
                if (rangeBeginNewValue < 0)
                    rangeBeginNewValue = 0;

                rangeBeginValue.intValue = rangeBeginNewValue;
                if (rangeEndValue.intValue < rangeBeginValue.intValue)
                    rangeEndValue.intValue = rangeBeginValue.intValue;
            }

            int rangeEndNewValue = EditorGUILayout.IntField(rangeEndLabel, rangeEndValue.intValue);
            if (rangeEndNewValue != rangeEndValue.intValue)
            {
                if (rangeEndNewValue < rangeBeginValue.intValue)
                    rangeEndNewValue = rangeBeginValue.intValue;

                rangeEndValue.intValue = rangeEndNewValue;
            }

            EditorGUILayout.EndHorizontal();
        }


#if !UNITY_4
        void DrawAssetBundleOptions()
        {
            if (!helper.DrawSerializedPropertyFoldoutField("showAssetBundleOptions", "Asset Bundle Settings", boldFoldout))
                return;

            EditorGUILayout.LabelField(assignToAssetBundlesLabel1);
            helper.DrawSerializedPropertyField("assignScenesToAssetBundles", assignToAssetBundlesLabel2);
            EditorGUILayout.Space();

            if (helper.GetPropertyByName("assignScenesToAssetBundles").boolValue)
            {
                EditorGUILayout.LabelField("Add Scenes To");
                helper.DrawSerializedPropertyField("addScenesToBuildSettings", "Build Settings");
                EditorGUILayout.Space();

                if (helper.GetPropertyByName("addScenesToBuildSettings").boolValue)
                {
                    if (helper.DrawSerializedPropertyFoldoutField("showBuildSettingsWarning", "Warning about adding Scenes to Build Settings while using Asset Bundles", boldFoldout))
                    {
                        EditorGUILayout.HelpBox("Normally you would not want to add scenes that you are utilizing in Asset Bundles to the Build Settings, as the whole point of using Asset Bundles is to reduce build size, and adding the scenes to the Build Settings would counter that.\n\nStill, if for some reason you want to add the scenes to the build settings even when assigning asset bundles, you can check this option.\n\nAlso note that if not assigning scenes to asset bundles, the scenes will always be added to the build settings.", MessageType.Warning);
                    }
                }

                helper.DrawSerializedPropertyField("useVariants", useAssetBundleVariants);

                if (helper.GetPropertyByName("useVariants").boolValue)
                    helper.DrawSerializedPropertyField("variantName", "Variant Name");
            }
        }
#endif


        bool TryToGenerateScenes()
        {
            helper.SerializedObject.ApplyModifiedProperties();
            SceneGenerationFile targetScript = (SceneGenerationFile)helper.SerializedObject.targetObject;
            if (targetScript.unboundTagName == "Untagged")
            {
                EditorUtility.DisplayDialog("Tag Not Set", "You must specify a tag to use as the umbound tag in order to proceed.", "Ok");
                return false;
            }

            if (!TryToValidateSaveAndLoadPaths(targetScript))
                return false;

            string pathToLoadPrefabsFrom = targetScript.loadPath.ConvertRelativePathToAbsolutePath(true);
            string pathToSaveScenesTo = targetScript.savePath.ConvertRelativePathToAbsolutePath(true);

            SceneGenerator sceneGenerator = new SceneGenerator(targetScript, pathToLoadPrefabsFrom, pathToSaveScenesTo);
            sceneGenerator.GenerateScenes();
            return true;
        }

        bool TryToValidateSaveAndLoadPaths(SceneGenerationFile targetScript)
        {
            string loadPathThatMightNotExist = Application.dataPath + targetScript.loadPath;
            if (!loadPathThatMightNotExist.DoesPathExist())
            {
                EditorUtility.DisplayDialog("Incorrect File Path", "Cannot locate prefabs. Assets" + loadPathThatMightNotExist + " does not exist.", "Ok");
                return false;
            }

            string savePathThatMightNotExist = Application.dataPath + targetScript.savePath;
            if (!savePathThatMightNotExist.DoesPathExist())
                Directory.CreateDirectory(savePathThatMightNotExist);

            return true;
        }



        #region Labels

        GUIContent areScenesFixedLabel = new GUIContent("Are Scenes Fixed*", "If enabled, the scene generation tool will not modify your prefabs in any way when building your scenes (other than setting the root object's tag to the unbound object tag).\n\nThis should only be enabled if you know your scenes are fixed/static, i.e., if you know that your root objects will not need to be moved from their default positions.\n\nIf disabled, the Scene Generation Tool will create a new empty game object with the same name as your existing prefab to serve as the root object in each scene. This new root object will have it's tag set to the unbound object tag, and your terrain/mesh/main root object (on your prefab) will be sceneGenerationFileed to this new root object and deactivated.\n\nThis will ensure that your terrain/main mesh will not be enabled initially, and can be moved to it's correct position without incurring a performance penalty. It will then be activated once it has been positioned correctly.");

        static string assignToAssetBundlesLabelText = "If checked, the generated scenes will automatically be assigned to Asset Bundles. The asset bundle names will follow the output naming convention (or default naming convention if no convention is specified), with one caveat. If the first character of the asset bundle name is alphabetical, it will be changed to an equivalent lowercase value.\n\nNote that Asset Bundles will need to be built manually. This tool only assigns the scenes to the correct bundles, it does not generate Asset Bundles!";

        GUIContent assignToAssetBundlesLabel1 = new GUIContent("Assign Scenes To", assignToAssetBundlesLabelText);

        GUIContent assignToAssetBundlesLabel2 = new GUIContent("Asset Bundles*", assignToAssetBundlesLabelText);

        GUIContent prefabLoadPathLabel = new GUIContent("Prefab Load Path*", "This is the location where the " +
            "prefabs are stored, in relation to the Assets folder.\n\nExample: to get prefabs from Assets/Resources type /Resources");

        GUIContent saveScenesLabel = new GUIContent("Save Scenes Path*", "This is the location you wish to save the scenes in, in relation to the Assets folder. If this directory doesn't exist, it will be created.\n\n Example : To save in Assets/Scenes folder type /Scenes");

        GUIContent sharedNameInputLabel = new GUIContent("Input Group Name*", "The common shared name of the input prefabs that will be used to build the scenes, i.e., " +
            "'Terrain' if your prefabs are called 'Terrain_1_1', 'Terrain_1_2', etc.");

        GUIContent sharedNameOutputLabel = new GUIContent("Output Group Name*", "This will be the common name given to all of the generated scenes (as well as the main object in each scene), e.g. if you want your scenes and objects to be called 'Terrain_1_1', 'Terrain_1_2', etc., enter 'Terrain'.");

        GUIContent unboundTagNameLabel = new GUIContent("Unbound Object Tag*", "When the root object in the scene is loaded, it must be found by the program so that it can be bound to a cell. In order to efficiently find newly loaded root objects, we'll assign each root object in our scene a specific tag, which you can choose here. Make sure your Scene Loader component also uses this same tag.");

        GUIContent useAssetBundleVariants = new GUIContent("Use Variants*", "If checked, each scenes variant Asset Bundle setting will be set to whatever you specify in the 'Variant Name' field.\n\nYou'll usually leave this option disabled. More information can be found @ https://unity3d.com/learn/tutorials/topics/scripting/assetbundles-and-assetbundle-manager");
        #endregion

        class SceneGenerator
        {
            SceneGenerationFile sceneGenerationFile;
            float sceneGenerationProgress = 0f;
            string pathToLoadPrefabsFrom, pathToSaveScenesTo, pathOfInitialScene, formatStringInput, formatStringOutput, pathOfTempScene;

            string InitialScene { get { return pathOfInitialScene; } }

            public SceneGenerator(SceneGenerationFile sceneGenerationFile, string pathToLoadPrefabsFrom, string pathToSaveScenesTo)
            {
                this.sceneGenerationFile = sceneGenerationFile;
                this.pathToLoadPrefabsFrom = pathToLoadPrefabsFrom;
                this.pathToSaveScenesTo = pathToSaveScenesTo;

                INamingConvention namingConventionToUseForInput = sceneGenerationFile.inputNamingConvention.GetCorrectNamingConvention(sceneGenerationFile.groupIs3D);
                formatStringInput = namingConventionToUseForInput.GetStringFormatVersion(sceneGenerationFile.groupIs3D, sceneGenerationFile.sharedNameInput);

                INamingConvention namingConventionToUseForOutput = sceneGenerationFile.outputNamingConvention.GetCorrectNamingConvention(sceneGenerationFile.groupIs3D);
                formatStringOutput = namingConventionToUseForOutput.GetStringFormatVersion(sceneGenerationFile.groupIs3D, sceneGenerationFile.sharedNameOutput);
            }

            public void GenerateScenes()
            {
                DisplayProgressBar("Generating Scenes");
                if (!SaveInitialScene())
                {
                    ClearProgressBar();
                    return;
                }

                CreateBackupScene();

                if (sceneGenerationFile.groupIs3D)
                    GenerateSceneFor3DWorld();
                else
                    GenerateSceneFor2DWorld();

#if UNITY_4
                EditorApplication.OpenScene(InitialScene);
                AssetDatabase.DeleteAsset(pathOfTempScene);

                EditorUtility.UnloadUnusedAssets();
                System.GC.Collect();
                EditorApplication.SaveScene(InitialScene);
#else
                //EditorSceneManager.OpenScene(InitialScene);
                //AssetDatabase.DeleteAsset(pathOfTempScene);

                EditorUtility.UnloadUnusedAssetsImmediate();
                System.GC.Collect();
                //EditorSceneManager.SaveOpenScenes();
#endif
#if UNITY_4 || UNITY_5_3_5
                EditorApplication.SaveAssets();
#else
                AssetDatabase.SaveAssets();
#endif
                EditorUtility.ClearProgressBar();
            }

#if UNITY_4
            
            bool SaveInitialScene()
            {
                pathOfInitialScene = EditorApplication.currentScene;
                return EditorApplication.SaveScene(pathOfInitialScene);
            }

            void CreateBackupScene()
            {
                pathOfTempScene = pathToSaveScenesTo + "tempScene.unity";
                pathOfTempScene = AssetDatabase.GenerateUniqueAssetPath(pathOfTempScene);
                EditorApplication.NewScene();
                GameObject.DestroyImmediate(Camera.main.gameObject);
                GameObject[] gos = GameObject.FindGameObjectsWithTag("Untagged");
                for(int i = gos.Length - 1; i >= 0; i--)
                    GameObject.DestroyImmediate(gos[i]);
                EditorApplication.SaveScene(pathOfTempScene);
            }
#else
            bool SaveInitialScene()
            {
                if (!EditorSceneManager.SaveOpenScenes())
                    return false;

                //pathOfInitialScene = EditorSceneManager.GetActiveScene().path;
                //EditorSceneManager.OpenScene(InitialScene);
                return true;
            }

            void CreateBackupScene()
            {
                //pathOfTempScene = pathToSaveScenesTo + "tempScene.unity";
                //pathOfTempScene = AssetDatabase.GenerateUniqueAssetPath(pathOfTempScene);

                //UnityEngine.SceneManagement.Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                //EditorSceneManager.SetActiveScene(scene);
                //EditorSceneManager.SaveScene(scene, pathOfTempScene);
            }
#endif


            void DisplayProgressBar(string subText)
            {
                EditorUtility.DisplayProgressBar("Generating Scenes", subText, sceneGenerationProgress);
            }

            void ClearProgressBar()
            {
                EditorUtility.ClearProgressBar();
            }


            void GenerateSceneFor3DWorld()
            {
                int rows = sceneGenerationFile.lastRow - sceneGenerationFile.firstRow + 1;
                int columns = sceneGenerationFile.lastColumn - sceneGenerationFile.firstColumn + 1;
                int layers = sceneGenerationFile.lastLayer - sceneGenerationFile.firstLayer + 1;
                float progressIncremenet = 1f / (columns * rows * layers);

                for (int layer = sceneGenerationFile.firstLayer; layer <= sceneGenerationFile.lastLayer; layer++)
                {
                    for (int row = sceneGenerationFile.firstRow; row <= sceneGenerationFile.lastRow; row++)
                    {
                        for (int column = sceneGenerationFile.firstColumn; column <= sceneGenerationFile.lastColumn; column++)
                        {
                            string inputPrefabName = string.Format(formatStringInput, column, row, layer);
                            string outputName = string.Format(formatStringOutput, column, row, layer);
                            GenerateScene(inputPrefabName, outputName);

                            sceneGenerationProgress += progressIncremenet;
                            DisplayProgressBar(string.Format("Generating scene {0}", outputName));
                        }
                    }
                }
            }

            void GenerateSceneFor2DWorld()
            {
                int rows = sceneGenerationFile.lastRow - sceneGenerationFile.firstRow + 1;
                int columns = sceneGenerationFile.lastColumn - sceneGenerationFile.firstColumn + 1;
                float progressIncremenet = 1f / (columns * rows);

                for (int row = sceneGenerationFile.firstRow; row <= sceneGenerationFile.lastRow; row++)
                {
                    for (int column = sceneGenerationFile.firstColumn; column <= sceneGenerationFile.lastColumn; column++)
                    {
                        string inputPrefabName = string.Format(formatStringInput, column, row);
                        string outputName = string.Format(formatStringOutput, column, row);
                        GenerateScene(inputPrefabName, outputName);

                        sceneGenerationProgress += progressIncremenet;
                        DisplayProgressBar(outputName);
                    }
                }
            }

            void GenerateScene(string inputPrefabName, string outputName)
            {
                string pathOfPrefabToLoad = pathToLoadPrefabsFrom + inputPrefabName + ".prefab";
#if UNITY_4
                GameObject prefab = Resources.LoadAssetAtPath(pathOfPrefabToLoad, typeof(GameObject)) as GameObject;
#else
                GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(pathOfPrefabToLoad);
#endif
                if (prefab != null)
                {
                    CreateAndSaveSceneForPrefab(prefab, outputName);
                    pathOfPrefabToLoad = null;
                    prefab = null;

#if UNITY_4
                    EditorUtility.UnloadUnusedAssets();
#else
                    EditorUtility.UnloadUnusedAssetsImmediate();
#endif

                    System.GC.Collect();

#if UNITY_4
                    EditorApplication.OpenScene(pathOfTempScene);
                    EditorApplication.SaveScene(pathOfTempScene);
#else
                    //EditorSceneManager.OpenScene(pathOfTempScene);
                    //EditorSceneManager.SaveOpenScenes();

#endif
#if UNITY_4 || UNITY_5_3_5
                    EditorApplication.SaveAssets();
#else
                    AssetDatabase.SaveAssets();
#endif
                }
            }

            void CreateAndSaveSceneForPrefab(GameObject prefab, string outputName)
            {
                GameObject instantiatedPrefab = (GameObject)GameObject.Instantiate(prefab);
                SetupPrefab(instantiatedPrefab, outputName);

                string pathOfSceneToAdd = pathToSaveScenesTo + outputName + ".unity";

#if UNITY_4
                EditorApplication.SaveScene(pathOfSceneToAdd);
#else
                UnityEngine.SceneManagement.Scene newScene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
                EditorSceneManager.MoveGameObjectToScene(instantiatedPrefab, newScene);
                EditorSceneManager.SaveScene(newScene, pathOfSceneToAdd);
                EditorSceneManager.CloseScene(newScene, true);
#endif

                bool addSceneToBuildSettings = true;

#if !UNITY_4
                if (sceneGenerationFile.assignScenesToAssetBundles)
                {
                    addSceneToBuildSettings = sceneGenerationFile.addScenesToBuildSettings;

                    AssetImporter assetImporter = AssetImporter.GetAtPath(pathOfSceneToAdd);

                    string variantName = "";//None
                    if (sceneGenerationFile.useVariants)
                        variantName = sceneGenerationFile.variantName;

                    assetImporter.SetAssetBundleNameAndVariant(outputName, variantName);
                }
#endif
                if (addSceneToBuildSettings)
                    AddSceneToBuildSettings(pathOfSceneToAdd);

                pathOfSceneToAdd = null;
                instantiatedPrefab = null;
            }

            void AddSceneToBuildSettings(string pathOfSceneToAdd)
            {
                //Loop through and see if the scene already exist in the build settings
                int indexOfSceneIfExist = -1;

                for (int i = 0; i < EditorBuildSettings.scenes.Length; i++)
                {
                    if (EditorBuildSettings.scenes[i].path == pathOfSceneToAdd)
                    {
                        indexOfSceneIfExist = i;
                        break;
                    }
                }

                EditorBuildSettingsScene[] newScenes;

                if (indexOfSceneIfExist == -1)
                {
                    newScenes = new EditorBuildSettingsScene[EditorBuildSettings.scenes.Length + 1];

                    //Seems inefficent to add scene to build settings after creating each scene (rather than doing it all at once
                    //after they are all created, however, it's necessary to avoid memory issues.
                    int i = 0;
                    for (; i < EditorBuildSettings.scenes.Length; i++)
                        newScenes[i] = EditorBuildSettings.scenes[i];

                    newScenes[i] = new EditorBuildSettingsScene(pathOfSceneToAdd, true);
                }
                else
                {
                    newScenes = new EditorBuildSettingsScene[EditorBuildSettings.scenes.Length];

                    int i = 0, j = 0;
                    for (; i < EditorBuildSettings.scenes.Length; i++)
                    {
                        //skip over the scene that is a duplicate
                        //this will effectively delete it from the build settings
                        if (i != indexOfSceneIfExist)
                            newScenes[j++] = EditorBuildSettings.scenes[i];
                    }
                    newScenes[j] = new EditorBuildSettingsScene(pathOfSceneToAdd, true);
                }

                EditorBuildSettings.scenes = newScenes;

                newScenes = null;
            }

            void SetupPrefab(GameObject instantiatedPrefab, string outputName)
            {
                instantiatedPrefab.name = outputName;
                Transform instantiatedPrefabTransform = instantiatedPrefab.transform;

                if (!sceneGenerationFile.areScenesFixed)
                {
                    GameObject newRootObject = new GameObject(outputName);
                    newRootObject.transform.position = instantiatedPrefabTransform.position;

                    newRootObject.tag = sceneGenerationFile.unboundTagName;

                    instantiatedPrefabTransform.parent = newRootObject.transform;
                    instantiatedPrefabTransform.localPosition = new Vector3(0f, 0f, 0f);
                    instantiatedPrefab.SetActive(false);
                }
                else
                {
                    instantiatedPrefab.tag = sceneGenerationFile.unboundTagName;
                    instantiatedPrefab.SetActive(true);
                }
            }
        }
    }
}