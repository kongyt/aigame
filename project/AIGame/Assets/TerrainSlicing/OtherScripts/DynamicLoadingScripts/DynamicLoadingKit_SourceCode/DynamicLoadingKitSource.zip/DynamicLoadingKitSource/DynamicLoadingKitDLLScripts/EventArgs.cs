﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System;

    /// <summary>
    /// Event Args for CellPlyerIsInChanged event (an event of the Active Grid class).
    /// </summary>
    /// <title>CellPlayerIsInChangedEventArgs Class</title>
    /// <category>Other Classes</category>
    /// <navigationName>CellPlayerIsInChangedEventArgs</navigationName>
    /// <fileName>CellPlayerIsInChangedEventArgs.html</fileName>
    /// <syntax>public class CellPlayerIsInChangedEventArgs : EventArgs</syntax>
    public class CellPlayerIsInChangedEventArgs : EventArgs
    {
        internal WorldCell worldCellPlayerIsIn;
        internal string reasonForNullWorldCell;
        /// <summary>
        /// Gets the World Cell the player is currently in, if one exists. A World Cell exists only 
        /// when the World has objects loaded for that cell.
        /// </summary>
        /// <type link="WorldCell.html">WorldCell</type>
        public WorldCell WorldCellPlayerIsIn { get { return worldCellPlayerIsIn; } }

        /// <summary>
        /// Gets the cell the player is in as projected on an endless grid of cells.
        /// </summary>
        /// <type link="Cell.html">Cell</type>
        public Cell EndlessGridCellPlayerIsIn { get; internal set; }

        /// <summary>
        /// Gets the cell the player is in as it lies on the world grid associated with the World.
        /// </summary>
        /// <type link="Cell.html">Cell</type>
        public Cell WorldGridCellPlayerIsIn { get; internal set; }

        /// <summary>
        /// When WorldCellPlayerIsIn is null, this property can be used to get the reason for why it is null, 
        /// which can be useful for debugging purposes.
        /// </summary>
        /// <type>string</type>
        public string ReasonForNullWorldCell { get { return reasonForNullWorldCell; } }

        internal CellPlayerIsInChangedEventArgs() { }
    }

    /// <summary>
    /// Event Args for a PlayerMovedByGrid event (an event of the Active Grid class).
    /// </summary>
    /// <title>PlayerMovedByGridEventArgs Class</title>
    /// <category>Other Classes</category>
    /// <navigationName>PlayerMovedByGridEventArgs</navigationName>
    /// <fileName>PlayerMovedByGridEventArgs.html</fileName>
    /// <syntax>public class PlayerMovedByGridEventArgs : EventArgs</syntax>
    public class PlayerMovedByGridEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the Transform of the player that was moved by the Active Grid.
        /// </summary>
        /// <type>Transform</type>
        public Transform Player { get; internal set; }

        internal PlayerMovedByGridEventArgs() { }

        /// <summary>
        /// Initializes a new instance of the PlayerMovedByGridEventArgs class with the passed in player Transform.
        /// </summary>
        /// <param name="player" type="Transform">The player that was moved.</param>
        /// <displayName id="PlayerMovedByGridEventArgs">PlayerMovedByGridEventArgs(Transform)</displayName>
        /// <syntax>public PlayerMovedByGridEventArgs(Transform player)</syntax>
        public PlayerMovedByGridEventArgs(Transform player)
        {
            Player = player;
        }
    }

    /// <summary>
    /// Event Args for a WorldSyncedToChanged event (an event of the Active Grid class).
    /// </summary>
    /// <title>WorldSyncedToChangedEventArgs Class</title>
    /// <category>Other Classes</category>
    /// <navigationName>WorldSyncedToChangedEventArgs</navigationName>
    /// <fileName>WorldSyncedToChangedEventArgs.html</fileName>
    /// <syntax>public class WorldSyncedToChangedEventArgs : EventArgs</syntax>
    public class WorldSyncedToChangedEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the old World tha the Active Grid was synced to.
        /// </summary>
        /// <type link="World.html">World</type>
        public World OldWorld { get; internal set; }

        /// <summary>
        /// Gets the new World that the Active Grid is now synced to.
        /// </summary>
        /// <type link="World.html">World</type>
        public World NewWorld { get; internal set; }

        internal WorldSyncedToChangedEventArgs() { }

        /// <summary>
        /// Initializes a new instance of the WorldSyncedToChangedEventArgs class using and old and new World.
        /// </summary>
        /// <param name="oldWorld" type="World" link="World.html">The old world the Active Grid was synced to before the change.</param>
        /// <param name="newWorld" type="World" link="World.html">The new world the Active Grid is synced to after the change.</param>
        /// <displayName id="WorldSyncedToChangedEventArgs">WorldSyncedToChangedEventArgs(World, World)</displayName>
        /// <syntax>public WorldSyncedToChangedEventArgs(World oldWorld, World newWorld)</syntax>
        public WorldSyncedToChangedEventArgs(World oldWorld, World newWorld)
        {
            OldWorld = oldWorld;
            NewWorld = newWorld;
        }
    }
}