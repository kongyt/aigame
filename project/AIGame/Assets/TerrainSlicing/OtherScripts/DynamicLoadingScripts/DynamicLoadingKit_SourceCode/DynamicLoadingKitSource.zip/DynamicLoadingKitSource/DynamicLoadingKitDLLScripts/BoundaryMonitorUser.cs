//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;
	using System.Collections.Generic;
	using DynamicLoadingKit;
	using System;

	internal class BoundaryMonitorUser : MonoBehaviour
    {
        internal bool monitoringInProgress, monitorDynamicBoundary, monitoringPaused, monitorStaticBoundary, stopMonitoring;
        internal Boundary dynamicBoundary, staticBoundary;
        internal Action<BoundaryMonitorUser> UpdateAction;

        internal Action<BoundaryCrossed, BoundaryCrossed, BoundaryCrossed> MethodToCallWhenDynamicBoundaryCrossed;
        internal Action<Transform> MethodToCallWhenStaticBoundaryCrossed;

        internal float timeOutStart;

        internal Transform transformToMonitor;
            
        void Update()
        {
            UpdateAction(this);
        }

        //public IEnumerator<YieldInstruction> MonitorBoundaries(YieldInstruction yieldInstruction)
        //{
        //    stopMonitoring = false;
        //    monitoringInProgress = true;
        //    yield return null;

        //    while (!stopMonitoring)
        //    {
        //        if(!monitoringPaused)
        //        {
        //            if (monitorDynamicBoundary)
        //            {
        //                BoundaryCrossed eastOrWestBoundaryCrossed, northOrSouthBoundaryCrossed, topOrBottomBoundaryCrossed;
        //                dynamicBoundary.WereBoundariesCrossed(transformToMonitor.position, out eastOrWestBoundaryCrossed, out northOrSouthBoundaryCrossed, out topOrBottomBoundaryCrossed);
        //                if (eastOrWestBoundaryCrossed != BoundaryCrossed.None)
        //                {
        //                    MethodToCallWhenDynamicBoundaryCrossed(eastOrWestBoundaryCrossed);
        //                    yield return null;
        //                }

        //                if (northOrSouthBoundaryCrossed != BoundaryCrossed.None)
        //                {
        //                    MethodToCallWhenDynamicBoundaryCrossed(northOrSouthBoundaryCrossed);
        //                    yield return null;
        //                }

        //                if (topOrBottomBoundaryCrossed != BoundaryCrossed.None)
        //                {
        //                    MethodToCallWhenDynamicBoundaryCrossed(topOrBottomBoundaryCrossed);
        //                    yield return null;
        //                }

        //                if (stopMonitoring)
        //                    break;
        //            }

        //            if (monitorStaticBoundary && !monitoringPaused)
        //            {
        //                BoundaryCrossed eastOrWestBoundaryCrossed, northOrSouthBoundaryCrossed, topOrBottomBoundaryCrossed;
        //                staticBoundary.WereBoundariesCrossed(transformToMonitor.position, out eastOrWestBoundaryCrossed, out northOrSouthBoundaryCrossed, out topOrBottomBoundaryCrossed);

        //                if (eastOrWestBoundaryCrossed != BoundaryCrossed.None || northOrSouthBoundaryCrossed != BoundaryCrossed.None || topOrBottomBoundaryCrossed != BoundaryCrossed.None)
        //                    MethodToCallWhenStaticBoundaryCrossed(eastOrWestBoundaryCrossed, northOrSouthBoundaryCrossed, topOrBottomBoundaryCrossed);
        //            }
        //        }
                    
        //        yield return yieldInstruction;//wait a little before checking position again
        //    }
        //    monitoringInProgress = false;
        //}
        
        public void NullOut()
        {
            dynamicBoundary = staticBoundary = null;
            MethodToCallWhenDynamicBoundaryCrossed = null;
            MethodToCallWhenStaticBoundaryCrossed = null;
            transformToMonitor = null;
            UpdateAction = null;
        }
    }
}