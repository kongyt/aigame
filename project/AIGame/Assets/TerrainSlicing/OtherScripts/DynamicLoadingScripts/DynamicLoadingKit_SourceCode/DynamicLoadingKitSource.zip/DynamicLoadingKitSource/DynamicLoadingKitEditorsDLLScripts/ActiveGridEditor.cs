﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using UnityEditor;
    using UnityEngine;

    internal class ActiveGridBaseEditor : BaseEditor
    {
        enum LayerOfSection { Bottom, Top };
        enum RowOfSection { South, North };
        enum ColumnOfSection { West, East };

        public ActiveGridBaseEditor(SerializedObject serializedObject) : base(serializedObject) { }

        protected sealed override void DrawInspector()
        {
            helper.DrawSerializedPropertyField("activeGridID", activeGridIDLabel);

            DrawPlayerOption();
            DrawBoundaryMonitorOption();
            DrawPlayerMoverOption();
            
            DrawWorldOptions();
            
            DrawActiveGridTypeOption();
            EditorGUILayout.Space();

            if (helper.GetPropertyByName("activeGridType").intValue == (int)ActiveGridType.Outer_Ring_Grid)
                DrawGridDimensionsOptions();
            else
                DrawSectionOptions();

            DrawPrimaryCellIndexOptions();
            DrawEnableCellUsersOptions();
            DrawMonitorInnerAreaBoundariesOptions();    
            DrawAllowWorldShiftOptions();
        }

        void DrawBoundaryMonitorOption()
        {
            helper.DrawSerializedPropertyField("boundaryMonitor", boundaryMonitorLabel);
            if (helper.GetPropertyByName("player").objectReferenceValue != null && helper.GetPropertyByName("boundaryMonitor").objectReferenceValue == null)
            {
                EditorGUILayout.HelpBox("A boundary monitor is required whenever a player is linked to the active grid. One will be added automatically at runtime, however you should consider adding one manually now so you set the detection frequency.", MessageType.Error);
            }
        }

        void DrawPlayerOption()
        {
            helper.DrawSerializedPropertyField("player", playerLabel);
        }

        void DrawPlayerMoverOption()
        {
            helper.DrawSerializedPropertyField("playerMover", playerMoverLabel);
            
            if (helper.GetPropertyByName("playerMover").objectReferenceValue == null)
                EditorGUILayout.HelpBox("Please Note: If the player needs to be moved, it will be moved via its transform. Depending on the method you are using to control your character, this may cause the player to fall through the world. If this is a concern for you, create a PlayerMover derived script to move your player instead.", MessageType.Warning);
        }

        void DrawWorldOptions()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField(defaultsLabel, EditorStyles.boldLabel);
                        
            SerializedProperty worldProperty = helper.GetPropertyByName("world");
            helper.DrawSerializedPropertyField(worldProperty);

            World world = worldProperty.objectReferenceValue as World;
            if (worldProperty.objectReferenceValue != null)
                EditorGUILayout.LabelField("ID = " + world.ID);

            EditorGUILayout.HelpBox("If you want to supply the World to the Active Grid at runtime, you can use PreInitialize_SetWorld method, which must be used before the Active Grid has been initialized. Note that a persistent Active Grid can only be synced to a persistent World!", MessageType.Info);  
        }

        void DrawActiveGridTypeOption()
        {
            helper.DrawSerializedPropertyField("activeGridType", activeGridTypeLabel);
        }

        void DrawGridDimensionsOptions()
        {
            EditorGUILayout.LabelField("Grid Dimensions");
            helper.DrawNestedSerializedPropertyField("activeGridState", "innerLayers", innerLayersLabel);
            helper.DrawNestedSerializedPropertyField("activeGridState", "innerRows");
            helper.DrawNestedSerializedPropertyField("activeGridState", "innerColumns");
            helper.DrawNestedSerializedPropertyField("activeGridState", "outerRingWidth");
            EditorGUILayout.Space();
        }

        void DrawSectionOptions()
        {
            EditorGUILayout.LabelField("Starting Section (Used if a player is not present)");
            helper.DrawNestedSerializedPropertyField("activeGridState", "layerOfSection", layerSectionIndexLabel);
            helper.DrawNestedSerializedPropertyField("activeGridState", "rowOfSection");
            helper.DrawNestedSerializedPropertyField("activeGridState", "columnOfSection");
        }

        void DrawPrimaryCellIndexOptions()
        {
            if(helper.GetPropertyByName("activeGridType").intValue == (int)ActiveGridType.Outer_Ring_Grid)
                EditorGUILayout.LabelField("Index Of First Cell In Grid (Used if a player is not present)");
            else
                EditorGUILayout.LabelField("Index Of Starting Sectioned Cell (Used if a player is not present)");

            helper.DrawNestedSerializedPropertyField("activeGridState", "primaryCellLayer", firstCellLayerIndexLabel);
            helper.DrawNestedSerializedPropertyField("activeGridState", "primaryCellRow");
            helper.DrawNestedSerializedPropertyField("activeGridState", "primaryCellColumn");
            EditorGUILayout.Space();
        }

        void DrawEnableCellUsersOptions()
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cellUsersEnabledLabel, mediumLabel);
            helper.DrawNestedSerializedPropertyField("activeGridState", "cellObjectsEnabled", GUIContent.none, mediumLabel);
            EditorGUILayout.EndHorizontal();
        }

        void DrawMonitorInnerAreaBoundariesOptions()
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(monitorInnerAreaBoundariesLabel, mediumLabel);

            helper.DrawNestedSerializedPropertyField("activeGridState", "monitorInnerAreaBoundaries", GUIContent.none);
            EditorGUILayout.EndHorizontal();
        }

        void DrawAllowWorldShiftOptions()
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(allowGridToForceWorldShiftsLabel, mediumLabel);

            helper.DrawNestedSerializedPropertyField("activeGridState", "monitorWorldShiftBoundaries", GUIContent.none);
            EditorGUILayout.EndHorizontal();
        }

        GUIContent activeGridTypeLabel = new GUIContent("Active Grid Type*", "The type of active grid to use. To use the normal grid that has been available since the kit's creation, set this to 'Outer_Ring_Grid'. This grid consist of an inner area and outer ring.\n\nThe new Sectioned_Grid type uses a 4 (for 2D worlds) or 8 (for 3D worlds) cell approach. The cell the player is in is always loaded. For 2D worlds, it is divided into four equal sections, and the 3 additional cells that are loaded are chosen based upon which cells the section that the player falls within is touching.\n\nFor example, if the player is in the top right section, the cell above, to the right, and above and to the right of the cell the player is in will be loaded.\n\nThis grid type results in less cells being loaded a time, but you should be careful about using it; if you're camera's view distances is too large and your terrain too small, the player may notice where your terrains end and may see loading/unloading occur (technically this is a concern when using an Outer_Ring_Grid as well, though less so).");

        GUIContent allowGridToForceWorldShiftsLabel = new GUIContent("Allow Grid To Force World Shifts*", "If checked, when this Active Grid is synced to a World set to stay centered around its origin, the player associated with this grid will be monitored and if they cross the World's shift boundary (defined by the World), the World will be notified and a world shift will occur. It is not recommended to have multiple Active Grid's that can shift the same World at the same time.\n\nNote that if using World Shifting in your game (or one of the Active Grid's methods that moves the player), the player's position when saved via the Component Manager's Save or GetSaveData method is not guaranteed to be the player's actual location when the save occurs.\n\n For this reason, when using world shifting or the movement methods mentioned, do not save/load the player's position manually.");

        GUIContent activeGridIDLabel = new GUIContent("Grid ID*", "An int ID that should be unique to this Active Grid in this scene (there should be no other Active Grids in this scene with this ID).\n\nNote, if you are using this Active Grid as a prototype, the ID does not matter, as it won't be used.");

        GUIContent boundaryMonitorLabel = new GUIContent("Boundary Monitor*", "The boundary monitor that will be used to track the player to see if they have crossed a boundary.\n\nThe same Boundary Monitor can be used with multiple Active Grids.\n\nIf you don't plan on using a player with this Active Grid (unlikely), you can leave this field blank.");

        GUIContent cellUsersEnabledLabel = new GUIContent("Cell Objects Enabled*", "Should the cell objects of the World the Active Grid is synced to be loaded during Awake/Start?\n\nUsually you'll want to leave this option enabled, though keep in mind that for runtime created Active Grids, this value will always be false and you will need to manually load the objects via TryLoadCellObjects or TryLoadCellObjectsAndWaitForLoadToComplete.");

        GUIContent defaultsLabel = new GUIContent("Defaults*", "All of the options below (up to and including 'Monitor Inner Area Boundaries') will only be used if no persistent data is found for the Active Grid. In addition, the index of the first cell in grid is used only if a player is not present, otherwise the world grid is constructed around the player.");

        GUIContent firstCellLayerIndexLabel = new GUIContent("Primary Cell Layer*", "Only used when the grid is synced to a world with a 3D World Grid (otherwide this value defaults to 0).");

        GUIContent innerLayersLabel = new GUIContent("Inner Layers*", "Only used when the grid is synced to a world with a 3D World Grid.");

        GUIContent layerSectionIndexLabel = new GUIContent("Layer of Section*", "Only used when the grid is synced to a world with a 3D World Grid (otherwide this value defaults to 0).");

        GUIContent monitorInnerAreaBoundariesLabel = new GUIContent("Monitor Inner Area Boundaries When Synced*", "Should the Active Grid's inner area boundaries be monitored when the grid is synced to a world?\n\nWhen inner area boundary monitoring is disabled, dynamic loading does not take place, so you will most likely wish to leave this option enabled.\n\nYou can enable or disable inner area boundary monitoring via scripting (see Active Grid page of API on website).");

        GUIContent playerLabel = new GUIContent("Player*", "The transform of the player you wish to be associated with this Active Grid.\n\nPlease ensure this transform is the one who's world position is actually changed as the player moves around the world!\n\nIf you need to pass this player in at runtime, create your Active Grid at runtime instead of using an inspector created one. \n\nTo do this, move this Active Grid to a disabled game object and add it to the Component Manager as a prototype. More info can be found in the Dynamic Loading Kit Full Guide.");

        GUIContent playerMoverLabel = new GUIContent("Player Mover*", "When the Active Grid needs to move the player at any time (necessary when using world shifting, for instance), it offloads the responsibility to the Player Mover, which is a custom abstract class which derives from MonoBehaviour.\n\nBy creating a class that derives from PlayerMover, or by changing an existing script to derive from it, you can ensure that the player is moved in a way that does not result in the player falling through the world.\n\nIf no PlayerMover is provided, the player will be moved by adjusting it's Transform.position, which may or may not ideal (depends on whether you're using a Character Controller, Rigidbody, etc.).\n\nYou can find more information in the Dynamic Loading Kit_Full_Guide, or in aboutTheseScripts.txt, which can be found in TerrainSlicing/OtherScripts/DynamicLoadingScripts/PlayerMoverControllers.\n\nAlso note, if you plan on creating an Active Grid at runtime and passing int a Player, you can also pass in the PlayerMover component at the same time.");
    }

    [CustomEditor(typeof(ActiveGrid))]
    class ActiveGridEditor : Editor
    {
        ActiveGridBaseEditor baseEditor;

        public override void OnInspectorGUI()
        {
            if (baseEditor == null)
                baseEditor = new ActiveGridBaseEditor(serializedObject);
            
            baseEditor.OnInspectorGUI();
        }
    }
}