//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
	using UnityEditor;
	using DynamicLoadingKit;

	[CustomEditor(typeof(NonPoolingPrimaryCellObjectSubController))]
    class NonPoolingPrimaryCellObjectSubControllerEditor : Editor
	{
        PrimaryCellObjectSubControllerEditor baseEditor;
		
		public override void OnInspectorGUI()
		{
            if (baseEditor == null)
                baseEditor = new PrimaryCellObjectSubControllerEditor(serializedObject);
            
            baseEditor.OnInspectorGUI();
		}
	}
}