﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using System;
    using UnityEngine;
    using DynamicLoadingKit;

    internal abstract class DimensionGetter
    {
        internal abstract float GetHeight(Component component);
        internal abstract float GetLength(Component component);
        internal abstract float GetWidth(Component component);
    }

    internal class TerrainDimensionGetter : DimensionGetter
    {
        internal TerrainDimensionGetter() { }

        internal sealed override float GetHeight(Component component)
        {
            return ((Terrain)component).terrainData.size.y;
        }

        internal sealed override float GetLength(Component component)
        {
            return ((Terrain)component).terrainData.size.z;
        }

        internal sealed override float GetWidth(Component component)
        {
            return ((Terrain)component).terrainData.size.x;
        }
    }

    internal class RendererDimensionGetter : DimensionGetter
    {
        Func<Bounds, float> GetHeightFromBounds;
        Func<Bounds, float> GetLenghFromBounds;
        Func<Bounds, float> GetWidthFromBounds;

        internal RendererDimensionGetter(GridValues<BoundsComponent> boundsComponents)
        {
            SetGetHeightFromBoundsFunction(boundsComponents.layerValue);
            SetGetLengthFromBoundsFunction(boundsComponents.rowValue);
            SetGetWidthFromBoundsFunction(boundsComponents.columnValue);
        }

        void SetGetHeightFromBoundsFunction(BoundsComponent componentToGetHeightFrom)
        {
            if (componentToGetHeightFrom == BoundsComponent.x)
                GetHeightFromBounds = bounds => bounds.size.x;
            else if (componentToGetHeightFrom == BoundsComponent.y)
                GetHeightFromBounds = bounds => bounds.size.y;
            else
                GetHeightFromBounds = bounds => bounds.size.z;
        }

        void SetGetLengthFromBoundsFunction(BoundsComponent componentToGetLengthFrom)
        {
            if (componentToGetLengthFrom == BoundsComponent.x)
                GetLenghFromBounds = bounds => bounds.size.x;
            else if (componentToGetLengthFrom == BoundsComponent.y)
                GetLenghFromBounds = bounds => bounds.size.y;
            else
                GetLenghFromBounds = bounds => bounds.size.z;
        }

        void SetGetWidthFromBoundsFunction(BoundsComponent componentToGetWidthFrom)
        {
            if (componentToGetWidthFrom == BoundsComponent.x)
                GetWidthFromBounds = bounds => bounds.size.x;
            else if (componentToGetWidthFrom == BoundsComponent.y)
                GetWidthFromBounds = bounds => bounds.size.y;
            else
                GetWidthFromBounds = bounds => bounds.size.z;
        }

        internal sealed override float GetHeight(Component component)
        {
            return GetHeightFromBounds(((Renderer)component).bounds);
        }

        internal sealed override float GetLength(Component component)
        {
            return GetLenghFromBounds(((Renderer)component).bounds);
        }

        internal sealed override float GetWidth(Component component)
        {
            return GetWidthFromBounds(((Renderer)component).bounds);
        }
    }
}
