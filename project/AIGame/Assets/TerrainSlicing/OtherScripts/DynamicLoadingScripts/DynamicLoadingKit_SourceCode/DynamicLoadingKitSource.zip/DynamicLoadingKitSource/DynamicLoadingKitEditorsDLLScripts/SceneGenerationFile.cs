﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using UnityEngine;
    using UnityEditor;

    public class SceneGenerationFile : ScriptableObject
    {
        //foldout options
        [SerializeField]
        internal bool showNameSettings = true, showRangeSettings = true, showMiscOptions = true, showSaveLoadOptions = true;

#if !UNITY_4
        [SerializeField]
        internal bool showAssetBundleOptions = true, showBuildSettingsWarning = true, assignScenesToAssetBundles, addScenesToBuildSettings, useVariants;

        [SerializeField]
        internal string variantName = "";
#endif

        //scene generation settings
        [SerializeField]
        internal bool groupIs3D, areScenesFixed;

        [SerializeField]
        internal int firstColumn = 1, firstRow = 1, firstLayer = 1;

        [SerializeField]
        internal int lastColumn = 4, lastRow = 4, lastLayer = 4;

        [SerializeField]
        internal NamingConvention inputNamingConvention, outputNamingConvention;

        [SerializeField]
        internal string sharedNameInput = "Terrain", sharedNameOutput = "Terrain", unboundTagName = "Untagged", savePath, loadPath;
    }
}
