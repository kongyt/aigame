﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
    using UnityEngine;
    using System;
    using System.Text;
    using System.Collections.Generic;

    /*
        Active Grid Notes
        1: references to the active cell refer to the endless grid cell (zero based) that the player is in
    */
    

    /// <summary>
    /// Defines a grid containing <see cref="ActiveGridCells" href="ActiveGridCells.html">ActiveGridCells</see>. Provides for
    /// the manipulation of these cells and other actions.
    /// <para>For the inspector options below, note that some options have <em>(DO)</em> at the end of their description. This indicates that the option is a default option 
    /// and will only be used when no persistent data for the Active Grid is present, such as when the Active Grid is first added to
    /// the scene in the Editor.</para>
    /// <para>Finally, an Active Grid should only be disabled (or its game object disabled) if it is being used as a prototype to create active grids 
    /// at runtime. Do not disable an Active Grid with the intention of enabling/using it at a later time, as this will not work properly. Instead, 
    /// you should create the Active Grid via the Component Manager when it is needed, and destroy it when it is no longer needed.</para>
    /// </summary>
    /// <title>ActiveGrid Class</title>
    /// <category>Primary Components</category>
    /// <navigationName>ActiveGrid</navigationName>
    /// <fileName>ActiveGrid.html</fileName>
    /// <syntax>public sealed partial class ActiveGrid : MonoBehaviour, <see href = "IIdentifiable.html">IIdentifiable</see>, <see cref="IWorldUser" href="IWorldUser.html">IWorldUser</see></syntax>
    /// 
    /// <inspector name="AllowGridToForceWorldShifts" type="bool">Should the Boundary Monitor associated with the Active Grid monitor
    /// the World Shift Boundary of the World the Active Grid is synced to when the game starts? This is only used when the World the Active Grid 
    /// is synced to is set to stay centered around the origin.
    /// <para>If enabled, a world shift will be initiated when the player crosses the world shift boundary. 
    /// If you have multiple Active Grids/Players, issues can arise when the players are at opposite ends of the World. One player might force a world shift that forces a different player  
    /// accross the opposite boundary, which forces a shift in the opposite direction. This in turns forces the first player across the original boundary, 
    /// causing and endless cycle of world shifts. For this reason, it is not recommended to have multiple Active Grids/Players able to shift the same World at the same time.</para>
    /// <para>This can be done by disabling this option on all but one Active Grids (probably the main player on a client).</para>
    /// </inspector>
    /// 
    /// <inspector name = "Boundary Monitor" type = "BoundaryMonitor" link = "BoundaryMonitor.html">The Boundary Monitor that should be used to
    /// track the player's position (must be provided for dynamic loading and reset boundary monitoring to work).</inspector>
    /// 
    /// <inspector name="Cell Users Enabled" type="bool">Should Cell Users be enabled at the start of the scene? If disabled, the cell objects
    /// associated with the cells will not be loaded. <em>(DO)</em></inspector>
    /// 
    /// <inspector name = "Column Index" type ="int">The column index of the bottom left most cell in the Active Grid, used only when
    /// a player Transform is not associated with the Active Grid. <em>(DO)</em></inspector>
    /// 
    /// <inspector name = "Grid ID" type ="int">The ID that uniquely identifies this Active Grid. If multiple Active Grids exist in the same scene,
    /// it is imperative that their ID's be unique. When creating Active Grid's at runtime via the 
    /// <see cref="ComponentManager" href="ComponentManager.html">Component Manager</see>, a unique ID is automatically
    /// assigned to the created Active Grid.</inspector>
    /// 
    /// <inspector name = "Inner Columns" type ="int">The number of columns in the inner area of the Active Grid. <em>(DO)</em></inspector>
    /// 
    /// <inspector name = "Inner Layers" type ="int">The number of layers in the inner area of the Active Grid 
    /// (relevant only when the Active Grid is synced to a three dimensional 
    /// <see cref="World" href="World.html">World</see>). <em>(DO)</em></inspector>
    /// 
    /// <inspector name = "Inner Rows" type ="int">The number of rows in the inner area of the Active Grid. <em>(DO)</em></inspector>
    /// 
    /// <inspector name = "Layer Index" type ="int">The layer index of the bottom left most cell in the Active Grid, used only when
    /// a player Transform is not associated with the Active Grid and the Active Grid is 
    /// synced to a three dimensional <see cref="World" href="World.html">World</see>. <em>(DO)</em></inspector>
    /// 
    /// <inspector name="Monitor Inner Area Boundaries" type="bool">Should the Boundary Monitor associated with the Active Grid monitor
    /// the Inner Area Boundaries of the Active Grid when the scene starts? Unchecking this option will effectively disable dynamic loading. 
    /// Note that this option is only displayed when a Boundary Monitor is supplied to the Active Grid. <em>(DO)</em></inspector>
    /// 
    /// <inspector name = "Outer Ring Width" type ="int">The width of the outer ring of cells that surrounds the inner area of the Active Grid. <em>(DO)</em></inspector>
    /// 
    /// <inspector name = "Player" type ="Transform" link="http://docs.unity3d.com/ScriptReference/Transform.html">
    /// The Transform of the player that is associated with the Active Grid. The position of this transform should reflect your player's position in the world.</inspector>
    /// 
    /// <inspector name = "Player Mover" type ="PlayerMover" link="PlayerMover.html">The Player Mover component that should be used
    /// to move the player. If left blank, the player will be moved via it's Transform, which may or may not cause issues depending upon
    /// your movement system (are you using a Rigidbody, Character Controller, etc.?).
    /// <para>Please visit the Player Mover page for more information.</para></inspector>
    /// 
    /// <inspector name = "Row Index" type ="int">The row index of the bottom left most cell in the Active Grid, used only when
    /// a player Transform is not associated with the Active Grid. <em>(DO)</em></inspector>
    /// 
    /// <inspector name = "World" type ="World" link="World.html">The World the Active Grid should start synced to. <em>(DO)</em></inspector>
    [AddComponentMenu("Dynamic Loading Kit/Main Components/Active Grid")]
    public sealed partial class ActiveGrid : MonoBehaviour, IIdentifiable, IWorldUser
    {
        #region Variables
        [SerializeField]
        internal int activeGridID;
        
        [SerializeField]
        internal ActiveGridState activeGridState = new ActiveGridState();

        //Required Components
        [SerializeField]
        internal BoundaryMonitor boundaryMonitor;

        [SerializeField]
        internal Transform player;

        [SerializeField]
        internal PlayerMover playerMover;

        [SerializeField]
        internal World world;

        [SerializeField]
        internal ActiveGridType activeGridType;

        List<Cell> cellsToRemoveUsersFrom, cellsToAddUsersTo;

        ActiveGridCells activeGridCells;
        Boundary innerAreaBoundary, activeCellBoundary, worldShiftBoundary;
        Cell activeCell;
        ComponentManager componentManager;
        IActiveGridTypeSpecificLogic activeGridTypeSpecificLogic;
        int innerAreaAndWorldShiftBoundaryMonitorID, activeCellBoundaryMonitorID, worldRegistrationID;

        //Next three variables Used by Component Manager
        internal bool runtimeCreated = false, persistent = true;
        internal int prototypeCreatedFrom;//Note, only useful for runtime created Active Grids.

        bool persistentDataSet;
        Action<BoundaryCrossed, BoundaryCrossed, BoundaryCrossed> MethodToCallWhenInnerAreaBoundaryCrossed, MethodToCallWhenActiveCellBoundaryCrossed;
        #endregion

        #region Events

        /// <summary>
        /// An event that can be subscribed to in order to receive 
        /// notifications when the cell the player is in changes. Please keep the following points in mind:
        /// <para>
        /// 1) The cell in question is the 
        /// endless grid cell the player is in, which can change, among other reasons, as the 
        /// result of a world shift. In this case, the WorldGridCellPlayerIsIn and 
        /// WorldCellPlayerIsIn will remain the same as before the event was fired. In other situations, the 
        /// WorldCell will change but WorldGridCellPlayerIsIn will remain the same (if the player 
        /// is transported to an endless grid cell that is associated with the same world grid cell as the 
        /// previous endless grid cell the player was on).
        /// </para>
        /// <para>
        /// 2) When the Active Grid becomes desynced from a World, the WorldCellPlayerIsIn 
        /// will be null and EndlessGridCellPlayerIsIn/WorldGridCellPlayerIsIn values invalid, and this 
        /// event will stop firing (until a new world is synced).
        /// </para> 
        /// <para>
        /// 3) The WorldCellPlayerIsIn property will also return null if a World Cell cannot be retrieved 
        /// from the World 
        /// for a given cell. This can occur if that cell on the World is not active, either 
        /// because the component manager has not been initialized or had time to fully load the world 
        /// objects, that cell is simply empty, or this Active Grid and any other World users are not 
        /// "using" that cell (which can occur, for instance, if the Active Grid's Monitor 
        /// Inner Area Boundaries option is disabled). In any case, EndlessGridCellPlayerIsIn and 
        /// WorldGridCellPlayerIsIn will still be valid.
        /// </para>
        /// <para>
        /// 4) This event will not fire upon initialization of the Active Grid, only during gameplay as the player 
        /// moves around the scene, or when the Active Grid syncs/desyncs from a world during gameplay. 
        /// If you need to find the world grid cell, endless grid cell, or World Cell that the player 
        /// is in (including at the start of the game), you should use the appropriate methods on the World class.
        /// </para>
        /// <para>
        /// 5) The event args are reused for each event, so once a new event fires the 
        /// WorldCellPlayerIsIn, EndlessGridCellPlayerIsIn, and WorldGridCellPlayerIsIn values will no 
        /// longer be accurate for the previous event (though some values may be the same, depending upon 
        /// the situation which caused the new event to fire).
        /// </para>
        /// <para>
        /// 6) The event utilizes 
        /// <see cref="CellPlayerIsInChangedEventArgs" href="WorldCellPlayerIsInChangedEventArgs.html">CellPlayerIsInChangedEventArgs</see> 
        /// and subscribers must have a signature of 
        /// void MethodName(object sender, CellPlayerIsInChangedEventArgs paramaterName).
        /// </para>
        /// </summary>
        /// <validSubscriber>void MethodName(object sender, CellPlayerIsInChangedEventArgs parameterName)</validSubscriber>
        public event EventHandler<CellPlayerIsInChangedEventArgs>CellPlayerIsInChanged;
        CellPlayerIsInChangedEventArgs cellPlayerIsInChangedEventArgs;

        /// <summary>
        /// An event that can be subscribed to in order to receive notifications when the player is 
        /// moved by the Active Grid. This is most useful when trying to sync an action to the player being 
        /// moved during one of the Active Grids move methods.
        /// <para>
        /// Note, the event args are reused for each event, so once a new event fires the Player values 
        /// will no longer be accurate for the previous event. If you need to use this 
        /// value at a future time, you should store them locally.
        /// </para>
        /// <para>
        /// The event utilizes 
        /// <see cref="PlayerMovedByGridEventArgs" href="PlayerMovedByGridEventArgs.html">PlayerMovedByGridEventArgs</see> 
        /// and subscribers must have a signature of void MethodName(object sender, PlayerMovedByGridEventArgs paramaterName).
        /// </para>
        /// </summary>
        /// <validSubscriber>void MethodName(object sender, PlayerMovedByGridEventArgs parameterName)</validSubscriber>
        public event EventHandler<PlayerMovedByGridEventArgs> PlayerMovedByGrid;
        PlayerMovedByGridEventArgs playerMovedByGridEventArgs;

        /// <summary>
        /// An event that can be subscribed to in order to receive notifications when the Active Grid is 
        /// synced to a new World. When the sync occurs as a result of TryMovePlayerToLocationOnNewWorld, 
        /// the sync "occurs" when the player is moved, otherwise the sync occurs just before the 
        /// coroutine that triggered the sync exits.
        /// <para>
        /// Note, the event args are reused for each event, so once a new event fires the OldWorld 
        /// and NewWorld values will no longer be accurate for the previous event. If you need to use this 
        /// value at a future time, you should store them locally.
        /// </para>
        /// <para>
        /// The event utilizes 
        /// <see cref="WorldSyncedToChangedEventArgs" href="WorldSyncedToChangedEventArgs.html">WorldSyncedToChangedEventArgs</see> 
        /// and subscribers must have a signature of void MethodName(object sender, WorldSyncedToChangedEventArgs paramaterName).
        /// </para>
        /// </summary>
        /// <validSubscriber>void MethodName(object sender, WorldSyncedToChangedEventArgs parameterName)</validSubscriber>
        public event EventHandler<WorldSyncedToChangedEventArgs> WorldSyncedToChanged;
        WorldSyncedToChangedEventArgs worldSyncedToChangedEventArgs;
        #endregion

        #region Public Properties/Methods

        /// <summary>
        /// Gets a value indicating the Active Grid Type of the Active Grid.
        /// </summary>
        /// <type link="ActiveGridType.html">ActiveGridType</type>
        public ActiveGridType ActiveGridType { get { return activeGridType; } }

        /// <summary>
        /// Gets a value indicating whether cell users are enabled for the Active Grid. This is mostly useful 
        /// if you are not seeing objects loaded in your scene and you're not sure why. This value may be false 
        /// (and thus no objects loaded) if you have created the Active Grid at runtime and not called one of the 
        /// TryLoadCellObjects methods, or if you have called one of the TryUnloadCellObjects methods.
        /// </summary>
        /// <type>bool</type>
        public bool AreCellUsersEnabled { get { return activeGridState.cellObjectsEnabled; } }

        /// <summary>
        /// Gets a value indicating whether cell users are loaded for the Active Grid. Note that the actual physical cell objects may not be in th scene when this value returns true, as it's possible the World is in the process of loading them still.
        /// </summary>
        /// <type>bool</type>
        public bool AreCellUsersLoaded { get { return activeGridState.cellObjectsLoaded; } }

        /// <summary>
        /// Gets the identification number of the Active Grid.
        /// </summary>
        /// <type>int</type>
        public int ID { get { return activeGridID; } }

        /// <summary>
        /// Gets a value indicating whether the Active Grid is persistent between game sessions.
        /// </summary>
        /// <type>bool</type>
        public bool IsActiveGridPersistent { get { return persistent; } }

        /// <summary>
        /// Gets a value indicating whether ManagedAwake has been called (and successfully run) already. 
        /// </summary>
        /// <type>bool</type>
        public bool IsInitialized { get { return cellsToAddUsersTo != null; } }

        /// <summary>
        /// Gets a value indicating whether the current Active Grid is busy. "Busy" simply means a multi frame action (aka, a coroutine method)
        /// is currently being executed (such as the method <see href = "#TryMovePlayerToLocation">TryMovePlayerToLocation</see>).
        /// </summary>
        /// <type>bool</type>
        public bool IsBusy  { get { return activeGridState.multiFrameActionExecuting; } }

        internal bool IsReadyForWorldShiftPreparation { get { return !IsBusy; } }
        
        /// <summary>
        /// Gets the Persistent Data Save Key for the Active Grid. This is only valid if 
        /// "Use Custom Save/Load Solution" is disabled on your Component Manager.
        /// </summary>
        /// <type>string</type>
        public string PersistentDataSaveKey     { get; internal set; }

        /// <summary>
        /// Gets the current Player associated with the Active Grid.
        /// </summary>
        /// <type>Transform</type>
        public Transform Player { get { return player; } }

        /// <summary>
        /// Gets the current Player Mover associated with the Active Grid.
        /// </summary>
        /// <type link="PlayerMover.html">PlayerMover</type>
        public PlayerMover PlayerMover { get { return playerMover; } }

        /// <summary>
        /// During an Active Grid operation where the player needs to be moved and true was passed in for waitForCommandBeforeMovingPlayer,
        /// this can be used to determine whether the player is ready to be moved. This will be true if the area the player is being moved to 
        /// has successfully been loaded.
        /// <para>This is most useful when trying to sync other actions/events to 
        /// the player being moved (such as a portal effect or transport sound).</para>
        /// <para>To use it effectively, you'd call StartCoroutine(any Active Grid Method that moves the player, such as 
        /// <see cref="TryMovePlayerToLocation" href="#TryMovePlayerToLocation">TryMovePlayerToLocation</see>). When you are ready 
        /// for the player to be moved, you query this property to make sure the area to move the player to has been loaded. 
        /// Once this returns true, you play your effect/sound and call the same Active Grid's 
        /// <see cref="InitiatePendingMove" href="#InitiatePendingMove">InitiatePendingMove</see> method at the appropriate time during that 
        /// effect/sound.</para>
        /// <para>The player will be moved either in the same frame or a couple of frames after, depending on whether a Player Mover 
        /// component is linked to the Active Grid. In the case of the latter, the player should not notice the delay.</para>
        /// </summary>
        public bool PlayerReadyToBeMoved { get; private set; }

        /// <summary>
        /// Gets the current World the Active Grid is synced to.
        /// </summary>
        /// <type link = "World.html">World</type>
        public World WorldSyncedTo  { get { return world; } }

        /// <summary>
        /// Gets the total number of columns currently being used by the Active Grid.
        /// </summary>
        /// <syntax>public int GetColumnsInUse()</syntax>
        /// <displayName id="GetColumnsInUse">GetColumnsInUse()</displayName>
        /// <returns type = "int">Returns 0 when no active grid cells have been created or the Active Grid Type is set to 
        /// Sectioned_Grid, otherwise a value greater than 0.
        /// </returns>
        public int GetColumnsInUse()
        {
            if (activeGridCells == null || activeGridType == ActiveGridType.Sectioned_Grid)
                return 0;
            else
                return ((OuterRingActiveGridCells)activeGridCells).Columns;
        }

        /// <summary>
        /// Gets the total number of layers currently being used by the Active Grid.
        /// </summary>
        /// <syntax>public int GetLayersInUse()</syntax>
        /// <displayName id="GetLayersInUse">GetLayersInUse()</displayName>
        /// <returns type = "int">Returns 0 when no active grid cells have been created or the Active Grid Type is set to 
        /// Sectioned_Grid, otherwise a value greater than 0 (but which will alwyas be 1 when the grid is synced to a 2D world).
        /// </returns>
        public int GetLayersInUse()
        {
            if (activeGridCells == null || activeGridType == ActiveGridType.Sectioned_Grid)
                return 0;

            OuterRingActive3DGridCells cells = activeGridCells as OuterRingActive3DGridCells;
            //Cells are 2D not 3D, so layers used is 1
            if (cells == null)
                return 1;
            else
                return cells.Layers;
        }

        /// <summary>
        /// Gets the total number of rows currently being used by the Active Grid.
        /// </summary>
        /// <syntax>public int GetRowsInUse()</syntax>
        /// <displayName id="GetRowsInUse">GetRowsInUse()</displayName>
        /// <returns type = "int">
        /// Returns 0 when no active grid cells have been created or the Active Grid Type is set to 
        /// Sectioned_Grid, otherwise a value greater than 0.
        /// </returns>
        public int GetRowsInUse()
        {
            if (activeGridCells == null || activeGridType == ActiveGridType.Sectioned_Grid)
                return 0;
            else
                return ((OuterRingActiveGridCells)activeGridCells).Rows;
        }

        /// <summary>
        /// Gets the distance that a cell is from the inner area of the active grid. 
        /// This effectively tells you what ring the cell is in 
        /// when using an outer ring grid. 
        /// <para>
        /// You can use this info for a variety of purposes, for instance you could modify loaded terrains to use a lower resolution 
        /// at runtime if they are farther from the grids center.
        /// </para>
        /// </summary>
        /// <param name="cellOnEndlessGrid" type="Cell" link="Cell.html">
        /// The cell whose distance from center you want. It should be one based and a cell on your worlds endless grid.
        /// </param>
        /// <returns type="int">0 will be returned if the cell is part of the inner grid, 1 if the cell 
        /// is in the first ring around the inner grid, and so on. A -1 will be returned if the ring cannot be determined or 
        /// if using a sectioned grid.
        /// </returns>
        /// <syntax>
        /// public int GetDistanceFromInnerAreaOfGrid(Cell cellOnEndlessGrid)
        /// </syntax>
        /// <displayName id="GetDistanceFromInnerAreaOfGrid">
        /// GetDistanceFromInnerAreaOfGrid(Cell)
        /// </displayName>
        public int GetDistanceFromInnerAreaOfGrid(Cell cellOnEndlessGrid)
        {
            if (activeGridCells == null || activeGridType == ActiveGridType.Sectioned_Grid)
                return -1;

            Cell zeroBasedCell = cellOnEndlessGrid.ConvertTo0Based(world != null ? world.IsWorld3D : false);

            return ((OuterRingActiveGridCells)activeGridCells).GetDistanceFromInnerGrid(zeroBasedCell);
        }

        #endregion

        #region Initialization

        /// <summary>
        /// Sets the initial World for the Active Grid to use. This must be called before the Active Grid has been 
        /// initialized, and if the Active Grid is persistent, the world must also be persistent.
        /// <para>Note, this will not fire the ActiveGridSyncedToNewWorld event.</para>
        /// </summary>
        /// <param name="world" type="World" link="World.html">
        /// The world for the Active Grid to use.
        /// </param>
        /// <param name="overwriteWorldFromPersistentData" type="bool">
        /// If true, the passed in World will be used regardless of whether persistent data exist for the Active Grid. If false, the passed 
        /// in world will be used if a) no persistent data exist for the Active Grid, or b) persistent data exist, but no world was found 
        /// in the data (happens when active grid was synced to a non persistent world when data was saved).
        /// </param>
        /// <exception name="InvalidOperationException">
        /// Thrown when the Active Grid has already been initialized.
        /// </exception>
        /// <displayName id="PreInit_SetWorld">
        /// PreInitialize_SetWorld(World, bool)
        /// </displayName>
        /// <syntax>
        /// public void PreInitialize_SetWorld(World world, bool overwriteWorldFromPersistentData)
        /// </syntax>
        public void PreInitialize_SetWorld(World world, bool overwriteWorldFromPersistentData)
        {
            if (IsInitialized)
                throw new InvalidOperationException("PreInit_SetWorld call on Active Grid with ID" + ID + " failed. The Active Grid has already been initialized, and this method must be called before it has been initialized.");

            if (persistent && !world.IsWorldPersistent)
                throw new InvalidPersistenceException(string.Format("PreInit_SetWorld call on Active Grid with ID {0} failed. The Active Grid is persistent, but the World you are trying to set (ID = {1}) is not. This is not allowed.", ID, world.ID));

            activeGridState.ignoreWorldInPersistentData = overwriteWorldFromPersistentData;

            if (!persistentDataSet || overwriteWorldFromPersistentData || world == null)
            {
                this.world = world;
                activeGridState.idOfSyncedToWorld = world.ID;
            }
        }

        internal void PreInitialize_SetPlayer(Transform newPlayer, PlayerMover newPlayerMover)
        {
            player = newPlayer;
            if (player != null)
                playerMover = newPlayerMover;
            else
                playerMover = null;
        }

        internal void Initialize(ComponentManager componentManager = null)
        {
            if(componentManager != null)
                this.componentManager = componentManager;

            if (IsInitialized)
                return;

            if (world == null && !componentManager.suppressWarnings)
                Debug.LogWarning("Active Grid with ID " + ID + " Initialized, but the Active Grid is missing a World component. The grid will sit idle until you sync it to a world. Remember, you can set a world before the grid is initialized via the PreInitializeSetWorld method.");

            if (player == null)
            {
                if (activeGridState.monitorInnerAreaBoundaries || activeGridState.monitorWorldShiftBoundaries)
                    throw new MissingComponentException("Active Grid with ID " + ID + " Initialized, but the Active Grid is missing a Player component. Inner Area Boundaries and/or World Shift Boundaries cannot be monitored when a player is not present.");
            }
            else
            {
                cellPlayerIsInChangedEventArgs = new CellPlayerIsInChangedEventArgs();
                playerMovedByGridEventArgs = new PlayerMovedByGridEventArgs(player);
            }

            worldSyncedToChangedEventArgs = new WorldSyncedToChangedEventArgs();
            MethodToCallWhenInnerAreaBoundaryCrossed = OnInnerAreaBoundaryCrossed;
            MethodToCallWhenActiveCellBoundaryCrossed = OnActiveCellBoundaryCrossed;

            InitializeUserRequestsList();

            if (player != null)
            {
                CreateBoundaryMonitorIfNull();
                boundaryMonitor.Register(player, out innerAreaAndWorldShiftBoundaryMonitorID);
                boundaryMonitor.Register(player, out activeCellBoundaryMonitorID);
            }

            if (world != null)
            {
                world.Initialize(componentManager);
                world.Register(this, out worldRegistrationID);
                activeGridTypeSpecificLogic = CreateActiveGridTypeSpecificLogic();
                PerformInitialSetupOfActiveGridCells();
                if (player != null)
                {
                    if (activeGridState.monitorInnerAreaBoundaries || activeGridState.monitorWorldShiftBoundaries)
                        SetupInnerAreaAndShiftBoundaryMonitors();

                    activeCell = FindCellPlayerIsIn(world);
                    SetupActiveCellBoundary();
                }
            }
        }

        void InitializeUserRequestsList()
        {
            cellsToAddUsersTo = new List<Cell>();
            cellsToRemoveUsersFrom = new List<Cell>();
        }

        IActiveGridTypeSpecificLogic CreateActiveGridTypeSpecificLogic()
        {
            if (activeGridType == ActiveGridType.Outer_Ring_Grid)
                return new OuterRingGridLogic(this);
            else
                return new SectionedGridLogic(this);
        }

        void PerformInitialSetupOfActiveGridCells()
        {
            if (player != null)
            {
                if (!persistentDataSet || !IsPersistentDataAccurateGivenPlayerPosition())
                {
                    IdentifyFirstCellInGridBasedOnPlayerPosition();
                    SetSectionPlayerIsIn(new Cell(activeGridState.primaryCellRow - 1, activeGridState.primaryCellColumn - 1, activeGridState.primaryCellLayer - 1));
                }
                
            }
            else if (world.WorldGrid.WorldType != WorldType.Three_Dimensional)
                activeGridState.primaryCellLayer = 1;

            SetupActiveGridCells();
        }

        //Checks whether the player is in the projected area where we think he should be. The projected area is based on the 
        //primary cell and, for Sectioned_Grid's, the row, column, and layer of the section.
        //This is basically an accuracy check to make sure the player is where he's suppose to be. 
        //If he's not, it's a signal that some of the persistent data is not accurate and the grid should 
        //be rebuilt based on the player's position.
        bool IsPersistentDataAccurateGivenPlayerPosition()
        {
            Vector3 bottomSouthWestBoundary, topNorthEastBoundary;
            
            if (activeGridType == ActiveGridType.Outer_Ring_Grid)
            {
                Cell innerAreaFirstCell = new Cell(activeGridState.primaryCellRow + activeGridState.outerRingWidth, activeGridState.primaryCellColumn + activeGridState.outerRingWidth, world.WorldGrid.WorldType == WorldType.Three_Dimensional ? activeGridState.primaryCellLayer + activeGridState.outerRingWidth : 0);

                bottomSouthWestBoundary = world.GetPositionOfEndlessGridCell_ZeroBased(innerAreaFirstCell);

                Cell cellJustOutsideInnerArea = new Cell(innerAreaFirstCell.row + activeGridState.innerRows, innerAreaFirstCell.column + activeGridState.innerColumns, world.WorldGrid.WorldType == WorldType.Three_Dimensional ? innerAreaFirstCell.layer + activeGridState.innerLayers : 0);
                topNorthEastBoundary = world.GetPositionOfEndlessGridCell_ZeroBased(cellJustOutsideInnerArea);
            }
            else
            {
                Vector3 positionOfInnerAreaFirstCell;
                CellDimensions dimensionsOfInnerAreaFirstCell;
                Cell innerAreaFirstCell = new Cell(activeGridState.primaryCellRow, activeGridState.primaryCellColumn, activeGridState.primaryCellLayer);

                world.GetPositionAndDimensionsOfEndlessGridCell_ZeroBased(innerAreaFirstCell, out positionOfInnerAreaFirstCell, out dimensionsOfInnerAreaFirstCell);

                float x1 = activeGridState.columnOfSection == 0 ? positionOfInnerAreaFirstCell.x : positionOfInnerAreaFirstCell.x + (.5f * dimensionsOfInnerAreaFirstCell.width);

                float x2 = x1 + (.5f * dimensionsOfInnerAreaFirstCell.width);

                float y1, z1, y2, z2;
                if (world.WorldGrid.WorldType == WorldType.Three_Dimensional)
                {
                    y1 = activeGridState.layerOfSection == 0 ? positionOfInnerAreaFirstCell.y : positionOfInnerAreaFirstCell.y + (.5f * dimensionsOfInnerAreaFirstCell.height);
                    y2 = y1 + (.5f * dimensionsOfInnerAreaFirstCell.height);

                    z1 = activeGridState.rowOfSection == 0 ? positionOfInnerAreaFirstCell.z : positionOfInnerAreaFirstCell.z + (.5f * dimensionsOfInnerAreaFirstCell.length);
                    z2 = z1 + (.5f * dimensionsOfInnerAreaFirstCell.length);
                }
                else if (world.WorldGrid.WorldType == WorldType.Two_Dimensional_On_XY_Axes)
                {
                    z1 = 0f;
                    z2 = 0f;

                    y1 = activeGridState.rowOfSection == 0 ? positionOfInnerAreaFirstCell.y : positionOfInnerAreaFirstCell.y + (.5f * dimensionsOfInnerAreaFirstCell.length);
                    y2 = y1 + (.5f * dimensionsOfInnerAreaFirstCell.length);                    
                }
                else
                {
                    y1 = 0f;
                    y2 = 0f;

                    z1 = activeGridState.rowOfSection == 0 ? positionOfInnerAreaFirstCell.z : positionOfInnerAreaFirstCell.z + (.5f * dimensionsOfInnerAreaFirstCell.length);
                    z2 = z1 + (.5f * dimensionsOfInnerAreaFirstCell.length);                    
                }

                bottomSouthWestBoundary = new Vector3(x1, y1, z1);
                topNorthEastBoundary = new Vector3(x2, y2, z2);
            }

            if (player.position.x < bottomSouthWestBoundary.x || player.position.x > topNorthEastBoundary.x)
                return false;

            if(world.WorldGrid.WorldType == WorldType.Three_Dimensional)
            {
                if (player.position.y < bottomSouthWestBoundary.y || player.position.y > topNorthEastBoundary.y)
                    return false;

                if (player.position.z < bottomSouthWestBoundary.z || player.position.z > topNorthEastBoundary.z)
                    return false;
            }
            else if (world.WorldGrid.WorldType == WorldType.Two_Dimensional_On_XY_Axes)
            {
                if (player.position.y < bottomSouthWestBoundary.y || player.position.y > topNorthEastBoundary.y)
                    return false;
            }
            else
            {
                if (player.position.z < bottomSouthWestBoundary.z || player.position.z > topNorthEastBoundary.z)
                    return false;
            }

            return true;
        }

        void IdentifyFirstCellInGridBasedOnPlayerPosition()
        {
            Cell firstCellInInnerAreaOfGrid = world.FindEndlessGridCellPositionIsIn_ZeroBased(player.position);
            Cell zeroBasedPrimaryCellInGrid = activeGridTypeSpecificLogic.FindPrimaryCellInGridUsingFirstCellInInnerAreaOfGrid(world, firstCellInInnerAreaOfGrid);

            activeGridState.primaryCellLayer = zeroBasedPrimaryCellInGrid.layer + 1;
            activeGridState.primaryCellRow = zeroBasedPrimaryCellInGrid.row + 1;
            activeGridState.primaryCellColumn = zeroBasedPrimaryCellInGrid.column + 1;
        }

        void SetupActiveGridCells()
        {
            Cell firstCell = new Cell(activeGridState.primaryCellRow - 1, activeGridState.primaryCellColumn - 1, activeGridState.primaryCellLayer - 1);
            if(activeGridCells == null)
                activeGridCells = activeGridTypeSpecificLogic.CreateActiveGridCells(firstCell, world.WorldGrid.WorldType, activeGridState.layerOfSection, activeGridState.rowOfSection, activeGridState.columnOfSection);
            else
                activeGridTypeSpecificLogic.ReassignActiveGridCellIndexesUsingPrimaryCell(firstCell);
        }

        #endregion

        #region Private Methods

        void RebuildGridAroundPlayer()
        {
#if DEBUG_ON
            Debug.Log("Rebuilding Active Grid around player, as they are beyond the new Inner Boundary Area (this probably shouldn't happen).");
#endif
            if (activeGridState.cellObjectsLoaded)
            {
                activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToRemoveUsersFrom);
            }

            Cell cellPlayerIsIn = world.FindEndlessGridCellPositionIsIn_ZeroBased(player.position);
            activeGridTypeSpecificLogic.ReassignActiveGridCellIndexesUsingCellPlayerIsIn(cellPlayerIsIn);

            if (activeGridState.cellObjectsLoaded)
            {
                activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToAddUsersTo);

                world.AddCellUsers_ZeroBased(cellsToAddUsersTo);
                world.RemoveCellUsers_ZeroBased(cellsToRemoveUsersFrom);

                cellsToRemoveUsersFrom.Clear();
                cellsToAddUsersTo.Clear();
            }

            SetFirstAndLastCellInInnerArea();
            activeGridTypeSpecificLogic.CalculateInnerAreaBoundaries();
            ResetPrimaryCellIndexes();
        }

        internal void StartMonitoringIfNecessary()
        {
            if (world == null)
                return;
            
            StartMonitoringOfActiveCellBoundary();

            if (activeGridState.monitorInnerAreaBoundaries || (world.IsWorldOriginCentered && activeGridState.monitorWorldShiftBoundaries))
                StartMonitoringOfInnerAreaAndWorldShiftBoundaries();
        }

        void SetupInnerAreaAndShiftBoundaryMonitors()
        {
            SetupInnerAreaBoundary();

            if (world.IsWorldOriginCentered)
                SetupWorldShiftBoundary();
            else
            {
                boundaryMonitor.SetStaticBoundaryMonitoringInfo(innerAreaAndWorldShiftBoundaryMonitorID, null, null);
                boundaryMonitor.DisableStaticBoundaryMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);
            }
        }

       

        void SetupWorldShiftBoundary()
        {
            worldShiftBoundary = world.WorldShiftBoundary;
            boundaryMonitor.SetStaticBoundaryMonitoringInfo(innerAreaAndWorldShiftBoundaryMonitorID, worldShiftBoundary, world.MethodToCallWhenWorldShiftBoundaryCrossed);

            if (activeGridState.monitorWorldShiftBoundaries)
                boundaryMonitor.EnableStaticBoundaryMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);
        }

        void SetupInnerAreaBoundary()
        {
            if (innerAreaBoundary == null)
                innerAreaBoundary = new Boundary(world.WorldGrid.WorldType);
            else
                innerAreaBoundary.ChangeWorldType(world.WorldGrid.WorldType);

            boundaryMonitor.SetDynamicBoundaryMonitoringInfo(innerAreaAndWorldShiftBoundaryMonitorID, innerAreaBoundary, MethodToCallWhenInnerAreaBoundaryCrossed);

            if (activeGridState.monitorInnerAreaBoundaries)
            {
                SetFirstAndLastCellInInnerArea();
                activeGridTypeSpecificLogic.CalculateInnerAreaBoundaries();
                boundaryMonitor.EnableDynamicBoundaryMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);
            }
        }
        
        //make sure Active Cell is valid before calling this method
        void SetupActiveCellBoundary()
        {
            if (activeCellBoundary == null)
                activeCellBoundary = new Boundary(world.WorldGrid.WorldType);
            else
                activeCellBoundary.ChangeWorldType(world.WorldGrid.WorldType);

            boundaryMonitor.SetDynamicBoundaryMonitoringInfo(activeCellBoundaryMonitorID, activeCellBoundary, MethodToCallWhenActiveCellBoundaryCrossed);

            Vector3 positionOfActiveCell;
            CellDimensions dimensionsOfActiveCell;

            world.GetPositionAndDimensionsOfEndlessGridCell_ZeroBased
            (
                activeCell, 
                out positionOfActiveCell, 
                out dimensionsOfActiveCell
            );

            activeCellBoundary.SetWestSouthAndBottomBoundaries(positionOfActiveCell);
            activeCellBoundary.SetEastNorthAndTopBoundaries(positionOfActiveCell, dimensionsOfActiveCell);

            boundaryMonitor.EnableDynamicBoundaryMonitoring(activeCellBoundaryMonitorID);
        }

        void CreateBoundaryMonitorIfNull()
        {
            if (boundaryMonitor != null)
                return;

            if (!componentManager.suppressWarnings)
                Debug.LogWarning("Active Grid with ID " + ID + " requires a Boundary Monitor, but no boundary monitor was found. A Boundary Monitor with a detection frequency of 5 second was created.");

            boundaryMonitor = gameObject.AddComponent<BoundaryMonitor>();
            boundaryMonitor.UpdateDetectionFrequency(5f);
        }

       

        
        
        

        void SetFirstAndLastCellInInnerArea()
        {
            activeGridState.firstCellInInnerArea = activeGridCells.FirstCellInInnerArea;
            activeGridState.lastCellInInnerArea = activeGridCells.LastCellInInnerArea;
        }

        void RemoveClaimOnCurrentCells()
        {
            activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToRemoveUsersFrom);
            world.RemoveCellUsers_ZeroBased(cellsToRemoveUsersFrom);
            cellsToRemoveUsersFrom.Clear();
        }

        void ResetPrimaryCellIndexes()
        {
            Cell primaryCellInGrid;
            if (activeGridType == ActiveGridType.Outer_Ring_Grid)
                primaryCellInGrid = ((OuterRingActiveGridCells)activeGridCells).FirstCellInGroup;
            else
                primaryCellInGrid = activeGridCells.FirstCellInInnerArea;

            activeGridState.primaryCellLayer = primaryCellInGrid.layer + 1;
            activeGridState.primaryCellRow = primaryCellInGrid.row + 1;
            activeGridState.primaryCellColumn = primaryCellInGrid.column + 1;
        }

        void FindSectionPositionIsIn(Cell cellSectionIsIn, Vector3 position, out int layerOfSection, out int rowOfSection, out int columnOfSection, World world)
        {
            Vector3 positionOfCell;
            CellDimensions dimensionsOfCell;

            world.GetPositionAndDimensionsOfEndlessGridCell_ZeroBased(cellSectionIsIn,
                                                            out positionOfCell,
                                                            out dimensionsOfCell);

            if (world.WorldGrid.WorldType == WorldType.Two_Dimensional_On_XY_Axes)
                rowOfSection = position.y < (positionOfCell.y + (.5f * dimensionsOfCell.length)) ? 0 : 1;
            else
                rowOfSection = position.z < (positionOfCell.z + (.5f * dimensionsOfCell.length)) ? 0 : 1;

            columnOfSection = position.x < (positionOfCell.x + (.5f * dimensionsOfCell.width)) ? 0 : 1;

            if (world.WorldGrid.WorldType == WorldType.Three_Dimensional)
            {
                layerOfSection = position.y < (positionOfCell.y + (.5f * dimensionsOfCell.height)) ? 0 : 1;
            }
            else
                layerOfSection = 0;
        }

        void SetSectionPlayerIsIn(Cell cellPlayerIsIn)
        {
            FindSectionPositionIsIn(cellPlayerIsIn, player.position, out activeGridState.layerOfSection, out activeGridState.rowOfSection, out activeGridState.columnOfSection, world);
        }

        #endregion

        #region State Saving/Loading

        internal void SetStateFromSaveData(string saveData, TryGet<int, World> TryGetWorldByIDFunction)
        {
            string[] data = saveData.Split(';');

            if (player != null && data.Length == 2)
                SetPlayerPosition(data[1]);

            bool foundWorldInSaveData;
            activeGridState.SetStateFromStringData(data[0], out foundWorldInSaveData);
            if (foundWorldInSaveData)
            {
                if (!TryGetWorldByIDFunction(activeGridState.idOfSyncedToWorld, out world))
                    throw new MissingComponentException(string.Format("Setting state from save data on The Active Grid with ID {0} failed. The grid was synced to the persistent World with ID {1}, but no world with that ID could be found in the scene. The most likely reason is that the World was an inspector created World and you removed it. This is not allowed. Save Data is corrupted.", activeGridID, activeGridState.idOfSyncedToWorld));
            }
            else
                world = null;

            persistentDataSet = true;
        }

        void SetPlayerPosition(string playerPositionData)
        {
            string[] positions = playerPositionData.Split('/');
            float xPosition = float.Parse(positions[0], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            float yPosition = float.Parse(positions[1], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            float zPosition = float.Parse(positions[2], System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            player.position = new Vector3(xPosition, yPosition, zPosition);
        }

        /// <summary>
        /// Gets the Active Grids persistent save data in the form of a string. This string can be used to
        /// maintain the grids state between game sessions. This is done by loading the string via the
        /// <see cref="SetStateFromSaveData(string, TryGet&lt;int, World&gt;)" href="#SetStateFromSaveData1">
        /// SetStateFromSaveData(string, TryGet&lt;int, World&gt;)
        /// </see> method. If no string builder is provided, one is created.
        /// <para>
        /// It is unlikely that you will ever need to call this method yourself, as the 
        /// <see cref="ComponentManager" href = "ComponentManager.html">ComponentManager</see> handles
        /// persistent data saving/loading automatically.
        /// </para>
        /// </summary>
        /// <param name="stringBuilder" type = "StringBuilder">
        /// An optional stringbuilder. This allows you to provide a reusable string builder to reduce
        /// some garbage generation.
        /// </param>
        /// <displayName id ="GetPersistentStringSaveData">
        /// GetPersistentStringSaveData([StringBuilder])
        /// </displayName>
        /// <syntax>
        /// public string GetPersistentStringSaveData(StringBuilder stringBuilder = null)
        /// </syntax>
        /// <returns type = "string">
        /// The persistent save data in the form of a string.
        /// </returns>
        public string GetPersistentStringSaveData(StringBuilder stringBuilder = null)
        {
            if (stringBuilder == null)
                stringBuilder = new StringBuilder();
            else if (stringBuilder.Length > 0)
                stringBuilder.Length = 0;

            AppendPersistentDataToStringBuilder(stringBuilder);
            
            return stringBuilder.ToString();
        }

        internal void AppendPersistentDataToStringBuilder(StringBuilder stringBuilder)
        {
            activeGridState.AppendDataToStringBuilder(stringBuilder, world == null ? false : world.IsWorldPersistent);
            if (player != null)
            {
                stringBuilder.Append(";");
                AppendPlayerPositionDataToStringBuilder(stringBuilder);
            }
        }

        void AppendPlayerPositionDataToStringBuilder(StringBuilder stringBuilder)
        {
            Vector3 playerPosition = player.position;
            if (IsBusy && activeGridState.completeActionNextSessionIfGameExitsBeforeActionCompletes)
            {
                //If the player has not already been moved, adjust his position
                if(!activeGridState.playerMovedDuringMultiFrameAction)
                {
                    if (activeGridState.multiFrameActionType == MultiFrameActionType.WorldShift)
                        playerPosition += activeGridState.amountToMoveGridOrPositionToMoveGridTo;
                    else if (activeGridState.multiFrameActionType == MultiFrameActionType.MoveToLocation || activeGridState.multiFrameActionType == MultiFrameActionType.MoveToLocationAndSyncToNewWorld)
                        playerPosition = activeGridState.amountToMoveGridOrPositionToMoveGridTo;
                }
            }

            stringBuilder.Append(playerPosition.x);
            stringBuilder.Append('/');
            stringBuilder.Append(playerPosition.y);
            stringBuilder.Append('/');
            stringBuilder.Append(playerPosition.z);
        }
        
        internal void ChangeActiveGridState(ActiveGridState newActiveGridState)
        {
            activeGridState = newActiveGridState;
        }
        #endregion

        #region Destruction
        
        internal void DestroyImmediately()
        {
            PrepareForDestruction();
            Destroy(this);
        }

        internal IEnumerator<YieldInstruction> DestroyAfterRemovingAllCellUsers()
        {
            persistent = false;
            if (boundaryMonitor != null)
            {
                boundaryMonitor.DeRegister(innerAreaAndWorldShiftBoundaryMonitorID);
                boundaryMonitor = null;
            }

            if (activeGridState.cellObjectsLoaded)
            {
                activeGridState.cellObjectsLoaded = false;
                if (activeGridCells != null && world != null)
                {
                    activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToRemoveUsersFrom);
                    IEnumerator<YieldInstruction> removeEnumerator = world.RemoveCellUsers_ZeroBasedAndWaitForCellObjectsToBeUnloaded(cellsToRemoveUsersFrom);

                    world.DeRegister(worldRegistrationID);
                    
                    activeGridCells = null;
                    world = null;
                    
                    while (removeEnumerator.MoveNext())
                        yield return removeEnumerator.Current;
                }
            }
            Destroy(this);
        }

        //Just in case this component is destroyed via some other method than the two methods above
        void OnDestroy()
        {
            PrepareForDestruction();
        }

        void PrepareForDestruction()
        {
            if (activeGridState.cellObjectsLoaded)
            {
                if (activeGridCells != null && world != null)
                {
                    activeGridTypeSpecificLogic.GetAllCellsThatNeedOrHaveObjects(cellsToRemoveUsersFrom);
                    world.RemoveCellUsers_ZeroBased(cellsToRemoveUsersFrom);
                    world.DeRegister(worldRegistrationID);

                    activeGridCells = null;
                    world = null;
                }
                activeGridState.cellObjectsLoaded = false;
            }

            if (boundaryMonitor != null)
            {
                boundaryMonitor.DeRegister(innerAreaAndWorldShiftBoundaryMonitorID);
                boundaryMonitor = null;
            }
        }

        #endregion

        #region Interface Implementations for IWorldUser interface

        void IWorldUser.OnWorldDestroyed()
        {
            if (boundaryMonitor != null)
            {
                boundaryMonitor.SetDynamicBoundaryMonitoringInfo(innerAreaAndWorldShiftBoundaryMonitorID, null, null);
                boundaryMonitor.DisableDynamicBoundaryMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);

                if (world.IsWorldOriginCentered)
                {
                    boundaryMonitor.SetStaticBoundaryMonitoringInfo(innerAreaAndWorldShiftBoundaryMonitorID, null, null);
                    boundaryMonitor.DisableStaticBoundaryMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);
                }

                boundaryMonitor.StopMonitoring(innerAreaAndWorldShiftBoundaryMonitorID);
            }

            activeGridState.cellObjectsLoaded = false;
            world = null;
        }

        void IWorldUser.OnWorldShifted(Vector3 shiftAmount, Cell newOriginCell, Cell endlessGridResetAddition) { }

        void IWorldUser.OnOriginCellChanged(Cell newOriginCell) 
        {
            activeGridState.waitingOnCellOriginUpdate = false;
        }
        #endregion
    }
}