﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using DynamicLoadingKit;
    using UnityEngine;
    using UnityEditor;

    public class ManagerDependencyConfigurer
    {
        GameObject manager;
        public ManagerDependencyConfigurer(GameObject manager)
        {
            this.manager = manager;
        }

        public void ConfigureDependencies()
        {
            SerializedObject componentManager = new SerializedObject(manager.GetComponent<ComponentManager>());
            SerializedObject world = new SerializedObject(manager.GetComponent<World>());
            SerializedObject activeGrid = new SerializedObject(manager.GetComponent<ActiveGrid>());
            SerializedObject persistentDataController = new SerializedObject(manager.GetComponent<PlayerPrefsPersistentDataController>());
            SerializedObject boundaryMonitor = new SerializedObject(manager.GetComponent<BoundaryMonitor>());
            SerializedObject subController = new SerializedObject(manager.GetComponent<PrimaryCellObjectSubController>());
            SerializedObject cellObjectLoader = new SerializedObject(manager.GetComponent<CellObjectLoader>());

            componentManager.Update();
            world.Update();
            activeGrid.Update();
            persistentDataController.Update();
            boundaryMonitor.Update();
            subController.Update();
            cellObjectLoader.Update();

            if (componentManager != null)
                componentManager.FindProperty("persistentDataController").objectReferenceValue = persistentDataController.targetObject;

            if (subController != null)
                subController.FindProperty("cellObjectLoader").objectReferenceValue = cellObjectLoader.targetObject;

            if (world != null)
                world.FindProperty("primaryCellObjectSubController").objectReferenceValue = subController.targetObject;

            if (activeGrid != null)
            {
                activeGrid.FindProperty("boundaryMonitor").objectReferenceValue = boundaryMonitor.targetObject;
                activeGrid.FindProperty("world").objectReferenceValue = world.targetObject;
            }

            componentManager.ApplyModifiedProperties();
            world.ApplyModifiedProperties();
            activeGrid.ApplyModifiedProperties();
            persistentDataController.ApplyModifiedProperties();
            boundaryMonitor.ApplyModifiedProperties();
            subController.ApplyModifiedProperties();
            cellObjectLoader.ApplyModifiedProperties();
        }
    }
}