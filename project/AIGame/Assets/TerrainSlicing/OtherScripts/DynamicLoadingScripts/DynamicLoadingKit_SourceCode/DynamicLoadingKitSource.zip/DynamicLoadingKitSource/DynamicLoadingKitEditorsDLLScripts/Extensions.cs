//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKitEditors
{
    using System;
	using UnityEditor;
	using UnityEngine;
	using DynamicLoadingKit;
    

	internal static class DLKExtensions
	{
        internal static bool AreAllValuesTrue(this bool[] values)
        {
            for (int i = 0; i < values.Length; i++)
                if (values[i] == false) return false;
                    
            return true;
        }

        internal static void SetAllValuesToSingleValue<T>(this T[] values, T singleValue)
        {
            for (int i = 0; i < values.Length; i++)
                values[i] = singleValue;
        }

        internal static T[] RemoveAt<T>(this T[] source, int index)
        {
            T[] dest = new T[source.Length - 1];
            if (index > 0)
                Array.Copy(source, 0, dest, 0, index);

            if (index < source.Length - 1)
                Array.Copy(source, index + 1, dest, index, source.Length - index - 1);

            return dest;
        }

        internal static bool DoAllBoolValuesMatchInputVaue(this SerializedProperty boolArrayProperty, bool input)
        {
            int arrSize = boolArrayProperty.arraySize;
            for(int i = 0; i < arrSize; i++)
            {
                if (boolArrayProperty.GetArrayElementAtIndex(i).boolValue != input)
                    return false;
            }
            return true;
        }

        internal static void CopyBoolArrayToBoolArrayProperty(this SerializedProperty boolArrayProperty, bool[] arr, bool resize)
        {
            if (resize)
                boolArrayProperty.arraySize = arr.Length;

            for (int i = 0; i < arr.Length; i++)
                boolArrayProperty.GetArrayElementAtIndex(i).boolValue = arr[i];
        }

        internal static T[] Convert2DArrayTo1DArray<T>(this T[,] arr_2D)
        {
            T[] arr_1D = new T[arr_2D.GetLength(0) * arr_2D.GetLength(1)];

            int i = 0;
            for (int row = 0; row < arr_2D.GetLength(0); row++)
            {
                for (int col = 0; col < arr_2D.GetLength(1); col++)
                {
                    arr_1D[i] = arr_2D[row, col];
                    i++;
                }
            }
            return arr_1D;
        }

        internal static T[,] Convert1DArrayTo2DArray<T>(this T[] arr_1D, int rows, int columns)
        {
            T[,] arr_2D = new T[rows, columns];

            int i = 0;
            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < columns; col++)
                {
                    arr_2D[row, col] = arr_1D[i];
                    i++;
                }
            }
            return arr_2D;
        }

        internal static void ResizeBoolArrayAndSetAllValuesToSingleValue(this SerializedProperty boolArrayProperty, int size, bool value)
        {
            boolArrayProperty.arraySize = size;
            
            for (int i = 0; i < size; i++)
                boolArrayProperty.GetArrayElementAtIndex(i).boolValue = value;
        }

        internal static void RebuildBoolArrayForNewWorldDimensions(this SerializedProperty boolArrayProperty, bool valueToSetNewElementsTo, int newNumLayers, int newNumRows, int newNumColumns, int oldNumLayers, int oldNumRows, int oldNumColumns)
        {
            if (boolArrayProperty.arraySize != 0)
            {
                if (boolArrayProperty.arraySize == 1)
                {
                    //In this case, we need to determine whether they can continue 
                    //to be represented by a single value
                    //or do we need to recreate the full array.
                    //(if all values are same, then they can be represented by a single value).

                    if ((newNumRows > oldNumRows || newNumColumns > oldNumColumns || newNumLayers > oldNumLayers) && boolArrayProperty.GetArrayElementAtIndex(0).boolValue != valueToSetNewElementsTo)
                    {
                        boolArrayProperty.arraySize = newNumRows * newNumColumns * newNumLayers;

                        //go through the array and set the old elements to true and new elements to false
                        for (int l = 0; l < newNumLayers; l++)
                        {
                            for (int r = 0; r < newNumRows; r++)
                            {
                                for (int c = 0; c < newNumColumns; c++)
                                {
                                    bool oldElement = r < oldNumRows && c < oldNumColumns && l < oldNumLayers;
                                    bool valueToSet;
                                    if (oldElement)
                                        valueToSet = !valueToSetNewElementsTo;
                                    else
                                        valueToSet = valueToSetNewElementsTo;

                                    boolArrayProperty.GetArrayElementAtIndex(c + (r * newNumColumns) + (newNumRows * newNumColumns * l)).boolValue = valueToSet;
                                }
                            }
                        }
                    }
                }
                else
                {
                    bool[] newArray = new bool[newNumRows * newNumColumns * newNumLayers];
                    for (int i = 0; i < newArray.Length; i++)
                        newArray[i] = true;

                    for (int l = 0; l < oldNumLayers; l++)
                    {
                        for (int r = 0; r < oldNumRows; r++)
                        {
                            for (int c = 0; c < oldNumColumns; c++)
                            {
                                if (l < newNumLayers && r < newNumRows && c < newNumColumns)
                                {
                                    newArray[c + (r * newNumColumns) + (newNumRows * newNumColumns * l)] = boolArrayProperty.GetArrayElementAtIndex(c + (r * oldNumColumns) + (oldNumRows * oldNumColumns * l)).boolValue;
                                }
                            }
                        }
                    }

                    boolArrayProperty.CopyBoolArrayToBoolArrayProperty(newArray, true);

                    if (boolArrayProperty.DoAllBoolValuesMatchInputVaue(true))
                    {
                        //if they are the same, store as single value
                        boolArrayProperty.arraySize = 1;
                        boolArrayProperty.GetArrayElementAtIndex(0).boolValue = true;
                    }
                    else if (boolArrayProperty.DoAllBoolValuesMatchInputVaue(false))
                    {
                        //if they are the same, store as single value
                        boolArrayProperty.arraySize = 1;
                        boolArrayProperty.GetArrayElementAtIndex(0).boolValue = false;
                    }
                }
            }
            else
            {
                boolArrayProperty.arraySize = 1;
                boolArrayProperty.GetArrayElementAtIndex(0).boolValue = valueToSetNewElementsTo;
            }
        }

        internal static void SetRowInBoolArray(this SerializedProperty boolArrayProperty, bool value, int row, int layer, int numLayers, int numRows, int numColumns)
        {
            int totalCells = numRows * numColumns * numLayers;
            if (totalCells != 1 && boolArrayProperty.arraySize == 1)
            {
                if (boolArrayProperty.GetArrayElementAtIndex(0).boolValue != value)
                {
                    boolArrayProperty.ResizeBoolArrayAndSetAllValuesToSingleValue(totalCells, boolArrayProperty.GetArrayElementAtIndex(0).boolValue);
                    boolArrayProperty.SetRowInBoolArray(value, row, layer, numLayers, numRows, numColumns);
                }
            }
            else
            {
                for (int column = 0; column < numColumns; column++)
                    boolArrayProperty.GetArrayElementAtIndex(column + (row * numColumns) + (numRows * numColumns * layer)).boolValue = value;

                //only possible for all cells to match the input value, so check for this
                if (totalCells != 1 && boolArrayProperty.DoAllBoolValuesMatchInputVaue(value))
                {
                    boolArrayProperty.arraySize = 1;
                    boolArrayProperty.GetArrayElementAtIndex(0).boolValue = value;
                }
            }
        }

        internal static void SetColumnInBoolArray(this SerializedProperty boolArrayProperty, bool value, int column, int layer, int numLayers, int numRows, int numColumns)
        {
            int totalCells = numRows * numColumns * numLayers;
            if (totalCells != 1 && boolArrayProperty.arraySize == 1)
            {
                if (boolArrayProperty.GetArrayElementAtIndex(0).boolValue != value)
                {
                    boolArrayProperty.ResizeBoolArrayAndSetAllValuesToSingleValue(totalCells, boolArrayProperty.GetArrayElementAtIndex(0).boolValue);
                    boolArrayProperty.SetColumnInBoolArray(value, column, layer, numLayers, numRows, numColumns);
                }
            }
            else
            {
                for (int row = 0; row < numRows; row++)
                    boolArrayProperty.GetArrayElementAtIndex(column + (row * numColumns) + (numRows * numColumns * layer)).boolValue = value;

                //only possible for all cells to match the input value, so check for this
                if (totalCells != 1 && boolArrayProperty.DoAllBoolValuesMatchInputVaue(value))
                {
                    boolArrayProperty.arraySize = 1;
                    boolArrayProperty.GetArrayElementAtIndex(0).boolValue = value;
                }
            }
        }

        internal static void SetLayerInBoolArray(this SerializedProperty boolArrayProperty, bool value, int layer, int numLayers, int numRows, int numColumns)
        {
            int totalCells = numRows * numColumns * numLayers;
            if (totalCells != 1 && boolArrayProperty.arraySize == 1)
            {
                if (boolArrayProperty.GetArrayElementAtIndex(0).boolValue != value)
                {
                    boolArrayProperty.ResizeBoolArrayAndSetAllValuesToSingleValue(totalCells, boolArrayProperty.GetArrayElementAtIndex(0).boolValue);
                    boolArrayProperty.SetLayerInBoolArray(value, layer, numLayers, numRows, numColumns);
                }
            }
            else
            {
                for (int row = 0; row < numRows; row++)
                {
                    for (int column = 0; column < numColumns; column++)
                    {
                        boolArrayProperty.GetArrayElementAtIndex(column + (row * numColumns) + (numRows * numColumns * layer)).boolValue = value;
                    }
                }

                //only possible for all cells to match the input value, so check for this
                if (totalCells != 1 && boolArrayProperty.DoAllBoolValuesMatchInputVaue(value))
                {
                    boolArrayProperty.arraySize = 1;
                    boolArrayProperty.GetArrayElementAtIndex(0).boolValue = value;
                }
            }
        }

        internal static bool AreAllBoolsInRowEqualToValue(this SerializedProperty boolArrayProperty, bool value, int row, int layer, int numRows, int numColumns)
        {
            if (boolArrayProperty.arraySize == 1 && boolArrayProperty.GetArrayElementAtIndex(0).boolValue == value)
                return true;

            for (int column = 0; column < numColumns; column++)
            {
                if (boolArrayProperty.GetArrayElementAtIndex(column + (row * numColumns) + (numRows * numColumns * layer)).boolValue != value)
                    return false;
            }

            return true;
        }

        internal static bool AreAllBoolsInColumnEqualToValue(this SerializedProperty boolArrayProperty, bool value, int column, int layer, int numRows, int numColumns)
        {
            if (boolArrayProperty.arraySize == 1 && boolArrayProperty.GetArrayElementAtIndex(0).boolValue == value)
                return true;

            for (int row = 0; row < numRows; row++)
            {
                if (boolArrayProperty.GetArrayElementAtIndex(column + (row * numColumns) + (numRows * numColumns * layer)).boolValue != value)
                    return false;
            }

            return true;
        }
        
        internal static bool AreAllBoolsInLayerEqualToValue(this SerializedProperty boolArrayProperty, bool value, int layer, int numRows, int numColumns)
        {
            if (boolArrayProperty.arraySize == 1 && boolArrayProperty.GetArrayElementAtIndex(0).boolValue == value)
                return true;

            for (int row = 0; row < numRows; row++)
            {
                for (int column = 0; column < numColumns; column++)
                {
                    if (boolArrayProperty.GetArrayElementAtIndex(column + (row * numColumns) + (numRows * numColumns * layer)).boolValue != value)
                        return false;
                }
            }
            return true;
        }

        internal static float ComputeAverage(this SerializedProperty floatArrayProperty)
        {
            int arrSize = floatArrayProperty.arraySize;

            if (arrSize == 0)
                return 0f;

            
            float totalLength = 0f;
            for (int i = 0; i < arrSize; i++)
                totalLength += floatArrayProperty.GetArrayElementAtIndex(i).floatValue;

            return totalLength / arrSize;
        }

        internal static bool AreAllFlaotValuesTheSame(this SerializedProperty floatArrayProperty)
        {
            float firstValue = floatArrayProperty.GetArrayElementAtIndex(0).floatValue;
            for (int i = 1; i < floatArrayProperty.arraySize; i++)
            {
                if (!Mathf.Approximately(floatArrayProperty.GetArrayElementAtIndex(i).floatValue, firstValue))
                    return false;
            }
            return true;
        }

        internal static void ResizeFloatArrayAndSetAllValuesToSingleValue(this SerializedProperty floatArrayProperty, int size, float value)
        {
            floatArrayProperty.arraySize = size;
            for (int i = 0; i < size; i++)
                floatArrayProperty.GetArrayElementAtIndex(i).floatValue = value;
        }

        internal static void CopyFloatArrayToFloatArrayProperty(this SerializedProperty floatArrayProperty, float[] arr, bool resize)
        {
            if (resize)
                floatArrayProperty.arraySize = arr.Length;

            for (int i = 0; i < arr.Length; i++)
                floatArrayProperty.GetArrayElementAtIndex(i).floatValue = arr[i];
        }
    }
}