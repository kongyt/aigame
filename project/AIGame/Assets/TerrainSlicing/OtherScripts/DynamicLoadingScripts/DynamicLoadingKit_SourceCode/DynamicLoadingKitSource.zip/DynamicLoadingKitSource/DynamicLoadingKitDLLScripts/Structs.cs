//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace DynamicLoadingKit
{
	using UnityEngine;	
	
    /// <summary>
    /// Represents a cell on a grid.
    /// </summary>
    /// <title>Cell Structure</title>
    /// <category>Structs</category>
    /// <navigationName>Cell</navigationName>
    /// <fileName>Cell.html</fileName>
    /// <syntax>public struct Cell</syntax>
	public struct Cell
	{
        internal int layer, row, column;

        /// <summary>
        /// Initializes a new instance of the Cell structure.
        /// </summary>
        /// <param name="row" type="int">The row index of the cell.</param>
        /// <param name="column" type="int">The column index of the cell.</param>
        /// <param name="layer" type="int">The layer index of the cell. Only needed when the cell is associated with a three dimensional entity, otherwise just pass in 1.</param>
        /// <displayName id="Cell">Cell(int, int, int)</displayName>
        /// <syntax>public Cell(int row, int column, int layer)</syntax>
        public Cell(int row, int column, int layer)
        {
            this.layer = layer;
            this.row = row;
            this.column = column;
        }

        internal Cell(int row, int column)
        {
            this.layer = 0;
            this.row = row;
            this.column = column;
        }

        /// <summary>
        /// Gets the column index of the cell.
        /// </summary>
        /// <type>int</type>
        public int Column { get { return column; } }

        /// <summary>
        /// Gets the layer index of the cell.
        /// </summary>
        /// <type>int</type>
        public int Layer    { get { return layer; } }

        /// <summary>
        /// Gets the row index of the cell.
        /// </summary>
        /// <type>int</type>
        public int Row      { get { return row; } }

        /// <summary>
        /// Returns a nicely formatted string representation of the Cell's Indexes.
        /// </summary>
        /// <displayName id="ToString">ToString()</displayName>
        /// <syntax>public override string ToString()</syntax>
        /// <returns>A string representation of the Cell's Indexes.</returns>
        public override string ToString()
        {
            return string.Format("Row = {0}, Column = {1}, Layer = {2}", row, column, layer);
        }

        public static Cell operator +(Cell cell1, Cell cell2)
        {
            return new Cell(cell1.Row + cell2.Row, cell1.Column + cell2.Column, cell1.Layer + cell2.Layer);
        }

        public static Cell operator -(Cell cell1, Cell cell2)
        {
            return new Cell(cell1.Row - cell2.Row, cell1.Column - cell2.Column, cell1.Layer - cell2.Layer);
        }

        public static bool operator ==(Cell cell1, Cell cell2)
        {
            return cell1.Row == cell2.Row && cell1.Column == cell2.Column && cell1.Layer == cell2.Layer;
        }

        public static bool operator !=(Cell cell1, Cell cell2)
        {
            return cell1.Row != cell2.Row || cell1.Column != cell2.Column || cell1.Layer != cell2.Layer;
        }

        public override bool Equals(object obj)
        {
            Cell objCell = (Cell)obj;
            return Row == objCell.Row && Column == objCell.Column && Layer == objCell.Layer;
        }

        public override int GetHashCode()
        {
            int hash = 23 * 31 + layer;
            hash = hash * 31 + row;
            hash = hash * 31 + column;

            return hash;
        }
    }

    /// <summary>
    /// Represents the dimensions of a <see cref="Cell" href="Cell.html">Cell</see>.
    /// </summary>
    /// <title>CellDimensions Structure</title>
    /// <category>Structs</category>
    /// <navigationName>CellDimensions</navigationName>
    /// <fileName>CellDimensions.html</fileName>
    /// <syntax>public struct CellDimensions</syntax>
    public struct CellDimensions
    { 
        /// <summary>
        /// The height of the cell. This is only relevant when the cell in question is associated with a three dimensional entity.
        /// </summary>
        /// <type>readonly float</type>
        /// <defaultValue>Does Not Apply</defaultValue>
        public readonly float height;

        /// <summary>
        /// The length of the cell.
        /// </summary>
        /// <type>readonly float</type>
        /// <defaultValue>Does Not Apply</defaultValue>
        public readonly float length;

        /// <summary>
        /// The width of the cell.
        /// </summary>
        /// <type>readonly float</type>
        /// <defaultValue>Does Not Apply</defaultValue>
        public readonly float width;

        /// <summary>
        /// Initializes a new instance of the CellDimension structure with height set to 0.
        /// </summary>
        /// <param name="length" type="float">The length of the cell.</param>
        /// <param name="width" type="float">The width of the cell.</param>
        /// <displayName id="">CellDimensions(float, float)</displayName>
        /// <syntax>public CellDimensions(float length, float width)</syntax>
        public CellDimensions(float length, float width)
        {
            this.height = 0f;
            this.length = length;
            this.width = width;
        }

        /// <summary>
        /// Initializes a new instance of the CellDimension structure.
        /// </summary>
        /// <param name="height" type="float">The height of the cell. This is only relevant when the cell in question is associated with a three dimensional entity.</param>
        /// <param name="length" type="float">The length of the cell.</param>
        /// <param name="width" type="float">The width of the cell.</param>
        /// <displayName id="">CellDimensions(float, float, float)</displayName>
        /// <syntax>public CellDimensions(float height, float length, float width)</syntax>
        public CellDimensions(float height, float length, float width)
        {
            this.height = height;
            this.length = length;
            this.width = width;
        }        
    }

    /// <summary>
    /// Represents a generic collection of values for a row, column, and layer. This class is used internally in several areas, but you will 
    /// probably never need to use it yourself, unless you are writing some custom code and want the convenience it offers.
    /// </summary>
    /// <title>GridValues&lt;T&gt; Structure</title>
    /// <category>Structs</category>
    /// <navigationName>GridValues</navigationName>
    /// <fileName>GridValues.html</fileName>
    /// <syntax>public struct GridValues&lt;T&gt;</syntax>
    public struct GridValues<T>
    {
        /// <summary>
        /// The column value.
        /// </summary>
        /// <type>readonly T</type>
        /// <defaultValue>Does Not Apply</defaultValue>
        public readonly T columnValue;

        /// <summary>
        /// The layer value.
        /// </summary>
        /// <type>readonly T</type>
        /// <defaultValue>Does Not Apply</defaultValue>
        public readonly T layerValue;

        /// <summary>
        /// The row value.
        /// </summary>
        /// <type>readonly T</type>
        /// <defaultValue>Does Not Apply</defaultValue>
        public readonly T rowValue;

        /// <summary>
        /// Initializes a new instance of the GridValues structure.
        /// </summary>
        /// <param name="layerValue" type = "T">The layer value that the structure should hold.</param>
        /// <param name="rowValue" type = "T">The row value that the structure should hold.</param>
        /// <param name="columnValue" type = "T">The column value that the structure should hold.</param>
        /// <displayName id="">GridValues(T, T, T)</displayName>
        /// <syntax>public GridValues(T layerValue, T rowValue, T columnValue)</syntax>
        public GridValues(T layerValue, T rowValue, T columnValue)
        {
            this.layerValue = layerValue;
            this.rowValue = rowValue;
            this.columnValue = columnValue;
        }
    }

    /// <summary>
    /// Represents the dimensions of an <see cref="ActiveGrid" href="ActiveGrid.html">Active Grid</see>.
    /// </summary>
    /// <title>ActiveGridDimensions Structure</title>
    /// <category>Structs</category>
    /// <navigationName>ActiveGridDimensions</navigationName>
    /// <fileName>ActiveGridDimensions.html</fileName>
    /// <syntax>public struct ActiveGridDimensions</syntax>
	public struct ActiveGridDimensions
	{
        /// <summary>
        /// The number of columns in the inner area of the Active Grid.
        /// </summary>
        /// <type>readonly int</type>
        /// <defaultValue>Does Not Apply</defaultValue>
        public readonly int innerAreaColumns;

        /// <summary>
        /// The number of layers in the inner area of the Active Grid. Only relevant when the grid is associated with a three dimensional World or other entity.
        /// </summary>
        /// <type>readonly int</type>
        /// <defaultValue>Does Not Apply</defaultValue>
        public readonly int innerAreaLayers;

        /// <summary>
        /// The number of rows in the inner area of the Active Grid.
        /// </summary>
        /// <type>readonly int</type>
        /// <defaultValue>Does Not Apply</defaultValue>
        public readonly int innerAreaRows;

        /// <summary>
        /// The width of the ring of cells that surrounds the inner area of the Active Grid.
        /// </summary>
        /// <type>readonly int</type>
        /// <defaultValue>Does Not Apply</defaultValue>
        public readonly int outerRingWidth;

        /// <summary>
        /// Initializes a new instance of the ActiveGridDimensions structure.
        /// </summary>
        /// <param name="innerAreaLayers" type="int">The number of layers in the inner area of the Active Grid. Only relevant when the grid is associated with a three dimensional World or other entity.</param>
        /// <param name="innerAreaRows" type="int">The number of rows in the inner area of the Active Grid.</param>
        /// <param name="innerAreaColumns" type="int">The number of columns in the inner area of the Active Grid.</param>
        /// <param name="outerRingWidth" type="int">The width of the ring of cells that surrounds the inner area of the Active Grid.</param>
        /// <displayName id="">ActiveGridDimensions(int, int, int, int)</displayName>
        /// <syntax>public ActiveGridDimensions(int innerAreaLayers, int innerAreaRows, int innerAreaColumns, int outerRingWidth)</syntax>
        public ActiveGridDimensions(int innerAreaLayers, int innerAreaRows, int innerAreaColumns, int outerRingWidth)
		{
			this.innerAreaLayers = innerAreaLayers;
			this.innerAreaRows = innerAreaRows;
            this.innerAreaColumns = innerAreaColumns;
            this.outerRingWidth = outerRingWidth;
		}
	}

    ///// <summary>
    ///// Represents a collection of settings specifying how many times a world can repeat on each axis.
    ///// <para>This dictates how many times a world will repeat before the Active Grid resets back to the origin of the world it is synced to.</para>
    ///// </summary>
    ///// <title>EndlessWorldRepeatSettings Structure</title>
    ///// <category>Structs</category>
    ///// <navigationName>EndlessWorldRepeatSettings</navigationName>
    ///// <fileName>EndlessWorldRepeatSettings.html</fileName>
    ///// <syntax>public struct EndlessWorldRepeatSettings</syntax>
    //public struct EndlessWorldRepeatSettings
    //{
    //    /// <summary>
    //    /// The number of times to allow the columns of the world to repeat before resetting.
    //    /// </summary>
    //    /// <type>readonly int</type>
    //    /// <defaultValue>Does Not Apply</defaultValue>
    //    public readonly int columnRepeatsToAllowBeforeResetting;

    //    /// <summary>
    //    /// The number of times to allow the layers of the world to repeat before resetting. This is only relevant when the entity using
    //    /// these repeat settings is associated with a three dimensional entity.
    //    /// </summary>
    //    /// <type>readonly int</type>
    //    /// <defaultValue>Does Not Apply</defaultValue>
    //    public readonly int layerRepeatsToAllowBeforeResetting;

    //    /// <summary>
    //    /// The number of times to allow the rows of the world to repeat before resetting.
    //    /// </summary>
    //    /// <type>readonly int</type>
    //    /// <defaultValue>Does Not Apply</defaultValue>
    //    public readonly int rowRepeatsToAllowBeforeResetting;

    //    /// <summary>
    //    /// Initializes a new instance of the EndlessWorldRepeatSettings structure.
    //    /// </summary>
    //    /// <param name="layerRepeatsToAllowBeforeResetting" type="int">The number of times to allow the layers of the world to repeat before resetting. This is only relevant when the entity using
    //    /// these repeat settings is associated with a three dimensional entity.</param>
    //    /// <param name="rowRepeatsToAllowBeforeResetting" type="int">The number of times to allow the rows of the world to repeat before resetting.</param>
    //    /// <param name="columnRepeatsToAllowBeforeResetting" type="int">The number of times to allow the columns of the world to repeat before resetting.</param>
    //    /// <displayName id="">EndlessWorldRepeatSettings(int, int, int)</displayName>
    //    /// <syntax>public EndlessWorldRepeatSettings(int layerRepeatsToAllowBeforeResetting, int rowRepeatsToAllowBeforeResetting, int columnRepeatsToAllowBeforeResetting)</syntax>
    //    public EndlessWorldRepeatSettings(int layerRepeatsToAllowBeforeResetting, int rowRepeatsToAllowBeforeResetting, int columnRepeatsToAllowBeforeResetting)
    //    {
    //        this.layerRepeatsToAllowBeforeResetting = layerRepeatsToAllowBeforeResetting;
    //        this.rowRepeatsToAllowBeforeResetting = rowRepeatsToAllowBeforeResetting;
    //        this.columnRepeatsToAllowBeforeResetting = columnRepeatsToAllowBeforeResetting;
    //    }
    //}
}