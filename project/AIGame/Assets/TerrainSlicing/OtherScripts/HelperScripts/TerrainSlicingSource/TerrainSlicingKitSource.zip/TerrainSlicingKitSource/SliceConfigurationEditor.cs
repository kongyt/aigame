﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using UnityEditor;
    using UnityEngine;
    using DynamicLoadingKit;

    public class SliceConfigurationEditor
    {
        #region Fields

        GUILayoutOption labelWidth, fieldWidth;
        GUIContent[] sliceMethodOptions;//terrainLocationOptions

        int maxSlicesOnSingleAxis, maxEdgeBlendingWidth = 1, smallestResolution;
        float terrainWidth, terrainLength, normalizedSnapSpread, cutWidth, cutLength, allCutsWidth, allCutsLength;
        Vector3 half;

        SerializedObject serializedObject;
        NestedSerializedObjectHelper helper;

        #endregion

        #region Properties

        //objects
        Terrain SampleTerrain { get { return SampleTerrainProperty.objectReferenceValue as Terrain; } }

        //Serialized Properties
        SerializedProperty SampleTerrainProperty { get { return helper.GetPropertyByName("sampleTerrain"); } }

        #endregion

        #region Constructor
        public SliceConfigurationEditor(SerializedObject serializedObject)
        {
            this.serializedObject = serializedObject;
            helper = new NestedSerializedObjectHelper(serializedObject.FindProperty("sliceConfiguration"));

            //terrainLocationOptions = new GUIContent[2] { terrainLocation_inCurrentScene, terrainLocation_inProjectHiearchy };
            sliceMethodOptions = new GUIContent[2] { sliceMethod_single, sliceMethod_terrainGroup };

            fieldWidth = GUILayout.Width(50f);
            labelWidth = GUILayout.Width(80f);

            serializedObject.Update();
            CalculateDataForTerrain();
        }

        #endregion

        #region Scene Drawing

        public void OnSceneGUI(SceneView sceneView)
        {
            serializedObject.Update();
            if (SampleTerrain == null || helper.GetInt("sliceMethod") == (int)SliceMethod.SliceTerrainGroup)
                return;

            Vector3 currentTerrainPosition = SampleTerrain.transform.position;

            float gridXPositionNonNormalized = CalculateNonNormalizedXPosition(currentTerrainPosition.x);
            float gridZPositionNonNormalized = CalculateNonNormalizedZPosition(currentTerrainPosition.z);
            SerializedProperty gridYOffsetProp = helper.GetPropertyByName("gridYOffset");

            Vector3 gridPositionTemp = Handles.PositionHandle(new Vector3(gridXPositionNonNormalized, currentTerrainPosition.y + gridYOffsetProp.floatValue, gridZPositionNonNormalized) + half, SampleTerrain.transform.rotation) - half;

            float newOffset = gridPositionTemp.y - currentTerrainPosition.y;
            if (!Mathf.Approximately(newOffset, gridYOffsetProp.floatValue))
                gridYOffsetProp.floatValue = newOffset;

            gridXPositionNonNormalized = gridPositionTemp.x;
            if (gridXPositionNonNormalized < currentTerrainPosition.x)
                gridXPositionNonNormalized = currentTerrainPosition.x;
            else if (gridXPositionNonNormalized + allCutsWidth > currentTerrainPosition.x + terrainWidth)
                gridXPositionNonNormalized = (currentTerrainPosition.x + terrainWidth) - allCutsWidth;

            CalculateNormalizedXPosition(gridXPositionNonNormalized - currentTerrainPosition.x);
            SnapGridNormalizedXPosition();

            gridZPositionNonNormalized = gridPositionTemp.z;
            if (gridZPositionNonNormalized < currentTerrainPosition.z)
                gridZPositionNonNormalized = currentTerrainPosition.z;
            else if (gridZPositionNonNormalized + allCutsLength > currentTerrainPosition.z + terrainLength)
                gridZPositionNonNormalized = (currentTerrainPosition.z + terrainLength) - allCutsLength;

            CalculateNormalizedZPosition(gridZPositionNonNormalized - currentTerrainPosition.z);
            SnapGridNormalizedZPosition();

            Handles.color = helper.GetPropertyByName("slicingGridColor").colorValue;
            DrawHorizontalCutGridLines(currentTerrainPosition);
            DrawVerticalCutGridLines(currentTerrainPosition);
            HandleUtility.Repaint();
            serializedObject.ApplyModifiedProperties();
        }

        void DrawHorizontalCutGridLines(Vector3 currentTerrainPosition)
        {
            float x1 = CalculateNonNormalizedXPosition(currentTerrainPosition.x);
            float x2 = x1 + allCutsWidth;
            float z = CalculateNonNormalizedZPosition(currentTerrainPosition.z);
            float zChange = allCutsLength / helper.GetInt("rowsOfSlices");
            float y = currentTerrainPosition.y + helper.GetFloat("gridYOffset");

            for (var i = 0; i <= helper.GetInt("rowsOfSlices"); i++)
            {
                Handles.DrawLine(new Vector3(x1, y, z), new Vector3(x2, y, z));
                z += zChange;
            }
        }

        void DrawVerticalCutGridLines(Vector3 currentTerrainPosition)
        {
            var z1 = CalculateNonNormalizedZPosition(currentTerrainPosition.z);
            var z2 = z1 + allCutsLength;
            var x = CalculateNonNormalizedXPosition(currentTerrainPosition.x);
            var xChange = allCutsWidth / helper.GetInt("columnsOfSlices");
            float y = currentTerrainPosition.y + helper.GetFloat("gridYOffset");
            for (var i = 0; i <= helper.GetInt("columnsOfSlices"); i++)
            {
                Handles.DrawLine(new Vector3(x, y, z1), new Vector3(x, y, z2));
                x += xChange;
            }
        }
        #endregion

        #region GUI
        public void OnInspectorGUI()
        {
            serializedObject.Update();
#if UNITY_4
            EditorGUIUtility.LookLikeControls(200f, 50f);
#else
            EditorGUIUtility.labelWidth = 200;
            EditorGUIUtility.fieldWidth = 50;
#endif

            DrawInitialMessage();
            DrawSliceMethodOption();

            if (helper.GetInt("sliceMethod") == (int)SliceMethod.SliceSingleTerrain)
                DrawSingleTerrainSliceOptions();
            else
                DrawTerrainGroupSliceOptions();

            DrawCommonSlicingOptions();
            DrawSliceProcessorFields();

            if (!Application.isPlaying)
                serializedObject.ApplyModifiedProperties();
        }

        void DrawInitialMessage()
        {
            EditorGUILayout.HelpBox("Note: All Folders are relative to the Assets folder. For example, the default save path '/' will save directly in the Assets folder.\n\n" +
                    "If terrain data or prefab assets with the same name exist in a specified save folder, they WILL BE OVERWRITTEN AUTOMATICALLY (this is a change from the previous behaviour " +
                    "of notifiying you before an asset was overwritten, so be careful).", MessageType.Info);
        }

        void DrawSliceMethodOption()
        {
            bool changeDetected;
            helper.DrawSerializedPropertyField("sliceMethod", sliceMethodLabel, out changeDetected);
            if (changeDetected)
            {
                if (helper.GetInt("sliceMethod") == (int)SliceMethod.SliceTerrainGroup)
                    CalculateDataForTerrain();
            }
        }

        void DrawSingleTerrainSliceOptions()
        {
            DrawSampleTerrainField(terrainToSliceLabel);
            if (SampleTerrain != null)
            {
                EditorGUILayout.HelpBox("A copy of the prefab can be added to scene so you can see exactly how the slicing grid lines up with the terrain that will be sliced.", MessageType.Warning);
                if (GUILayout.Button("Add Prefab To Scene"))
                    PrefabUtility.InstantiatePrefab(SampleTerrain.gameObject);
                DrawSingleTerrainSlicingGridOptions();
            }
        }
        #endregion

        #region Group Options

        void DrawTerrainGroupSliceOptions()
        {
            DrawSampleTerrainField(terrainFromGroupToSliceLabel);
            DrawInputNamingConventionOption();

            if (SampleTerrain != null)
            {
                if (!EditorUtility.IsPersistent(SampleTerrain))
                    EditorGUILayout.HelpBox("References to scene objects will be lost when changing scenes and/or closing Unity.", MessageType.Warning);
                DrawGroupSlicingGridOptions();
            }

            EditorGUILayout.LabelField(rangeToSliceLabel);
            DrawRangeOptions();

        }

        void DrawGroupSlicingGridOptions()
        {
            DrawNormalizedGridPositionNonEditableOptions();
            DrawRowsAndColumnsOfSlicesNonEditableOptions();
            DrawSliceSizeOptions();
            EditorGUILayout.Space();
        }

        void DrawInputNamingConventionOption()
        {
            NamingConvention namingConvention = (NamingConvention)EditorGUILayout.ObjectField(inputNamingConventionLabel, helper.GetPropertyByName("inputNamingConvention").objectReferenceValue, typeof(NamingConvention), false);

            if (namingConvention != helper.GetPropertyByName("inputNamingConvention").objectReferenceValue as NamingConvention)
            {
                if (namingConvention == null || namingConvention.ValidateNamingConvention(false))
                    helper.GetPropertyByName("inputNamingConvention").objectReferenceValue = namingConvention;
            }
        }

        void DrawNormalizedGridPositionNonEditableOptions()
        {
            EditorGUILayout.LabelField("Normalized Grid Position(Bottom Left Most Point on Grid)");
            EditorGUILayout.LabelField("X = 0 | Z = 0");
        }

        void DrawRowsAndColumnsOfSlicesNonEditableOptions()
        {
            EditorGUILayout.LabelField(string.Format("Rows of Slices = {0} | Columns of Slices = {1}", helper.GetInt("rowsOfSlices"), helper.GetInt("columnsOfSlices")));
            DrawTotalSlicesOption();
        }

        void DrawRangeOptions()
        {
            DrawFirstAndLastFields("First Row", "Last Row", helper.GetPropertyByName("firstRow"), helper.GetPropertyByName("lastRow"));

            DrawFirstAndLastFields("First Column", "Last Column", helper.GetPropertyByName("firstColumn"), helper.GetPropertyByName("lastColumn"));
            EditorGUILayout.HelpBox("Note, though you can enter any valid range from your group, the tool will assume the first terrain in your group starts at either 0 or 1 (depending on the Input Naming Convention). The row/coumn of the resulting slices will be calculated based on this assumption as well as the 'rows/columns of slices' values set above (as well as the Output Naming Convention).\n\nThis allows you to re-slice sub sets of your group at any time without overwriting the slices from other sub sets, though keep in mind that this will only work correctly if the slice size remains constant between slices.\n\nIf you change the slice size for a group, you should delete any pre-existing slices for that group beforehand.", MessageType.Info);

            EditorGUILayout.Space();

        }

        void DrawFirstAndLastFields(string firstLabel, string lastLabel, SerializedProperty firstValue, SerializedProperty lastValue)
        {
            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.LabelField(firstLabel, labelWidth);
            helper.DrawSerializedPropertyField(firstValue, GUIContent.none);
            EditorGUILayout.LabelField(lastLabel, labelWidth);
            helper.DrawSerializedPropertyField(lastValue, GUIContent.none);

            //EditorGUILayout.LabelField(firstLabel, labelWidth);
            //firstValue.intValue = EditorGUILayout.IntField(firstValue.intValue, fieldWidth);

            //EditorGUILayout.LabelField(lastLabel, labelWidth);
            //lastValue.intValue = EditorGUILayout.IntField(lastValue.intValue, fieldWidth);

            EditorGUILayout.EndHorizontal();
        }

        #endregion

        #region Common Options
        void DrawSampleTerrainField(GUIContent label)
        {
            EditorGUI.BeginChangeCheck();
            Terrain t = (Terrain)EditorGUILayout.ObjectField(label, SampleTerrainProperty.objectReferenceValue, typeof(Terrain), true);
            SampleTerrainProperty.objectReferenceValue = t;
            if (t != null && SampleTerrainProperty.objectReferenceValue == null)
            {
                //user tried to assign a terrain from the scene to the asset. this is no longer allowed.
                EditorUtility.DisplayDialog("Scene Terrain not Allowed", "Unfortunately, it is no longer possible to assign a non prefab terrain to this field. Please create a prefab for your terrain and assign that instead.", "OK");
                return;
            }

            if (EditorGUI.EndChangeCheck() && SampleTerrain != null)
                CalculateDataForTerrain();
        }

        void DrawCommonSlicingOptions()
        {
            DrawOutputNamingConventionOption();
            DrawStaticEditorFlagOption();
            DrawLayerAndTagOptions();
            DrawCopyOptions();
            DrawAlphamapOptions();
            EditorGUILayout.Space();

            if (!helper.GetBool("disableEdgeBlending"))
                EditorGUILayout.HelpBox("You may notice white lines on the borders of your slices after slicing. These appear because Terrain " +
                    "Neighboring is not setup in the Editor. If using the Dynamic Loading Kit, neighboring will be done automatically; otherwise, you " +
                    "can add the SetNeighbors script (Component->Terrain Slicing Kit) to the first slice in your group (_1_1). Make sure to configure this script correctly!", MessageType.Info);

            DrawBaseNameOfSlicesOption();
            DrawBaseNameOfSlicesDataOption();
            DrawSliceDataSaveFolderOption();
            DrawPrefabOptions();
        }



        #endregion

        #region Single Slicing Grid Options

        void DrawSingleTerrainSlicingGridOptions()
        {
            DrawGridColorOption();
            DrawGridYOffsetOption();
            DrawNormalizedGridPositionEditableOptions();
            DrawRowsOfSlicesOption();
            DrawColumnsOfSlicesOption();
            DrawTotalSlicesOption();
            DrawSliceSizeOptions();
            EditorGUILayout.Space();
        }

        void DrawGridColorOption()
        {
            helper.DrawSerializedPropertyField("slicingGridColor", "Slicing Grid Color");
        }

        void DrawGridYOffsetOption()
        {
            helper.DrawSerializedPropertyField("gridYOffset");
        }

        void DrawNormalizedGridPositionEditableOptions()
        {
            EditorGUILayout.LabelField("Normalized Grid Position(Bottom Left Most Point on Grid)");

            float normalizedXPosition = EditorGUILayout.Slider("X", helper.GetFloat("normalizedXPosition"), 0f, 1f);
            if (!Mathf.Approximately(helper.GetFloat("normalizedXPosition"), normalizedXPosition))
            {
                helper.GetPropertyByName("normalizedXPosition").floatValue = normalizedXPosition;
                SnapGridNormalizedXPosition();
            }

            float normalizedZPosition = EditorGUILayout.Slider("Z", helper.GetFloat("normalizedZPosition"), 0f, 1f);
            if (!Mathf.Approximately(helper.GetFloat("normalizedZPosition"), normalizedZPosition))
            {
                helper.GetPropertyByName("normalizedZPosition").floatValue = normalizedZPosition;
                SnapGridNormalizedZPosition();
            }
        }

        void DrawRowsOfSlicesOption()
        {
            int currentRowsOfSlices = helper.GetInt("rowsOfSlices");
            int rowsOfSlices = EditorGUILayout.IntSlider("Rows of Slices", currentRowsOfSlices, 1, helper.GetInt("baseTerrainToSliceRatio"));

            if (rowsOfSlices != currentRowsOfSlices)
            {
                float normalizedLengthOfPreviousGrid = allCutsLength / terrainLength;
                allCutsLength = cutLength * rowsOfSlices;
                float normalizedLengthOfNewGrid = allCutsLength / terrainLength;
                helper.GetPropertyByName("normalizedZPosition").floatValue = GetNewNormalizedPositionToKeepGridCentered(helper.GetFloat("normalizedZPosition"), normalizedLengthOfPreviousGrid, normalizedLengthOfNewGrid);

                half = new Vector3(allCutsWidth * .5f, 0f, allCutsLength * .5f);
                helper.GetPropertyByName("rowsOfSlices").intValue = rowsOfSlices;
            }
        }

        void DrawColumnsOfSlicesOption()
        {
            int currentColumnsOfSlices = helper.GetInt("columnsOfSlices");
            int columnsOfSlices = EditorGUILayout.IntSlider("Columns of Slices", currentColumnsOfSlices, 1, helper.GetInt("baseTerrainToSliceRatio"));

            if (columnsOfSlices != currentColumnsOfSlices)
            {
                float normalizedWidthOfPreviousGrid = allCutsWidth / terrainWidth;
                allCutsWidth = cutWidth * columnsOfSlices;
                float normalizedWidthOfNewGrid = allCutsWidth / terrainWidth;
                helper.GetPropertyByName("normalizedXPosition").floatValue = GetNewNormalizedPositionToKeepGridCentered(helper.GetFloat("normalizedXPosition"), normalizedWidthOfPreviousGrid, normalizedWidthOfNewGrid);

                half = new Vector3(allCutsWidth * .5f, 0f, allCutsLength * .5f);
                helper.GetPropertyByName("columnsOfSlices").intValue = columnsOfSlices;
            }
        }



        #endregion

        #region Other Options

        void DrawSliceSizeOptions()
        {
            EditorGUILayout.LabelField(string.Format("Slice Size = 1/{0} of base terrain's size", helper.GetInt("baseTerrainToSliceRatio")));

            if (helper.GetInt("baseTerrainToSliceRatio") > 2 && GUILayout.Button("Increase Slice Size"))
                DoubleSliceSize();

            if (helper.GetInt("baseTerrainToSliceRatio") < maxSlicesOnSingleAxis && GUILayout.Button("Decrease Slice Size"))
                HalveSliceSize();
        }

        void DrawTotalSlicesOption()
        {
            EditorGUILayout.LabelField(string.Format("Total Slices = {0}", helper.GetInt("rowsOfSlices") * helper.GetInt("columnsOfSlices")));
        }

        void DrawOutputNamingConventionOption()
        {
            NamingConvention namingConvention = (NamingConvention)EditorGUILayout.ObjectField(outputNamingConventionLabel, helper.GetPropertyByName("outputNamingConvention").objectReferenceValue, typeof(NamingConvention), false);

            if (namingConvention != helper.GetPropertyByName("outputNamingConvention").objectReferenceValue as NamingConvention)
            {
                if (namingConvention == null || namingConvention.ValidateNamingConvention(false))
                {
                    helper.GetPropertyByName("outputNamingConvention").objectReferenceValue = namingConvention;
                }
            }
        }

        void DrawStaticEditorFlagOption()
        {
            helper.DrawSerializedPropertyField("staticGameObjectFlagsSetMethod");
            if ((StaticEditorFlagsSetMethod)helper.GetPropertyByName("staticGameObjectFlagsSetMethod").enumValueIndex == StaticEditorFlagsSetMethod.SetManually)
            {
                SerializedProperty staticEditorFlagsProperty = helper.GetPropertyByName("staticEditorFlags");
                StaticEditorFlags currentFlags = (StaticEditorFlags)staticEditorFlagsProperty.intValue;
                StaticEditorFlags newFlags = (StaticEditorFlags)EditorGUILayout.EnumMaskField(currentFlags);

                if (currentFlags != newFlags)
                {
                    staticEditorFlagsProperty.intValue = (int)newFlags;
                }
            }
        }

        void DrawLayerAndTagOptions()
        {
            helper.DrawSerializedPropertyField("copyBaseLayer", getLayerFromBaseLabel);
            helper.DrawSerializedPropertyField("copyBaseTag", getTagFromBaseLabel);
        }

        void DrawCopyOptions()
        {
            helper.DrawSerializedPropertyField("copyAllTrees", copyAllTreesLabel);
            helper.DrawSerializedPropertyField("copyAllDetails", copyAllDetailLabel);
        }

        void DrawAlphamapOptions()
        {
            helper.DrawSerializedPropertyField("dontSliceAlphamap", dontSliceAlphamapLabel);

            if (helper.GetBool("dontSliceAlphamap"))
                helper.DrawSerializedPropertyField("copySplatTextures", copySplatTexturesLabel);
            else
            {
                helper.DrawSerializedPropertyField("disableEdgeBlending", disableEdgeBlendingLabel);

                if (!helper.GetBool("disableEdgeBlending"))
                {
                    SerializedProperty edgeBlendingWidthProperty = helper.GetPropertyByName("edgeBlendingWidth");
                    edgeBlendingWidthProperty.intValue = EditorGUILayout.IntSlider(edgeBlendingWidthLabel, edgeBlendingWidthProperty.intValue, 1, maxEdgeBlendingWidth);
                }
            }
        }

        void DrawBaseNameOfSlicesOption()
        {
            helper.DrawSerializedPropertyField("sliceOutputBaseName", baseNameSlicesLabel);
        }

        void DrawBaseNameOfSlicesDataOption()
        {
            helper.DrawSerializedPropertyField("sliceDataOutputBaseName", baseNameSlicesDataLabel);
        }

        void DrawSliceDataSaveFolderOption()
        {
            helper.DrawSerializedPropertyField("sliceDataSaveFolder", sliceDataSaveFolderLabel);
        }

        void DrawPrefabOptions()
        {
            helper.DrawSerializedPropertyField("createPrefabs", createPrefabsLabel);

            if (helper.GetBool("createPrefabs"))
            {
                helper.DrawSerializedPropertyField("prefabSaveFolder", prefabSaveFolderLabel);

                helper.DrawSerializedPropertyField("removeSlicesFromSceneAfterCreation", removeSlicesLabel);
            }
        }

        void DrawSliceProcessorFields()
        {
            helper.DrawSerializedPropertyArrayField("sliceProcessors");
            //int numProcessorsCurrently = sliceConfiguration.sliceProcessor == null ? 0 : sliceConfiguration.sliceProcessor.Length;
            //int processors = EditorGUILayout.IntField(sliceProcessorLabel, numProcessorsCurrently);

            //if(numProcessorsCurrently != processors)
            //{
            //    if (sliceConfiguration.sliceProcessor == null)
            //        sliceConfiguration.sliceProcessor = new SliceProcessor[processors];
            //    else
            //        System.Array.Resize<SliceProcessor>(ref sliceConfiguration.sliceProcessor, processors);

            //    SetDirty();
            //}

            //if(sliceConfiguration.sliceProcessor != null && sliceConfiguration.sliceProcessor.Length != 0)
            //{
            //    for(int i = 0; i < sliceConfiguration.sliceProcessor.Length; i++)
            //    {
            //        SliceProcessor processor = (SliceProcessor)EditorGUILayout.ObjectField(string.Format("Slice Processor {0}", i + 1), sliceConfiguration.sliceProcessor[i], typeof(SliceProcessor), false);
            //        CheckIfValueChangedAndReplaceOldValueIfChangeOccured<SliceProcessor>(processor, ref sliceConfiguration.sliceProcessor[i]);
            //    }
            //}
        }

        #endregion

        #region Private Methods (Non Options)
        int Pow(int num, int power)
        {
            if (power == 0)
                return 1;
            else
                return num * Pow(num, power - 1);
        }

        int CalculateMaxEdgeBlendingWidth()
        {
            return (SampleTerrain.terrainData.alphamapResolution / helper.GetInt("baseTerrainToSliceRatio")) / 2;
        }

        void CalculateDataForTerrain()
        {
            if (SampleTerrain == null)
                return;

            maxSlicesOnSingleAxis = SampleTerrain.DetermineMaxSlice();
            if (maxSlicesOnSingleAxis > 1)
            {
                TerrainData data = SampleTerrain.terrainData;
                terrainWidth = data.size.x;
                terrainLength = data.size.z;

                smallestResolution = TerrainDataExtensions.GetSmallestOfFourNumbers(data.heightmapResolution - 1, data.detailResolution, data.alphamapResolution, data.baseMapResolution);

                normalizedSnapSpread = 1f / smallestResolution;

                if (helper.GetInt("baseTerrainToSliceRatio") > maxSlicesOnSingleAxis)
                    helper.GetPropertyByName("baseTerrainToSliceRatio").intValue = maxSlicesOnSingleAxis;

                if (helper.GetInt("sliceMethod") == (int)SliceMethod.SliceSingleTerrain)
                {
                    if (helper.GetInt("rowsOfSlices") > helper.GetInt("baseTerrainToSliceRatio"))
                        helper.GetPropertyByName("rowsOfSlices").intValue = helper.GetInt("baseTerrainToSliceRatio");

                    if (helper.GetInt("columnsOfSlices") > helper.GetInt("baseTerrainToSliceRatio"))
                        helper.GetPropertyByName("columnsOfSlices").intValue = helper.GetInt("baseTerrainToSliceRatio");
                }
                else
                {
                    helper.GetPropertyByName("rowsOfSlices").intValue = helper.GetInt("baseTerrainToSliceRatio");
                    helper.GetPropertyByName("columnsOfSlices").intValue = helper.GetInt("baseTerrainToSliceRatio");
                }

                cutWidth = terrainWidth / helper.GetInt("baseTerrainToSliceRatio");
                allCutsWidth = cutWidth * helper.GetInt("columnsOfSlices");

                cutLength = terrainLength / helper.GetInt("baseTerrainToSliceRatio");
                allCutsLength = cutLength * helper.GetInt("rowsOfSlices");
                half = new Vector3(allCutsWidth * .5f, 0f, allCutsLength * .5f);
                maxEdgeBlendingWidth = CalculateMaxEdgeBlendingWidth();
            }
            else
            {
                SampleTerrainProperty.objectReferenceValue = null;
                EditorUtility.DisplayDialog("Invalid Terrain", resolutionTooSmallError, "OK");
            }
        }

        void DoubleSliceSize()
        {
            helper.GetPropertyByName("baseTerrainToSliceRatio").intValue /= 2;

            cutWidth = terrainWidth / helper.GetInt("baseTerrainToSliceRatio");

            int newNumSliceColumns = helper.GetPropertyByName("columnsOfSlices").intValue / 2;

            if (newNumSliceColumns == 0)
                newNumSliceColumns = 1;

            helper.GetPropertyByName("columnsOfSlices").intValue = newNumSliceColumns;
            float previousAllCutsWidth = allCutsWidth;
            allCutsWidth = cutWidth * newNumSliceColumns;

            if (!Mathf.Approximately(previousAllCutsWidth, allCutsWidth))
            {
                SerializedProperty normalX = helper.GetPropertyByName("normalizedXPosition");
                normalX.floatValue = GetNewNormalizedPositionToKeepGridCentered(normalX.floatValue, previousAllCutsWidth / terrainWidth, allCutsWidth / terrainWidth);
                SnapGridNormalizedXPosition();
            }

            cutLength = terrainLength / helper.GetInt("baseTerrainToSliceRatio");

            int newNumSliceRows = helper.GetPropertyByName("rowsOfSlices").intValue / 2;
            if (newNumSliceRows == 0)
                newNumSliceRows = 1;

            helper.GetPropertyByName("rowsOfSlices").intValue = newNumSliceRows;

            float previousAllCutsLength = allCutsLength;
            allCutsLength = cutLength * newNumSliceRows;

            if (!Mathf.Approximately(previousAllCutsLength, allCutsLength))
            {
                SerializedProperty normalZ = helper.GetPropertyByName("normalizedZPosition");

                normalZ.floatValue = GetNewNormalizedPositionToKeepGridCentered(normalZ.floatValue, previousAllCutsLength / terrainLength, allCutsLength / terrainLength);
                SnapGridNormalizedZPosition();
            }

            half = new Vector3(allCutsWidth * .5f, 0f, allCutsLength * .5f);
            maxEdgeBlendingWidth = CalculateMaxEdgeBlendingWidth();
        }

        float GetNewNormalizedPositionToKeepGridCentered(float previousNormalizedPosition, float previousNormalizedWidthOrLengthOfSlicingGrid, float newNormalizedWidthOrLengthOfSlicingGrid)
        {
            float normalizedCenterOfPreviousGrid = EditorTerrainTools.NormalizedBottomLeftPointToCenterPoint(previousNormalizedPosition, previousNormalizedWidthOrLengthOfSlicingGrid);

            float newNormal = EditorTerrainTools.NormalizedCenterPointToBottomLeftPoint(normalizedCenterOfPreviousGrid, newNormalizedWidthOrLengthOfSlicingGrid);

            if (newNormal < 0f)
                newNormal = 0f;
            else if (newNormal > (1f - newNormalizedWidthOrLengthOfSlicingGrid))
                newNormal = 1f - newNormalizedWidthOrLengthOfSlicingGrid;

            return newNormal;
        }

        void HalveSliceSize()
        {
            helper.GetPropertyByName("baseTerrainToSliceRatio").intValue *= 2;

            cutWidth = terrainWidth / helper.GetInt("baseTerrainToSliceRatio");
            helper.GetPropertyByName("columnsOfSlices").intValue *= 2;
            allCutsWidth = cutWidth * helper.GetInt("columnsOfSlices");

            cutLength = terrainLength / helper.GetInt("baseTerrainToSliceRatio");
            helper.GetPropertyByName("rowsOfSlices").intValue *= 2;
            allCutsLength = cutLength * helper.GetInt("rowsOfSlices");

            half = new Vector3(allCutsWidth * .5f, 0f, allCutsLength * .5f);
            maxEdgeBlendingWidth = CalculateMaxEdgeBlendingWidth();
        }

        void SnapGridNormalizedXPosition()
        {
            int snapWidthsFromOrigin = (int)(helper.GetFloat("normalizedXPosition") / normalizedSnapSpread);
            helper.GetPropertyByName("normalizedXPosition").floatValue = snapWidthsFromOrigin * normalizedSnapSpread;
        }

        void CalculateNormalizedXPosition(float xDistanceFromTerrainOrigin)
        {
            helper.GetPropertyByName("normalizedXPosition").floatValue = xDistanceFromTerrainOrigin / terrainWidth;
        }

        float CalculateNonNormalizedXPosition(float currentTerrainXPosition)
        {
            return helper.GetFloat("normalizedXPosition") * terrainWidth + currentTerrainXPosition;
        }

        void SnapGridNormalizedZPosition()
        {
            int snapLengthsFromOrigin = (int)(helper.GetFloat("normalizedZPosition") / normalizedSnapSpread);
            helper.GetPropertyByName("normalizedZPosition").floatValue = snapLengthsFromOrigin * normalizedSnapSpread;
        }

        void CalculateNormalizedZPosition(float zDistanceFromTerrainOrigin)
        {
            helper.GetPropertyByName("normalizedZPosition").floatValue = zDistanceFromTerrainOrigin / terrainLength;
        }

        float CalculateNonNormalizedZPosition(float currentTerrainZPosition)
        {
            return helper.GetFloat("normalizedZPosition") * terrainLength + currentTerrainZPosition;
        }
        #endregion

        #region GUIContent Labels

        GUIContent copySplatTexturesLabel = new GUIContent("Copy Splat Textures*", "Check this option if you still want to copy all splat textures from the base terrain to the sliced terrains, even though you are not slicing the base terrain's alphamap (splats are always copied when slicing the base terrain's alphamap). Note that this will cause each slice to have an alphamap created for it, so you should only enable it if you absolutely need to.");


        GUIContent dontSliceAlphamapLabel = new GUIContent("Don't Slice Alphamap*", "If enabled, the alphamap/splatmap from the base terrain will not be sliced (the slices will have no alphamap). This should only be used if using a custom shader that does not need the slices to have alphamaps.");

        GUIContent inputNamingConventionLabel = new GUIContent("Input Naming Convention*", "A Naming Convention implemented as a scriptable object. You can create a NamingConvention asset via Assets -> Dynamic Loading Kit -> Create Naming Convention Asset.\n\nThis asset should describe the naming convention of the group you wish to slice. If left blank, it will be assumed that the group follows the default naming convention (_%y_%x or _Row_Column).\n\nYou can find more information about Naming Conventions in the Quick Guides folder within your project.");

        GUIContent outputNamingConventionLabel = new GUIContent("Output Naming Convention*", "A Naming Convention implemented as a scriptable object. You can create a NamingConvention asset via Assets -> Dynamic Loading Kit -> Create Naming Convention Asset.\n\nThis can be used to change the naming convention used by the Slicing Tool to name the slices. If left blank, the default naming convention will be used (_%y_%x or _Row_Column).\n\nYou can find more information about Naming Conventions in the Quick Guides folder within your project.");

        GUIContent sliceProcessorLabel = new GUIContent("Slice Processor*", "Slice Processors can be used to perform some additional processes on each slice (such as slicing materials or adding specific scripts to each slice). The processes will be executed in the order they appear in the fields below.");

        GUIContent rangeToSliceLabel = new GUIContent("Enter the range of the terrains to slice from your group", "For example, if you want to slice all the terrains in a 8 x 8 group, enter " +
            "1 for First Row/Column and 8 for Last Row/Column.");

        GUIContent sliceMethodLabel = new GUIContent("Slice Method", "Which slicing method would you like to employ?");

        GUIContent sliceMethod_single = new GUIContent("Slice Single Terrain", "Slice a single terrain.");

        GUIContent sliceMethod_terrainGroup = new GUIContent("Slice Terrain Group", "Slice a set of terrains from a single terrain group.");

        GUIContent terrainToSliceLabel = new GUIContent("Terrain To Slice", "The terrain you wish to slice. This can be a terrain in your scene or a prefab from your project hiearchy.");

        GUIContent terrainFromGroupToSliceLabel = new GUIContent("Any Terrain From Group", "A terrain from the group you wish to slice. This can be a terrain in your scene or a prefab from your project hiearchy, " +
            "though if it is a prefab in your project hiearchy, please ensure all prefabs you are slicing are in the same folder.");

        GUIContent baseNameSlicesLabel = new GUIContent("Base Name of Created Slices", "The base name of the created slices. For instance, a value of 'Terrain' will produce slices " +
            "'Terrain_1_1', 'Terrain_1_2', etc.\n\nIf the Create Prefabs from Slices option is checked, the prefabs will also be named the same.");

        GUIContent baseNameSlicesDataLabel = new GUIContent("Base Name of Created Slice Data", "The base name of the created slices terrain data assets. For instance, a value of 'TerrainData' will produce data " +
            "'TerrainData_1_1', 'TerrainData_1_2', etc.");

        GUIContent copyAllDetailLabel = new GUIContent("Copy All Detail Meshes", "Same deal as the trees.\n\nLeave checked to copy every detail mesh to every slice, " +
                    "or uncheck to only copy a detail mesh to a slice if the detail mesh exists within the bounds of the slice.");

        GUIContent copyAllTreesLabel = new GUIContent("Copy All Trees", "The base terrain contains a list of tree prototypes " +
                    "(called a tree prototype list) which you can paint on it. The terrain slices created with this slicing tool also contain such a list.\n\nThe default " +
                    "behaviour of the slicing tool is to only add trees that fall within the bounds of each slice to that slices prototype list.\n\nIf you want to override this behaviour so all trees from " +
                    "the base terrain are copied to every slice, regardless of whether that slice has the tree type on it, enable this option.");

        GUIContent createPrefabsLabel = new GUIContent("Create Prefabs from Slices", "Enabling this option will generate prefabs " +
                    "out of your slices. In addition, it will also allow you to remove the slices from the scene after they are created (which is necessary when dealing with high resolution terrains and/or creating " +
                    "a large amount of slices. If seeing memory errors/crashing when slicing, check this option and set slices to be removed from the scene.");

        GUIContent deactivatePrefabsLabel = new GUIContent("Deactivate Prefabs", "Puts the created prefabs into a deactivated state. This is useful when using the prefabs with the Dynamic " +
            "Loading Kit and Prefab Instantiator component, since in the Instantiator component requires the prefabs to be deactivated.");

        GUIContent disableEdgeBlendingLabel = new GUIContent("Disable Alphamap Blending", "Edge blending blends the alphamap of each slice so that the transition from one slice to its neighbor is seemless.\n\nDisabling " +
                "edge blending is not recommended.");

        GUIContent edgeBlendingWidthLabel = new GUIContent("Blending Width", "The width of the area to belnd on each slices alphamap. A value of 1 will only blend slices along the edges, and is usually " +
            "sufficient. You are free to use whatever value you wish, though note that edge blending blurs the effected area, so it's best to minimize the width of the area.\n\nYou can preview how your terrain group will look by adding a SetNeighbors script to the first slice in the group (_1_1) and entering play mode.");

        GUIContent getLayerFromBaseLabel = new GUIContent("Copy Base Layer", "If enabled, every slice's layer will be set to whatever the layer is of the base 'Terrain To Slice', otherwise they will be set to the default layer.");

        GUIContent getTagFromBaseLabel = new GUIContent("Copy Base Tag", "If enabled, every slice's tag will be set to whatever the tag is of the base 'Terrain To Slice', otherwise they will be set to 'Untagged'");

        GUIContent removeSlicesLabel = new GUIContent("Remove Slices From Scene", "Enabling this option will remove the slices from the scene after they have been converted " +
                     "to prefabs.\n\nIf you are experiencing out of memory errors while slicing, enabling this option should resolve those issues.\n\nNote this option can only be used when " +
                     "creating prefabs out of your slices (or else the slices would be lost forever when removed from the scene).");

        GUIContent sliceDataSaveFolderLabel = new GUIContent("Slice Data Save Folder", "The folder where the slices terrain data will be saved to.\n\nWARNING: Any assets in the specified folder with the " +
            "same name as the newly created terrain data will be overwritten, so be careful!");

        GUIContent sliceDimensionsLabel = new GUIContent("Slice Dimensions", "The dimensions of the resulting slice, i.e., 2 x 2 means the base terrain will be sliced into 2 colums " +
            "and 2 rows, for a total of 4 slices.\n\nThe max slice dimension possible is constrained by your smallest terrain resolution.");

        GUIContent prefabSaveFolderLabel = new GUIContent("Prefab Save Folder", "The folder where the prefabs will be saved to.\n\nWARNING: Any assets in the specified folder with the " +
            "same name as the newly prefabs will be overwritten, so be careful!");

        string resolutionTooSmallError = "The provided terrain cannot be sliced, as one or more of its resolutions is too small. To slice, all resolutions must greater than or equal to " +
            "the following minimum values:\n\nControl Texture Resolution: 32\nHeightmap Resolution: 65\nBase Map Resolution: 32\nDetail Resolution: Detail Resolution Per Patch * 2";

        #endregion
    }
}