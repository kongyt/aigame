﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using UnityEditor;
    using UnityEngine;

    class BlendEdges : EditorWindow
    {
        //Use Options/fields
        Terrain baseTerrain;
        int columns;
        static int effectedRegionWidth;
        int rows;
        bool showFoldout;
        static Terrain[,] terrainSelections;

        //Other class member variables
        int maxWidth;
        Vector2 scrollPosition;


        [MenuItem("Terrain/Terrain Slicing Kit/Blend Edges")]
        static void ShowWindow()
        {
            var window = EditorWindow.GetWindow(typeof(BlendEdges));
            window.position = new Rect(Screen.width / 2 + 300, 400, 600, 300);
        }

        void OnEnable()
        {
            minSize = new Vector2(600, 380);

            if (!Application.isPlaying)
            {
                GameObject[] selection = Selection.gameObjects;
                Terrain selectedTerrain = null;
                if (selection.Length != 0)
                    selectedTerrain = selection[0].GetComponent<Terrain>();

                if (terrainSelections == null)
                {
                    rows = 1;
                    columns = 1;
                    terrainSelections = new Terrain[1, 1];
                    if (selectedTerrain != null)
                    {
                        baseTerrain = selectedTerrain;
                        terrainSelections[0, 0] = selectedTerrain;
                    }
                    else
                        baseTerrain = null;
                }
                else
                {
                    if (selectedTerrain != null && selectedTerrain != terrainSelections[0, 0])
                    {
                        rows = 1;
                        columns = 1;
                        baseTerrain = selectedTerrain;
                        terrainSelections = new Terrain[1, 1];
                        terrainSelections[0, 0] = selectedTerrain;
                    }
                    else if (selectedTerrain == null || (selectedTerrain != null && selectedTerrain == terrainSelections[0, 0]))
                    {
                        rows = terrainSelections.GetLength(0);
                        columns = terrainSelections.GetLength(1);
                        baseTerrain = terrainSelections[0, 0];
                    }
                }

                showFoldout = true;

                if (baseTerrain != null)
                    maxWidth = maxWidth = baseTerrain.terrainData.heightmapResolution / 2;
                else
                    maxWidth = -1;
            }
        }

        void Update()
        {
            if (Application.isPlaying)
            {
                EditorUtility.DisplayDialog("Error", "The Blend Edges Tool cannot operate in play mode. Exit play mode and reselect Blend Edges Option.", "Close");
                this.Close();
            }
        }

        //Our GUI
        void OnGUI()
        {
            GUILayout.Label("Configuration", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("This tool blends both the heightmap and alphamaps of a terrain group. It is outdated and unoptomized, however, " +
            "so I suggest using the Tileable Terrain Maker Component instead (Components -> Tileable Terrain Maker).", MessageType.Info);
            baseTerrain = EditorGUILayout.ObjectField(TerrainSlicingKit.LabelDatabase.baseTerrainLabel, baseTerrain, typeof(Terrain), true) as Terrain;
            if (baseTerrain == null)
                GUILayout.Label("You must provide a base terrain in order to proceed.");
            else
            {
                //use -1 to indicate the maxWidth hasn't been set yet
                if (maxWidth == -1)
                    maxWidth = baseTerrain.terrainData.heightmapResolution / 2;
                effectedRegionWidth = EditorGUILayout.IntSlider(TerrainSlicingKit.LabelDatabase.effectedRegionLabel, effectedRegionWidth, 1, maxWidth);

                columns = EditorGUILayout.IntField(TerrainSlicingKit.LabelDatabase.columnsLabel, columns);
                rows = EditorGUILayout.IntField(TerrainSlicingKit.LabelDatabase.rowsLabel, rows);

                showFoldout = EditorGUILayout.Foldout(showFoldout, TerrainSlicingKit.LabelDatabase.terrainsInGroupLabel);

                int row;
                int col;
                if (showFoldout)
                {
                    if (GUILayout.Button("Auto Fill From Scene"))
                        FillSelections();

                    int rowsOfSelectedTerrains = terrainSelections.GetLength(0);
                    int columnsOfSelectedTerrains = terrainSelections.GetLength(1);

                    if (rowsOfSelectedTerrains != rows || columnsOfSelectedTerrains != columns)
                    {
                        Terrain[,] tempArray = new Terrain[rows, columns];
                        for (row = 0; row < rows; row++)
                        {
                            for (col = 0; col < columns; col++)
                            {
                                if (row < rowsOfSelectedTerrains && col < columnsOfSelectedTerrains)
                                    tempArray[row, col] = terrainSelections[row, col];
                            }
                        }

                        terrainSelections = tempArray;
                    }
                    scrollPosition = GUILayout.BeginScrollView(scrollPosition, GUILayout.Width(590), GUILayout.Height(175));
                    for (row = 1; row <= rows; row++)
                    {
                        for (col = 1; col <= columns; col++)
                            terrainSelections[row - 1, col - 1] = EditorGUILayout.ObjectField("Terrain_" + row + "_" + col, terrainSelections[row - 1, col - 1], typeof(Terrain), true) as Terrain;
                    }
                    GUILayout.EndScrollView();
                }
            }
        }//End the OnGUI function

        void FillSelections()
        {
            SelectionFiller selectionFiller = new SelectionFiller();
            Terrain[,] terrains;

            terrains = selectionFiller.FillSelections_NormalVersion(baseTerrain.transform, rows, columns);
            if (terrains.Length != terrainSelections.Length)
            {
                EditorUtility.DisplayDialog("Error", "The number of terrains found does not match the expected number of terrains. Did you input the correct number of rows/columns?", "OK");
                return;
            }

            if (terrains != null)
                terrainSelections = terrains;
            else
                EditorUtility.DisplayDialog("Error", "No terrains were found.", "OK");
        }
    }//End the MakeTerrain Class
}