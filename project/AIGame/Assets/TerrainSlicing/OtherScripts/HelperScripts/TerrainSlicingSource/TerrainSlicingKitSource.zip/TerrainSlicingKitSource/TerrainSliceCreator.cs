﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
using UnityEngine;
using UnityEditor;
using System;

namespace TerrainSlicingKit
{
    internal class TerrainSliceCreator
    {
        Color grassTint;

        float sliceWidth, sliceLength, sliceHeight, grassStrength, grassAmount, grassSpeed;
        float normalizedSliceToBaseTerrainRatio;

        int sliceHeightMapResolution, sliceEvenHeightMapResolution, sliceDetailResolution, sliceAlphaMapResolution, sliceBaseMapResolution, detailResolutionPerPatch, rowsOfSlices, columnsOfSlices, baseTerrainToSliceRatio, sliceOutputLayer, indexAdd;

        bool copyAllTrees, copyAllDetails, removeSlicesFromSceneAfterPrefabCreation, copyBaseLayer, copyBaseTag, sliceAlphamap, copySplatTextures;

        DetailPrototype[] detailProtos;

        SliceProcessor[] postSliceProcesses;
        PrefabCreator prefabCreator;

        Terrain sourceTerrain;
        TerrainData sourceData;

        SplatPrototype[] splatProtos;

        string outputNamingConventionFormatStringForTerrainData, outputNamingConventionFormatStringForTerrainObject, sliceDataSavePath, sliceDataOutputBaseName, sliceOutputBaseName, sliceOutputTag;

        UnityVersionDependentDataCopier versionDependentDataCopier;
        Vector3 normalizedSliceStart, nonNormalizedSliceStart;

        internal TerrainSliceCreator(UnityVersionDependentDataCopier versionDependentDataCopier, string sliceDataSavePath, string sliceDataOutputBaseName, string sliceOutputBaseName, string outputNamingConventionFormatStringForTerrainData, string outputNamingConventionFormatStringForTerrainObject, bool startNumberingAt0,
            int rowsOfSlices, int columnsOfSlices, int baseTerrainToSliceRatio, Vector3 normalizedSliceStart, SliceProcessor[] postSliceProcesses, bool copyBaseLayer, bool copyBaseTag, bool copyAllTrees, bool copyAllDetails, bool sliceAlphamap, bool copySplatTextures, bool createPrefabs = false, string prefabSavePath = null, bool removeSlicesFromSceneAfterPrefabCreation = false)
        {
            this.versionDependentDataCopier = versionDependentDataCopier;
            this.postSliceProcesses = postSliceProcesses;

            this.outputNamingConventionFormatStringForTerrainData = outputNamingConventionFormatStringForTerrainData;
            this.outputNamingConventionFormatStringForTerrainObject = outputNamingConventionFormatStringForTerrainObject;
            this.sliceDataSavePath = sliceDataSavePath;
            this.sliceDataOutputBaseName = sliceDataOutputBaseName;
            this.sliceOutputBaseName = sliceOutputBaseName;
            this.rowsOfSlices = rowsOfSlices;
            this.columnsOfSlices = columnsOfSlices;
            this.baseTerrainToSliceRatio = baseTerrainToSliceRatio;

            this.copyBaseLayer = copyBaseLayer;
            this.copyBaseTag = copyBaseTag;
            this.copyAllTrees = copyAllTrees;
            this.copyAllDetails = copyAllDetails;
            this.sliceAlphamap = sliceAlphamap;
            this.normalizedSliceStart = normalizedSliceStart;
            this.copySplatTextures = copySplatTextures;
            indexAdd = startNumberingAt0 ? 0 : 1;

            //ex if baseTerrainToSliceRatio = 2, then the normalizedSliceToBaseTerrainRatio would be .5 (aka slice is 1/2 
            //the size of base terrain)
            normalizedSliceToBaseTerrainRatio = 1f / baseTerrainToSliceRatio;

            if (createPrefabs)
                prefabCreator = new PrefabCreator(prefabSavePath, true, versionDependentDataCopier);

            this.removeSlicesFromSceneAfterPrefabCreation = removeSlicesFromSceneAfterPrefabCreation;
        }

            




        float progress;

        internal void CreateSlices(Terrain terrainToSlice, TreeDataHandler treeDataHandler, int rowStart, int columnStart, float startingProgress, float totalAllowedProgress = 1f)
        {
            sourceTerrain = terrainToSlice;
            sourceData = terrainToSlice.terrainData;
            StoreDataFromSourceTerrain();
            CalculateSliceDataFromSourceData();
            SetLayerAndTagInfoForSlices();

            progress = startingProgress;
            float progressIncrement = totalAllowedProgress / (rowsOfSlices * columnsOfSlices);

            TreeCopier treeCopier = CreateAndInitializeTreeCopier(treeDataHandler, copyAllTrees);
            for (var row = 0; row < rowsOfSlices; row++)
            {
                for (var column = 0; column < columnsOfSlices; column++)
                {
                    int actualRowInGroup = row + rowStart + indexAdd;
                    int actualColumnInGroup = column + columnStart + indexAdd;
                    string rowText = actualRowInGroup.ToString();
                    string columnText = actualColumnInGroup.ToString();
                    string terrainDataName = string.Format(outputNamingConventionFormatStringForTerrainData, columnText, rowText);

                    string terrainObjectName = string.Format(outputNamingConventionFormatStringForTerrainObject, columnText, rowText);

                    GameObject gameObjectSlice = CreateSliceAsset(row, column, terrainObjectName, terrainDataName);
                    CopyDataToSlice(gameObjectSlice, treeCopier, row, column);

                    if(postSliceProcesses != null && postSliceProcesses.Length != 0)
                    {
                        float normalizedXStart = normalizedSliceStart.x + (column * normalizedSliceToBaseTerrainRatio);
                        float normalizedZStart = normalizedSliceStart.z + (row * normalizedSliceToBaseTerrainRatio);
                        TerrainSlice terrainSlice = new TerrainSlice(gameObjectSlice.GetComponent<Terrain>(), actualRowInGroup, actualColumnInGroup, normalizedSliceToBaseTerrainRatio, normalizedXStart, normalizedZStart, gameObjectSlice.transform.position);
                        for(int i = 0; i < postSliceProcesses.Length; i++)
                        {
                            if (postSliceProcesses[i] != null)
                                postSliceProcesses[i].ProcessSlice(terrainToSlice, terrainSlice);
                        }
                    }

                    if (prefabCreator != null)
                    {
                        prefabCreator.CreatePrefab(gameObjectSlice);
                        if (removeSlicesFromSceneAfterPrefabCreation)
                            GameObject.DestroyImmediate(gameObjectSlice);
                    }

                    gameObjectSlice = null;

                    OtherExtensions.FreeMemory();

                    progress += progressIncrement;
                }
            }
        }

        void StoreDataFromSourceTerrain()
        {
            splatProtos = sourceData.splatPrototypes;
            detailProtos = sourceData.detailPrototypes;
            grassStrength = sourceData.wavingGrassStrength;
            grassAmount = sourceData.wavingGrassAmount;
            grassSpeed = sourceData.wavingGrassSpeed;
            grassTint = sourceData.wavingGrassTint;

            Vector3 sourceTerrainPosition = sourceTerrain.GetPosition();
            float nonNormalizedSliceStartX = sourceTerrainPosition.x + (sourceData.size.x * normalizedSliceStart.x);
            float nonNormalizedSliceStartZ = sourceTerrainPosition.z + (sourceData.size.z * normalizedSliceStart.z);
            nonNormalizedSliceStart = new Vector3(nonNormalizedSliceStartX, sourceTerrainPosition.y, nonNormalizedSliceStartZ);

            detailResolutionPerPatch = sourceData.GetDetailResolutionPerPatch();
        }

        void CalculateSliceDataFromSourceData()
        {
            sliceWidth = sourceData.size.x / baseTerrainToSliceRatio;
            sliceLength = sourceData.size.z / baseTerrainToSliceRatio;
            sliceHeight = sourceData.size.y;

            sliceHeightMapResolution = ((sourceData.heightmapResolution - 1) / baseTerrainToSliceRatio) + 1;
            sliceEvenHeightMapResolution = sliceHeightMapResolution - 1;

            sliceDetailResolution = sourceData.detailResolution / baseTerrainToSliceRatio;
            sliceAlphaMapResolution = sourceData.alphamapResolution / baseTerrainToSliceRatio;
            sliceBaseMapResolution = sourceData.baseMapResolution / baseTerrainToSliceRatio;
        }

        void SetLayerAndTagInfoForSlices()
        {
            if (copyBaseLayer)
                sliceOutputLayer = sourceTerrain.gameObject.layer;
            else
                sliceOutputLayer = 0;

            if (copyBaseTag)
                sliceOutputTag = sourceTerrain.tag;
            else
                sliceOutputTag = "Untagged";
        }


        TreeCopier CreateAndInitializeTreeCopier(TreeDataHandler treeDataHandler, bool copyAllTrees)
        {
            TreeCopier treeCopier = new TreeCopier(sourceTerrain, treeDataHandler, rowsOfSlices, columnsOfSlices, baseTerrainToSliceRatio, normalizedSliceStart);
            treeCopier.IdentifySlicePlacementOfTrees();
            treeCopier.IdentifyWhichPrototypesArePresentOnEachSlice(copyAllTrees);

            return treeCopier;
        }

        GameObject CreateSliceAsset(int rowOfSlice, int columnOfSlice, string sliceObjectName, string sliceTerrainDataName)
        {
            if (EditorUtility.DisplayCancelableProgressBar("Slice Creation Progress", "Creating Slice " + sliceObjectName, progress))
                throw new SliceCanceledException();

            string fullPathToSaveSlice = sliceDataSavePath + sliceTerrainDataName + ".asset";

            AssetDatabase.CreateAsset(new TerrainData(), fullPathToSaveSlice);

            GameObject gameObjectSlice = Terrain.CreateTerrainGameObject((TerrainData)AssetDatabase.LoadAssetAtPath(fullPathToSaveSlice, typeof(TerrainData)));

            gameObjectSlice.name = sliceObjectName;
            gameObjectSlice.transform.position = new Vector3(columnOfSlice * sliceWidth + nonNormalizedSliceStart.x, nonNormalizedSliceStart.y, rowOfSlice * sliceLength + nonNormalizedSliceStart.z);

            gameObjectSlice.tag = sliceOutputTag;
            gameObjectSlice.layer = sliceOutputLayer;

            return gameObjectSlice;
        }

        void CopyDataToSlice(GameObject slice, TreeCopier treeCopier, int rowOfSlice, int columnOfSlice)
        {
            var terrainSlice = slice.GetComponent<Terrain>();
            var terrainSliceData = terrainSlice.terrainData;

            CopyTerrainDataToSlice(terrainSliceData, rowOfSlice, columnOfSlice);
            slice.GetComponent<TerrainCollider>().terrainData = terrainSliceData;

            CopyTerrainSettingsToSlice(terrainSlice);
            treeCopier.CopyTreesToSlice(terrainSlice, rowOfSlice, columnOfSlice);

            terrainSliceData.RefreshPrototypes();
            terrainSlice.Flush();

            terrainSlice = null;
            terrainSliceData = null;
        }

        void CopyTerrainDataToSlice(TerrainData slice, int rowOfSlice, int columnOfSlice)
        {
            float normalizedXPositionOfSlice = GetNormalizedXPositionOfSlice(columnOfSlice);
            float normalizedZPositionOfSlice = GetNormalizedZPositionOfSlice(rowOfSlice);

            CopyResolutionDataToSlice(slice);
            slice.size = new Vector3(sliceWidth, sliceHeight, sliceLength);

            if(sliceAlphamap || copySplatTextures)
                CopySplatTexturesToSlice(slice, normalizedXPositionOfSlice, normalizedZPositionOfSlice);

            

            if(slice.detailResolution != 0)
                CopyDetailMeshesToSlice(slice, normalizedXPositionOfSlice, normalizedZPositionOfSlice);
            CopyGrassDataToSlice(slice);

            //Set height and alphamap data
            float[,] heightMap = GetHeightmapForSliceRegion(slice, normalizedXPositionOfSlice, normalizedZPositionOfSlice);
            slice.SetHeights(0, 0, heightMap);

            if (sliceAlphamap)
            {
                float[,,] alphaMap = GetAlphamapForSliceRegion(slice, normalizedXPositionOfSlice, normalizedZPositionOfSlice);
                slice.SetAlphamaps(0, 0, alphaMap);
            }
        }

        void CopyResolutionDataToSlice(TerrainData slice)
        {
            slice.heightmapResolution = sliceEvenHeightMapResolution;
            slice.alphamapResolution = sliceAlphaMapResolution;
            slice.baseMapResolution = sliceBaseMapResolution;
            slice.SetDetailResolution(sliceDetailResolution, detailResolutionPerPatch);
        }

        void CopySplatTexturesToSlice(TerrainData slice, float normalizedXPositionOfSlice, float normalizedZPositionOfSlice)
        {
            SplatPrototype[] tempSplats = new SplatPrototype[splatProtos.Length];

            for (int i = 0; i < splatProtos.Length; i++)
            {
                tempSplats[i] = new SplatPrototype();
                tempSplats[i].texture = splatProtos[i].texture;
                tempSplats[i].normalMap = splatProtos[i].normalMap;
                versionDependentDataCopier.CopyAdditionalSplatSettings(splatProtos[i], tempSplats[i]);

                tempSplats[i].tileSize = new Vector2(splatProtos[i].tileSize.x, splatProtos[i].tileSize.y);

                //float xTileOffset = ((sliceWidth * columnOfSlice) % splatProtos[i].tileSize.x) + splatProtos[i].tileOffset.x;
                //float yTileOffset = ((sliceLength * rowOfSlice) % splatProtos[i].tileSize.y) + splatProtos[i].tileOffset.y;
                float xTileOffset = ((normalizedXPositionOfSlice * sourceData.size.x) % splatProtos[i].tileSize.x) + splatProtos[i].tileOffset.x;
                float yTileOffset = ((normalizedZPositionOfSlice * sourceData.size.z) % splatProtos[i].tileSize.y) + splatProtos[i].tileOffset.y;

                tempSplats[i].tileOffset = new Vector2(xTileOffset, yTileOffset);
            }
            slice.splatPrototypes = tempSplats;
        }

        void CopyDetailMeshesToSlice(TerrainData slice, float normalizedXPositionOfSlice, float normalizedZPositionOfSlice)
        {
            int xBase = (int)(normalizedXPositionOfSlice * sourceData.detailResolution);

            int yBase = (int)(normalizedZPositionOfSlice * sourceData.detailResolution);

            int[] layersSupportedOnSlice = sourceData.GetSupportedLayers(xBase, yBase, slice.detailWidth, slice.detailHeight);
                
            if (copyAllDetails)
            {
                slice.detailPrototypes = detailProtos;
                for (int i = 0; i < layersSupportedOnSlice.Length; i++)
                    slice.SetDetailLayer(0, 0, layersSupportedOnSlice[i], sourceData.GetDetailLayer(xBase, yBase, slice.detailWidth, slice.detailHeight, layersSupportedOnSlice[i]));

            }
            else
            {
                DetailPrototype[] tempDetailProtos = new DetailPrototype[layersSupportedOnSlice.Length];
                for (int i = 0; i < layersSupportedOnSlice.Length; i++)
                    tempDetailProtos[i] = detailProtos[layersSupportedOnSlice[i]];

                slice.detailPrototypes = tempDetailProtos;

                for (int i = 0; i < layersSupportedOnSlice.Length; i++)
                    slice.SetDetailLayer(0, 0, i, sourceData.GetDetailLayer(xBase, yBase, slice.detailWidth, slice.detailHeight, layersSupportedOnSlice[i]));
            }

            
        }

        void CopyGrassDataToSlice(TerrainData slice)
        {
            slice.wavingGrassStrength = grassStrength;
            slice.wavingGrassAmount = grassAmount;
            slice.wavingGrassSpeed = grassSpeed;
            slice.wavingGrassTint = grassTint;
        }

        float[,] GetHeightmapForSliceRegion(TerrainData slice, float normalizedXPositionOfSlice, float normalizedZPositionOfSlice)
        {
            int xBase = (int)(normalizedXPositionOfSlice * (sourceData.heightmapWidth - 1));
            int yBase = (int)(normalizedZPositionOfSlice * (sourceData.heightmapHeight - 1));
            return sourceData.GetHeights(xBase, yBase, slice.heightmapWidth, slice.heightmapHeight);
        }

        float[, ,] GetAlphamapForSliceRegion(TerrainData slice, float normalizedXPositionOfSlice, float normalizedZPositionOfSlice)
        {
            float[, ,] alphaMap = new float[sliceAlphaMapResolution, sliceAlphaMapResolution, splatProtos.Length];

            int xBase = (int)(normalizedXPositionOfSlice * sourceData.alphamapWidth);
            int yBase = (int)(normalizedZPositionOfSlice * sourceData.alphamapHeight);
            return sourceData.GetAlphamaps(xBase, yBase, slice.alphamapWidth, slice.alphamapHeight);
        }

        float GetNormalizedXPositionOfSlice(int columnOfSlice)
        {
            return normalizedSliceStart.x + (columnOfSlice * normalizedSliceToBaseTerrainRatio);
        }

        float GetNormalizedZPositionOfSlice(int rowOfSlice)
        {
            return normalizedSliceStart.z + (rowOfSlice * normalizedSliceToBaseTerrainRatio);
        }

        void CopyTerrainSettingsToSlice(Terrain slice)
        {
            slice.treeDistance = sourceTerrain.treeDistance;
            slice.treeBillboardDistance = sourceTerrain.treeBillboardDistance;
            slice.treeCrossFadeLength = sourceTerrain.treeCrossFadeLength;
            slice.treeMaximumFullLODCount = sourceTerrain.treeMaximumFullLODCount;
            slice.detailObjectDistance = sourceTerrain.detailObjectDistance;
            slice.detailObjectDensity = sourceTerrain.detailObjectDensity;
            slice.heightmapPixelError = sourceTerrain.heightmapPixelError;
            slice.heightmapMaximumLOD = sourceTerrain.heightmapMaximumLOD;
            slice.basemapDistance = sourceTerrain.basemapDistance;
            slice.lightmapIndex = sourceTerrain.lightmapIndex;
            slice.castShadows = sourceTerrain.castShadows;
            slice.editorRenderFlags = sourceTerrain.editorRenderFlags;
            slice.materialTemplate = sourceTerrain.materialTemplate;
            TerrainCollider sourceCollider = sourceTerrain.GetComponent<TerrainCollider>();
            TerrainCollider sliceCollider = slice.GetComponent<TerrainCollider>();
            sliceCollider.material = sourceCollider.material;
            sliceCollider.isTrigger = sourceCollider.isTrigger;

            versionDependentDataCopier.CopyOtherSettings(sourceTerrain, slice);
        }
    }
}