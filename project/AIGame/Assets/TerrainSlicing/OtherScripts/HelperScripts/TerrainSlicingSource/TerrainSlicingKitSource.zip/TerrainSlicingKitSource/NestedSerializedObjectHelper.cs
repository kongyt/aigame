﻿//Terrain Slicing & Dynamic Loading Kits copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using System.Collections.Generic;
    using UnityEngine;
    using UnityEditor;

    public class NestedSerializedObjectHelper
    {
        Dictionary<string, SerializedProperty> propertyLookupTable;
        Dictionary<string, GUIContent> labels;
        SerializedProperty propToGetNestedPropertiesFrom;

        public NestedSerializedObjectHelper(SerializedProperty propToGetNestedPropertiesFrom)
        {
            this.propToGetNestedPropertiesFrom = propToGetNestedPropertiesFrom;
            propertyLookupTable = new Dictionary<string, SerializedProperty>();
        }

        GUIContent GetLabel(string label)
        {
            if (labels == null)
                labels = new Dictionary<string, GUIContent>();

            GUIContent guiContentLabel;
            if (!labels.TryGetValue(label, out guiContentLabel))
            {
                guiContentLabel = new GUIContent(label);
                labels.Add(label, guiContentLabel);
            }

            return guiContentLabel;
        }

        #region Methods to retrieve serialized properties by name

        //Get property of this serialized object
        public SerializedProperty GetPropertyByName(string property)
        {
            SerializedProperty prop;
            if (!propertyLookupTable.TryGetValue(property, out prop))
            {
                prop = propToGetNestedPropertiesFrom.FindPropertyRelative(property);
                propertyLookupTable.Add(property, prop);
            }

            return prop;
        }

        //Get property which is an array element of an array property belonging to this serialized object
        public SerializedProperty GetArrayElementPropertyByName(int elementIndex, string arrayProperty)
        {
            SerializedProperty parentProperty = GetPropertyByName(arrayProperty);
            return parentProperty.GetArrayElementAtIndex(elementIndex);
        }

        //Get property relative to a property belonging to this serialized object
        public SerializedProperty GetNestedPropertyByName(string parentProperty, string nestedProperty)
        {
            return GetNestedPropertyByName(GetPropertyByName(parentProperty), nestedProperty);
        }

        //Get property nested in the array element of a property belonging to this serialized object
        public SerializedProperty GetNestedArrayElementPropertyByName(int elementIndex, string arrayProperty, string nestedProperty)
        {
            return GetNestedArrayElementPropertyByName(elementIndex, GetPropertyByName(arrayProperty), nestedProperty);
        }

        public SerializedProperty GetNestedArrayElementPropertyByName(int elementIndex, SerializedProperty arrayProperty, string nestedProperty)
        {
            return GetNestedPropertyByName(arrayProperty.GetArrayElementAtIndex(elementIndex), nestedProperty);
        }

        public SerializedProperty GetNestedPropertyByName(SerializedProperty parentProperty, string nestedProperty)
        {
            return parentProperty.FindPropertyRelative(nestedProperty);
        }
        
        #endregion

        #region Drawing for NestedSerializedProperty with changeDetected parameter
        //with change detected variable
        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty, out bool changeDetected)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty), out changeDetected);
        }

        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty), out changeDetected, layoutOptions);
        }

        public void DrawNestedSerializedPropertyField(SerializedProperty parentProperty, string nestedProperty, out bool changeDetected)
        {
            DrawSerializedPropertyField(parentProperty.FindPropertyRelative(nestedProperty), out changeDetected);
        }

        public void DrawNestedSerializedPropertyField(SerializedProperty parentProperty, string nestedProperty, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(parentProperty.FindPropertyRelative(nestedProperty), out changeDetected, layoutOptions);
        }

        
        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty, string label, out bool changeDetected)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty), GetLabel(label), out changeDetected);
        }

        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty, string label, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty), GetLabel(label), out changeDetected, layoutOptions);
        }

        public void DrawNestedSerializedPropertyField(SerializedProperty parentProperty, string nestedProperty, string label, out bool changeDetected)
        {
            DrawSerializedPropertyField(parentProperty.FindPropertyRelative(nestedProperty), GetLabel(label), out changeDetected);
        }

        public void DrawNestedSerializedPropertyField(SerializedProperty parentProperty, string nestedProperty, string label, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(parentProperty.FindPropertyRelative(nestedProperty), GetLabel(label), out changeDetected, layoutOptions);
        }



        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty, GUIContent label, out bool changeDetected)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty), label, out changeDetected);
        }

        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty, GUIContent label, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty), label, out changeDetected, layoutOptions);
        }


        public void DrawNestedSerializedPropertyField(SerializedProperty parentProperty, string nestedProperty, GUIContent label, out bool changeDetected)
        {
            DrawSerializedPropertyField(parentProperty.FindPropertyRelative(nestedProperty), label, out changeDetected);
        }

        public void DrawNestedSerializedPropertyField(SerializedProperty parentProperty, string nestedProperty, GUIContent label, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(parentProperty.FindPropertyRelative(nestedProperty), label, out changeDetected, layoutOptions);
        }

        #endregion

        #region Drawing for NestedSerializedProperty without changeDetected parameter
        //with change detected variable
        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty));
        }

        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty), layoutOptions);
        }



        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty, GUIContent label)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty), label);
        }

        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty, GUIContent label, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty), label, layoutOptions);
        }



        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty, string label)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty), GetLabel(label));
        }

        public void DrawNestedSerializedPropertyField(string parentProperty, string nestedProperty, string label, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(GetNestedPropertyByName(parentProperty, nestedProperty), GetLabel(label), layoutOptions);
        }

        #endregion

        #region Drawing for Serialized Properties with changeDetected parameter

        //with out change detected variable
        public void DrawSerializedPropertyField(string property, out bool changeDetected)
        {
            DrawSerializedPropertyField(GetPropertyByName(property), out changeDetected);
        }

        public void DrawSerializedPropertyField(string property, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(GetPropertyByName(property), out changeDetected, layoutOptions);
        }

        public void DrawSerializedPropertyField(SerializedProperty prop, out bool changeDetected)
        {
            EditorGUI.BeginChangeCheck();
            DrawSerializedPropertyField(prop);
            changeDetected = EditorGUI.EndChangeCheck();
        }

        public void DrawSerializedPropertyField(SerializedProperty prop, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            EditorGUI.BeginChangeCheck();
            DrawSerializedPropertyField(prop, layoutOptions);
            changeDetected = EditorGUI.EndChangeCheck();
        }




        public void DrawSerializedPropertyField(string property, GUIContent label, out bool changeDetected)
        {
            DrawSerializedPropertyField(GetPropertyByName(property), label, out changeDetected);
        }

        public void DrawSerializedPropertyField(string property, GUIContent label, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(GetPropertyByName(property), label, out changeDetected, layoutOptions);
        }
        
        public void DrawSerializedPropertyField(SerializedProperty property, GUIContent label, out bool changeDetected)
        {
            EditorGUI.BeginChangeCheck();
            DrawSerializedPropertyField(property, label);
            changeDetected = EditorGUI.EndChangeCheck();
        }

        public void DrawSerializedPropertyField(SerializedProperty property, GUIContent label, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            EditorGUI.BeginChangeCheck();
            DrawSerializedPropertyField(property, label, layoutOptions);
            changeDetected = EditorGUI.EndChangeCheck();
        }




        public void DrawSerializedPropertyField(string property, string label, out bool changeDetected)
        {
            DrawSerializedPropertyField(GetPropertyByName(property), GetLabel(label), out changeDetected);
        }

        public void DrawSerializedPropertyField(string property, string label, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(GetPropertyByName(property), GetLabel(label), out changeDetected, layoutOptions);
        }

        public void DrawSerializedPropertyField(SerializedProperty property, string label, out bool changeDetected)
        {
            DrawSerializedPropertyField(property, GetLabel(label), out changeDetected);
        }

        public void DrawSerializedPropertyField(SerializedProperty property, string label, out bool changeDetected, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(property, GetLabel(label), out changeDetected, layoutOptions);
        }

        #endregion

        #region Drawing for Serialized Properties without changeDetected parameter

        public void DrawSerializedPropertyField(string property)
        {
            EditorGUILayout.PropertyField(GetPropertyByName(property));
        }

        public void DrawSerializedPropertyField(string property, params GUILayoutOption[] layoutOptions)
        {
            EditorGUILayout.PropertyField(GetPropertyByName(property), layoutOptions);
        }

        public void DrawSerializedPropertyField(SerializedProperty prop)
        {
            EditorGUILayout.PropertyField(prop);
        }

        public void DrawSerializedPropertyField(SerializedProperty prop, params GUILayoutOption[] layoutOptions)
        {
            EditorGUILayout.PropertyField(prop, layoutOptions);
        }



        public void DrawSerializedPropertyField(string property, string label)
        {
            DrawSerializedPropertyField(GetPropertyByName(property), GetLabel(label));
        }

        public void DrawSerializedPropertyField(string property, string label, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(GetPropertyByName(property), GetLabel(label), layoutOptions);
        }

        public void DrawSerializedPropertyField(SerializedProperty property, string label)
        {
            DrawSerializedPropertyField(property, GetLabel(label));
        }

        public void DrawSerializedPropertyField(SerializedProperty property, string label, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(property, GetLabel(label), layoutOptions);
        }




        public void DrawSerializedPropertyField(string property, GUIContent label)
        {
            EditorGUILayout.PropertyField(GetPropertyByName(property), label);
        }

        public void DrawSerializedPropertyField(string property, GUIContent label, params GUILayoutOption[] layoutOptions)
        {
            DrawSerializedPropertyField(GetPropertyByName(property), label, layoutOptions);
        }
        
        public void DrawSerializedPropertyField(SerializedProperty property, GUIContent label)
        {
            EditorGUILayout.PropertyField(property, label);
        }

        public void DrawSerializedPropertyField(SerializedProperty property, GUIContent label, params GUILayoutOption[] layoutOptions)
        {
            EditorGUILayout.PropertyField(property, label, layoutOptions);
        }

        #endregion

        #region Some other drawing methods

        public void DrawSerializedPropertyTagField(string tagProperty, GUIContent label)
        {
            SerializedProperty tag = GetPropertyByName(tagProperty);
            tag.stringValue = EditorGUILayout.TagField(label, tag.stringValue);
        }

        public void DrawSerializedPropertyLayerField(string layerProperty, GUIContent label)
        {
            SerializedProperty layer = GetPropertyByName(layerProperty);
            layer.intValue = EditorGUILayout.LayerField(label, layer.intValue);
        }

        public bool DrawSerializedPropertyFoldoutField(string foldoutProperty, string label)
        {
            SerializedProperty foldout = GetPropertyByName(foldoutProperty);
            foldout.boolValue = EditorGUILayout.Foldout(foldout.boolValue, label);
            return foldout.boolValue;
        }

        public bool DrawSerializedPropertyFoldoutField(string foldoutProperty, string label, GUIStyle style)
        {
            SerializedProperty foldout = GetPropertyByName(foldoutProperty);
            foldout.boolValue = EditorGUILayout.Foldout(foldout.boolValue, label, style);
            return foldout.boolValue;
        }

        public void DrawSerializedPropertyPopupField(string popupProperty, GUIContent label, GUIContent[] displayedOptions)
        {
            SerializedProperty popup = GetPropertyByName(popupProperty);
            popup.intValue = EditorGUILayout.Popup(label, popup.intValue, displayedOptions);
        }

        public void DrawSerializedPropertyPopupField(string popupProperty, GUIContent label, GUIContent[] displayedOptions, out bool changeDetected)
        {
            SerializedProperty popup = GetPropertyByName(popupProperty);

            EditorGUI.BeginChangeCheck();
            popup.intValue = EditorGUILayout.Popup(label, popup.intValue, displayedOptions);
            changeDetected = EditorGUI.EndChangeCheck();
        }

        public void DrawSerializedPropertyArrayField(string arrayProperty)
        {
            SerializedProperty array = GetPropertyByName(arrayProperty);
            EditorGUILayout.PropertyField(array, true);
        }

        #endregion

        #region Methods for easier access of property values

        public bool GetBool(string property)
        {
            return GetPropertyByName(property).boolValue;
        }

        public float GetFloat(string property)
        {
            return GetPropertyByName(property).floatValue;
        }

        public int GetInt(string property)
        {
            return GetPropertyByName(property).intValue;
        }

        public string GetString(string property)
        {
            return GetPropertyByName(property).stringValue;
        }

        #endregion
    }
}