//Terrain Slicing & Dynamic Loading Kit copyright � 2014 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using UnityEngine;

    public class SliceConfigurationFile : ScriptableObject
    {
        [SerializeField]
        internal SliceConfiguration sliceConfiguration = new SliceConfiguration();

        public SliceConfiguration SliceConfiguration { get { return sliceConfiguration; } }

        public float WidthOfSlice { get { return sliceConfiguration.sampleTerrain.terrainData.size.x / sliceConfiguration.baseTerrainToSliceRatio; } }
        public float LengthOfSlice { get { return sliceConfiguration.sampleTerrain.terrainData.size.z / sliceConfiguration.baseTerrainToSliceRatio; } }

        public Vector3 GetSlicePosition(int row, int column)
        {
            int columnOfSlice = column - 1;
            int rowOfSlice = row - 1;
            Vector3 sampleTerrainPosition = sliceConfiguration.sampleTerrain.GetPosition();
            float sliceStartPosX = sampleTerrainPosition.x + (sliceConfiguration.sampleTerrain.terrainData.size.x * sliceConfiguration.normalizedXPosition);
            float sliceStartPosY = sampleTerrainPosition.z + (sliceConfiguration.sampleTerrain.terrainData.size.z * sliceConfiguration.normalizedZPosition);

            return new Vector3(columnOfSlice * WidthOfSlice + sliceStartPosX, sampleTerrainPosition.y, rowOfSlice * LengthOfSlice + sliceStartPosY);
        }
    }
}