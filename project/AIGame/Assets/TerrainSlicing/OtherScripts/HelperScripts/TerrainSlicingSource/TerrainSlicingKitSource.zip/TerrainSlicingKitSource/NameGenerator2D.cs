﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using DynamicLoadingKit;

    public class NameGenerator2D
    {
        string formatString;

        public NameGenerator2D(INamingConvention namingConvention)
        {
            formatString = namingConvention.GetStringFormatVersion2DWithoutGroupName();
        }

        /// <summary>
        /// Generate a name unique for the slice at row/column. This can be used to generate
        /// folders or assets names specific to each slice. It is dependent upon the naming convention used
        /// in the constructor, so you can create your own NameGenerator based on a custom naming convention.
        /// </summary>
        /// <param name="groupIdentifier">The name common to each slice.</param>
        /// <param name="row">The row of the slice within the entire output slicing group.</param>
        /// <param name="column">The column of the slice within the entire output slicing group.</param>
        /// <returns></returns>
        public string GenerateName(string groupIdentifier, int row, int column)
        {
            return string.Format(formatString, column, row, groupIdentifier);
        }
    }
}