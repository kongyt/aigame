﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.

namespace TerrainSlicingKit
{
    internal class TextureSlicer
    {
        public TextureSlicer()
        {

        }
    }
}
