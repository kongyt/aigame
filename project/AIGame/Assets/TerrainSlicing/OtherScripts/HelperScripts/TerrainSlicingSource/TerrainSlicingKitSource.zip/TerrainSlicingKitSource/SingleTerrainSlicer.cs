﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
namespace TerrainSlicingKit
{
    using UnityEngine;
    using UnityEditor;

    internal class SingleTerrainSlicer : TerrainSlicer
    {
        internal SingleTerrainSlicer(SliceConfiguration sliceConfiguration, UnityVersionDependentDataCopier versionDependentDataCopier)
            : base(sliceConfiguration, versionDependentDataCopier)
        {
            terrainSliceCreator = new TerrainSliceCreator(versionDependentDataCopier,
                                                            unitySliceDataSavePath,
                                                            sliceConfiguration.sliceDataOutputBaseName,
                                                            sliceConfiguration.sliceOutputBaseName,
                                                            outputNamingConventionFormatStringForTerrainData,
                                                            outputNamingConventionFormatStringForTerrainObject,
                                                            outputNumberingStartsAt0,
                                                            sliceConfiguration.rowsOfSlices,
                                                            sliceConfiguration.columnsOfSlices,
                                                            sliceConfiguration.baseTerrainToSliceRatio,
                                                            sliceConfiguration.NormalizedSlicingGridPosition,
                                                            sliceConfiguration.sliceProcessors,
                                                            sliceConfiguration.copyBaseLayer,
                                                            sliceConfiguration.copyBaseTag,
                                                            sliceConfiguration.copyAllTrees,
                                                            sliceConfiguration.copyAllDetails,
                                                            !sliceConfiguration.dontSliceAlphamap,
                                                            sliceConfiguration.copySplatTextures,
                                                            sliceConfiguration.createPrefabs,
                                                            prefabSliceSavePath,
                                                            sliceConfiguration.removeSlicesFromSceneAfterCreation);
        }

        protected sealed override int OutputFirstRow { get { return outputRowStart; } }
        protected sealed override int OutputFirstColumn { get { return outputColumnStart; } }

        protected sealed override int OutputLastRow { get { return OutputFirstRow + sliceConfiguration.rowsOfSlices - 1; } }
        protected sealed override int OutputLastColumn { get { return OutputFirstColumn + sliceConfiguration.columnsOfSlices - 1; } }

        protected sealed override void SliceTerrain(TreeDataHandler treeDataHandler)
        {
            terrainSliceCreator.CreateSlices(sliceConfiguration.sampleTerrain, treeDataHandler, 0, 0, 0f);
        }

        protected sealed override void OverwriteProtection()
        {
            DataOverwriteProtection();
            if (sliceConfiguration.createPrefabs && EditorUtility.IsPersistent(sliceConfiguration.sampleTerrain))
                PrefabOverwriteProtection();
        }

        void DataOverwriteProtection()
        {
            string terrainDataToSliceLocation = AssetDatabase.GetAssetPath(sliceConfiguration.sampleTerrain.terrainData);

            string formatString = unitySliceDataSavePath + outputNamingConventionFormatStringForTerrainData + ".asset";

            for (int row = outputRowStart; row <= outputRowEnd; row++)
            {
                for (int column = outputColumnStart; column <= outputColumnEnd; column++)
                {
                    if (string.Compare(terrainDataToSliceLocation, string.Format(formatString, column, row)) == 0)
                        throw new SliceException("With the current settings, the output slice data will overwrite the data of the terrain you're slicing. Change " +
                        "the slice data save folder, base name of created slice data, or move the data of the terrain you're slicing to a different folder.");
                }
            }
        }

        void PrefabOverwriteProtection()
        {
            string terrainPrefabToSliceLocation = AssetDatabase.GetAssetPath(sliceConfiguration.sampleTerrain);
            string formatString = prefabSliceSavePath + outputNamingConventionFormatStringForTerrainObject + ".asset";

            for (int row = outputRowStart; row <= outputRowEnd; row++)
            {
                for (int column = outputColumnStart; column <= outputColumnEnd; column++)
                {
                    if (string.Compare(terrainPrefabToSliceLocation, string.Format(formatString, column, row)) == 0)
                        throw new SliceException("With the current settings, the output slice prefabs will overwrite the prefab of the terrain you're slicing. Change " +
                        "the slice prefab save folder, base name of created slices, or move the terrain prefab you're slicing to a different folder.");
                }
            }
        }
    }
}