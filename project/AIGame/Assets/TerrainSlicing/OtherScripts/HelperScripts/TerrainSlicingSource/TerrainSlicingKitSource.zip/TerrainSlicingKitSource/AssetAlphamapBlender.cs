﻿//Terrain Slicing & Dynamic Loading Kit copyright © 2012 Kyle Gillen. All rights reserved. Redistribution is not allowed.
using UnityEngine;
using UnityEditor;

namespace TerrainSlicingKit
{
    public class AssetAlphamapBlender
    {
        string assetsFormatString;
        float progress, progressIncrement;

        public AssetAlphamapBlender(string absolutePathOfFolderWhereTerrainDataAssetsAreStored, string assetsRowColumnFormatString)
        {
            assetsFormatString = absolutePathOfFolderWhereTerrainDataAssetsAreStored;
            if (!assetsFormatString.EndsWith("/"))
                assetsFormatString += "/";

            assetsFormatString = assetsFormatString + assetsRowColumnFormatString + ".asset";
        }

        AlphamapBlender ConstructAlphamapBlender(int firstRow, int firstColumn, int effectedRegionWidth)
        {
            string assetName = string.Format(assetsFormatString, firstColumn, firstRow);
            TerrainData asset = (TerrainData)AssetDatabase.LoadAssetAtPath(assetName, typeof(TerrainData));
            if (asset == null)
                throw new System.Exception("Could not find Terrain Data Asset at path " + assetName + ". Blending aborted.");

            float effectedRegionWidth_asFloat = (float)effectedRegionWidth;
            effectedRegionWidth = Mathf.CeilToInt(effectedRegionWidth_asFloat * (asset.alphamapResolution / (asset.heightmapResolution - 1f)));

            return new AlphamapBlender(effectedRegionWidth);
        }

        public void BlendTerrainDataAssets(int firstRow, int lastRow, int firstColumn, int lastColumn, 
            int effectedRegionWidth, PortionToTile portionToTile)
        {
            AlphamapBlender alphamapBlender = ConstructAlphamapBlender(firstRow, firstColumn, effectedRegionWidth);

            progress = 0f;
            progressIncrement = .5f / ((lastColumn - firstColumn) * (lastRow - firstRow + 1));
            BlendVerticalEdges(firstRow, lastRow, firstColumn, lastColumn, portionToTile, alphamapBlender);

            progress = .5f;
            progressIncrement = .5f / ((lastRow - firstRow) * (lastColumn - firstColumn + 1));
            BlendHorizontalEdges(firstRow, lastRow, firstColumn, lastColumn, portionToTile, alphamapBlender);
            EditorUtility.DisplayProgressBar("Blending Alphamaps", "Blending Horizontal Edges", 1f);
            EditorUtility.ClearProgressBar();
            AssetDatabase.Refresh();
        }



        void BlendVerticalEdges(int firstRow, int lastRow, int firstColumn, int lastColumn, PortionToTile portionToTile, AlphamapBlender alphamapBlender)
        {
            for (int row = firstRow; row <= lastRow; row++)
            {
                TerrainData leftTerrainData = GetTerrainDataAssetAtPath(string.Format(assetsFormatString, firstColumn, row));
                float[, ,] leftAlphamap = null;
                    
                if(leftTerrainData != null)
                    leftAlphamap = GetAlphamapFromTerrainData(leftTerrainData);

                if (portionToTile != PortionToTile.TileInner)
                    TileOuterVerticalEdge(leftTerrainData, 
                                            leftAlphamap,
                                            GetTerrainDataAssetAtPath(string.Format(assetsFormatString, lastColumn, row)), 
                                            alphamapBlender);

                TerrainData rightTerrainData = leftTerrainData;
                float[, ,] rightAlphamap = leftAlphamap;
                leftTerrainData = null;
                leftAlphamap = null;

                if (portionToTile != PortionToTile.TileOuter)
                    TileInnerVerticalEdgesOfTerrainsOnRow(row, firstColumn, lastColumn, rightTerrainData, rightAlphamap, alphamapBlender);
                        
                rightTerrainData = null;
                rightAlphamap = null;
                OtherExtensions.FreeMemory();
            }
        }

        void BlendHorizontalEdges(int firstRow, int lastRow, int firstColumn, int lastColumn, PortionToTile portionToTile, AlphamapBlender alphamapBlender)
        {
            for (int column = firstColumn; column <= lastColumn; column++)
            {
                TerrainData bottomTerrainData = GetTerrainDataAssetAtPath(string.Format(assetsFormatString, column, firstRow));
                float[, ,] bottomAlphamap = null;

                if (bottomTerrainData != null)
                    bottomAlphamap = GetAlphamapFromTerrainData(bottomTerrainData);

                if (portionToTile != PortionToTile.TileInner)
                    TileOuterHorizontalEdge(bottomTerrainData, 
                                            bottomAlphamap,
                                            GetTerrainDataAssetAtPath(string.Format(assetsFormatString, column, lastRow)), 
                                            alphamapBlender);

                TerrainData topTerrainData = bottomTerrainData;
                float[, ,] topAlphamap = bottomAlphamap;
                bottomTerrainData = null;
                bottomAlphamap = null;

                if (portionToTile != PortionToTile.TileOuter)
                    TileInnerHorizontalEdgesOfTerrainsOnColumn(column, firstRow, lastRow, topTerrainData, topAlphamap, alphamapBlender);

                topTerrainData = null;
                topAlphamap = null;
                OtherExtensions.FreeMemory();
            }
        }

        TerrainData GetTerrainDataAssetAtPath(string fullPathOfAsset)
        {
            return (TerrainData)AssetDatabase.LoadAssetAtPath(fullPathOfAsset, typeof(TerrainData));
        }

        float[, ,] GetAlphamapFromTerrainData(TerrainData terrainData)
        {
            return terrainData.GetAlphamaps(0, 0, terrainData.alphamapWidth, terrainData.alphamapHeight);
        }

        void SetAlphamapOfTerrainData(float[, ,] alphamap, TerrainData terrainData)
        {
            terrainData.SetAlphamaps(0, 0, alphamap);
        }

        void TileOuterVerticalEdge(TerrainData leftTerrainData, float[, ,] leftAlphamap, TerrainData rightTerrainData, AlphamapBlender alphamapBlender)
        {
            if (leftTerrainData == null || rightTerrainData == null)
                return;

            float[, ,] rightAlphamap = GetAlphamapFromTerrainData(rightTerrainData);
            alphamapBlender.BlendVerticalEdgeAlpha(leftAlphamap, rightAlphamap, false);

            SetAlphamapOfTerrainData(leftAlphamap, leftTerrainData);
            SetAlphamapOfTerrainData(rightAlphamap, rightTerrainData);

            rightTerrainData = null;
            rightAlphamap = null;

            OtherExtensions.FreeMemory();
        }

        void TileOuterHorizontalEdge(TerrainData bottomTerrainData, float[, ,] bottomAlphamap, TerrainData topTerrainData, AlphamapBlender alphamapBlender)
        {
            if (bottomTerrainData == null || topTerrainData == null)
                return;

            float[, ,] topAlphamap = GetAlphamapFromTerrainData(topTerrainData);
            alphamapBlender.BlendHorizontalEdgeAlpha(bottomAlphamap, topAlphamap, false);

            SetAlphamapOfTerrainData(bottomAlphamap, bottomTerrainData);
            SetAlphamapOfTerrainData(topAlphamap, topTerrainData);

            topTerrainData = null;
            topAlphamap = null;

            OtherExtensions.FreeMemory();
        }

        void TileInnerVerticalEdgesOfTerrainsOnRow(int row, int firstColumn, int lastColumn, TerrainData rightTerrainData, 
            float[,,] rightAlphamap, AlphamapBlender alphamapBlender)
        {
            for (int column = firstColumn; column <= lastColumn; column++)
            {
                EditorUtility.DisplayProgressBar("Blending Alphamaps", "Blending Vertical Edges", progress);
                progress += progressIncrement;

                TerrainData leftTerrainData = rightTerrainData;
                rightTerrainData = GetTerrainDataAssetAtPath(string.Format(assetsFormatString, column, row));

                if (leftTerrainData == null || rightTerrainData == null)
                    continue;

                float[,,] leftAlphamap = rightAlphamap;
                rightAlphamap = GetAlphamapFromTerrainData(rightTerrainData);

                alphamapBlender.BlendVerticalEdgeAlpha(leftAlphamap, rightAlphamap, false);
                SetAlphamapOfTerrainData(leftAlphamap, leftTerrainData);
                SetAlphamapOfTerrainData(rightAlphamap, rightTerrainData);

                leftTerrainData = null;
                leftAlphamap = null;

                OtherExtensions.FreeMemory();
            }
        }

        void TileInnerHorizontalEdgesOfTerrainsOnColumn(int column, int firstRow, int lastRow, TerrainData topTerrainData,
            float[, ,] topAlphamap, AlphamapBlender alphamapBlender)
        {
            for (int row = firstRow; row < lastRow; row++)
            {
                EditorUtility.DisplayProgressBar("Blending Alphamaps", "Blending Horizontal Edges", progress);
                progress += progressIncrement;

                TerrainData bottomTerrainData = topTerrainData;
                topTerrainData = GetTerrainDataAssetAtPath(string.Format(assetsFormatString, column, row));

                if (bottomTerrainData == null || topTerrainData == null)
                    continue;

                float[,,] bottomAlphamap = topAlphamap;
                topAlphamap = GetAlphamapFromTerrainData(topTerrainData);

                alphamapBlender.BlendHorizontalEdgeAlpha(bottomAlphamap, topAlphamap, false);
                SetAlphamapOfTerrainData(bottomAlphamap, bottomTerrainData);
                SetAlphamapOfTerrainData(topAlphamap, topTerrainData);

                bottomTerrainData = null;
                bottomAlphamap = null;

                OtherExtensions.FreeMemory();
            }
        }
    }
}